package org.openquark.cal_Cal_Core_Debug;

import org.openquark.cal.internal.foreignsupport.module.Debug.Debug;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Show_Internal extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Show_Internal $instance = new Show_Internal();

	private Show_Internal() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Debug";
	}

	public final java.lang.String getUnqualifiedName() {
		return "showInternal";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Debug.showInternal";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Debug.showInternal
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue value = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(value, value = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Debug.showInternal
	 */
	public final RTValue f1L(RTValue value, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(value, value = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Debug.showInternal
	 */
	public final RTValue f1S(RTValue value, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_String.make(
				Debug.showInternal(RTData.CAL_Opaque.make(value)));
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Core.Debug.showInternal
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.String fUnboxed1S(RTValue value, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return Debug.showInternal(RTData.CAL_Opaque.make(value));
	}

}
