package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.To_Asc_List;
import org.openquark.cal_Cal_Core_Prelude.Map;
import org.openquark.cal_Cal_Core_Prelude.Snd;

public final class Get_Vertices_In_Insertion_Order extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Vertices_In_Insertion_Order $instance = 
		new Get_Vertices_In_Insertion_Order();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_getVerticesInInsertionOrder_169_42 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"getVerticesInInsertionOrder", 
			169, 
			42);

	private Get_Vertices_In_Insertion_Order() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getVerticesInInsertionOrder";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.getVerticesInInsertionOrder";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getVerticesInInsertionOrder
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getVerticesInInsertionOrder
	 */
	public final RTValue f1L(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getVerticesInInsertionOrder
	 */
	public final RTValue f1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Map.$instance.f2S(
				Snd.$instance, 
				To_Asc_List.$instance.f1S(
					(((RTCons)(java.lang.Object)
						graph.evaluate($ec))).getFieldByIndex(
						0, 
						1, 
						Get_Vertices_In_Insertion_Order.Cal_Utilities_DirectedGraph_getVerticesInInsertionOrder_169_42).evaluate(
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec);
	}

}
