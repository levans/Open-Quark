package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_List.Find;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Map__merge_If_Duplicate__8 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Map__merge_If_Duplicate__8 $instance = 
		new Map__merge_If_Duplicate__8();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_map_685_21 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "map", 685, 21);

	private Map__merge_If_Duplicate__8() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "map$mergeIfDuplicate$8";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.map$mergeIfDuplicate$8";
	}

	private static final RTValue duplicateVertex$20$def_Lazy(RTValue duplicate, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(duplicate, 2);
	}

	private static final RTValue duplicateVertex$20$def_Strict(RTValue duplicate, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				duplicate.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue duplicateNum$19$def_Lazy(RTValue duplicate, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(duplicate, 1);
	}

	private static final RTValue duplicateNum$19$def_Strict(RTValue duplicate, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				duplicate.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final int duplicateNum$19$def_Unboxed(RTValue duplicate, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				duplicate.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue entryNum$18$def_Lazy(RTValue entry, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				entry.getValue())).getOrdinalFieldValue(
				1);
	}

	private static final RTValue entryNum$18$def_Strict(RTValue entry, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				entry.getValue())).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final int entryNum$18$def_Unboxed(RTValue entry, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				entry.getValue())).getOrdinalFieldValue(
				1).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue maybeDuplicate$15$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_44, RTValue entry, RTValue seenEntries, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Find.$instance, 
				new RTPartialApp._3._2(
					_lambda__map__1.$instance, 
					$dictvarCal_Core_Prelude_Eq_44, 
					entry.getValue()), 
				seenEntries);
	}

	private static final RTValue maybeDuplicate$15$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_44, RTValue entry, RTValue seenEntries, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Find.$instance.f2S(
				new RTPartialApp._3._2(
					_lambda__map__1.$instance, 
					$dictvarCal_Core_Prelude_Eq_44, 
					entry.getValue()), 
				seenEntries.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue graph$13$def_Lazy(RTValue accumPair, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				accumPair.getValue())).getOrdinalFieldValue(
				2);
	}

	private static final RTValue graph$13$def_Strict(RTValue accumPair, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				accumPair.getValue())).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue seenEntries$12$def_Lazy(RTValue accumPair, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				accumPair.getValue())).getOrdinalFieldValue(
				1);
	}

	private static final RTValue seenEntries$12$def_Strict(RTValue accumPair, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				accumPair.getValue())).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.map$mergeIfDuplicate$8
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue entry = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue accumPair = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_44 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_44, 
					$dictvarCal_Core_Prelude_Eq_44 = null), 
				RTValue.lastRef(accumPair.evaluate($ec), accumPair = null), 
				RTValue.lastRef(entry.evaluate($ec), entry = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.map$mergeIfDuplicate$8
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_44, RTValue accumPair, RTValue entry, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_44, 
					$dictvarCal_Core_Prelude_Eq_44 = null), 
				RTValue.lastRef(accumPair.evaluate($ec), accumPair = null), 
				RTValue.lastRef(entry.evaluate($ec), entry = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.map$mergeIfDuplicate$8
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_44, RTValue accumPair, RTValue entry, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_seenEntries = 
			Map__merge_If_Duplicate__8.seenEntries$12$def_Lazy(
				accumPair.getValue(), 
				$ec);

		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)Map__merge_If_Duplicate__8.maybeDuplicate$15$def_Strict($dictvarCal_Core_Prelude_Eq_44, entry.getValue(), letVar_seenEntries, $ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {new TYPE_List.CAL_Cons(entry.getValue(), letVar_seenEntries), Map__merge_If_Duplicate__8.graph$13$def_Lazy(accumPair.getValue(), $ec)});
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue duplicate = $case1.get_value();

				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {letVar_seenEntries, new RTFullApp.General._6._S(Merge_Vertices_Internal.$instance, $dictvarCal_Core_Prelude_Eq_44, Map__merge_If_Duplicate__8.graph$13$def_Lazy(accumPair.getValue(), $ec), RTData.CAL_Boolean.make(true), Map__merge_If_Duplicate__8.duplicateNum$19$def_Lazy(duplicate, $ec), Map__merge_If_Duplicate__8.entryNum$18$def_Lazy(entry.getValue(), $ec), Map__merge_If_Duplicate__8.duplicateVertex$20$def_Lazy(duplicate, $ec))});
			}

			default: {
				return 
					badSwitchIndex(
						Map__merge_If_Duplicate__8.Cal_Utilities_DirectedGraph_map_685_21);
			}
		}
	}

}
