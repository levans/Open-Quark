package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal_Cal_Collections_List.Reverse;
import org.openquark.cal_Cal_Collections_Set.Delete_Find_Min;
import org.openquark.cal_Cal_Collections_Set.From_Distinct_Asc_List;
import org.openquark.cal_Cal_Collections_Set.Insert;
import org.openquark.cal_Cal_Collections_Set.Is_Empty;
import org.openquark.cal_Cal_Collections_Set.To_Asc_List;
import org.openquark.cal_Cal_Collections_Set.Union;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Stable_Topological_Sort__sort_Helper__5 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Stable_Topological_Sort__sort_Helper__5 $instance = 
		new Stable_Topological_Sort__sort_Helper__5();

	private Stable_Topological_Sort__sort_Helper__5() {
	}

	public final int getArity() {
		return 5;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "stableTopologicalSort$sortHelper$5";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.stableTopologicalSort$sortHelper$5";
	}

	private static final RTValue neighbours$18$def_Lazy(RTValue graph, RTValue min, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				To_Asc_List.$instance, 
				new RTFullApp.General._2._S(
					Get_Neighbour_Set.$instance, 
					graph, 
					min));
	}

	private static final RTValue neighbours$18$def_Strict(RTValue graph, RTValue min, RTExecutionContext $ec) throws CALExecutorException {
		return 
			To_Asc_List.$instance.f1S(
				Get_Neighbour_Set.$instance.f2S(graph, min, $ec).evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue candidatesToAdd$15$def_Lazy(RTValue graph, RTValue min, RTValue reverseGraph, RTValue newSatisfiedSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_Distinct_Asc_List.$instance, 
				new RTFullApp.General._2._S(
					Filter_List_Strict.$instance, 
					new RTPartialApp._3._2(
						Stable_Topological_Sort__are_Dependencies_Satisfied__17.$instance, 
						reverseGraph, 
						newSatisfiedSet), 
					Stable_Topological_Sort__sort_Helper__5.neighbours$18$def_Lazy(
						graph, 
						min, 
						$ec)));
	}

	private static final RTValue candidatesToAdd$15$def_Strict(RTValue graph, RTValue min, RTValue reverseGraph, RTValue newSatisfiedSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Distinct_Asc_List.$instance.f1S(
				Filter_List_Strict.$instance.f2S(
					new RTPartialApp._3._2(
						Stable_Topological_Sort__are_Dependencies_Satisfied__17.$instance, 
						reverseGraph, 
						newSatisfiedSet), 
					Stable_Topological_Sort__sort_Helper__5.neighbours$18$def_Lazy(
						graph, 
						min, 
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue newCandidateSet$16$def_Lazy(RTValue graph, RTValue min, RTValue reverseGraph, RTValue newSatisfiedSet, RTValue candidateSetWithoutMin, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Union.$instance, 
				_dict___Ord___Int.$instance, 
				candidateSetWithoutMin, 
				Stable_Topological_Sort__sort_Helper__5.candidatesToAdd$15$def_Lazy(
					graph, 
					min, 
					reverseGraph, 
					newSatisfiedSet, 
					$ec));
	}

	private static final RTValue newCandidateSet$16$def_Strict(RTValue graph, RTValue min, RTValue reverseGraph, RTValue newSatisfiedSet, RTValue candidateSetWithoutMin, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Union.$instance.f3S(
				_dict___Ord___Int.$instance, 
				candidateSetWithoutMin.evaluate($ec), 
				Stable_Topological_Sort__sort_Helper__5.candidatesToAdd$15$def_Strict(
					graph, 
					min, 
					reverseGraph, 
					newSatisfiedSet, 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue newSatisfiedSet$14$def_Lazy(RTValue min, RTValue satisfiedSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Insert.$instance, 
				_dict___Ord___Int.$instance, 
				min, 
				satisfiedSet);
	}

	private static final RTValue newSatisfiedSet$14$def_Strict(RTValue min, RTValue satisfiedSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Insert.$instance.f3S(
				_dict___Ord___Int.$instance, 
				min, 
				satisfiedSet.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue newReversedList$13$def_Lazy(RTValue min, RTValue reversedList, RTExecutionContext $ec) throws CALExecutorException {
		return new TYPE_List.CAL_Cons(min, reversedList);
	}

	private static final RTValue newReversedList$13$def_Strict(RTValue min, RTValue reversedList, RTExecutionContext $ec) throws CALExecutorException {
		return new TYPE_List.CAL_Cons(min, reversedList);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stableTopologicalSort$sortHelper$5
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue candidateSet = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue satisfiedSet = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue reversedList = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue graph = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue reverseGraph = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f5S(
				RTValue.lastRef(reverseGraph, reverseGraph = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(reversedList, reversedList = null), 
				RTValue.lastRef(satisfiedSet, satisfiedSet = null), 
				RTValue.lastRef(candidateSet, candidateSet = null), 
				$ec);
	}

	/**
	 * f5L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stableTopologicalSort$sortHelper$5
	 */
	public final RTValue f5L(RTValue reverseGraph, RTValue graph, RTValue reversedList, RTValue satisfiedSet, RTValue candidateSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f5S(
				RTValue.lastRef(reverseGraph, reverseGraph = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(reversedList, reversedList = null), 
				RTValue.lastRef(satisfiedSet, satisfiedSet = null), 
				RTValue.lastRef(candidateSet, candidateSet = null), 
				$ec);
	}

	/**
	 * f5S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stableTopologicalSort$sortHelper$5
	 */
	public final RTValue f5S(RTValue reverseGraph, RTValue graph, RTValue reversedList, RTValue satisfiedSet, RTValue candidateSet, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			if (Is_Empty.$instance.fUnboxed1S(candidateSet.evaluate($ec), $ec)) {
				return Reverse.$instance.f1S(reversedList.evaluate($ec), $ec);
			} else {

				RTRecordValue $recordCase2 = 
					((RTRecordValue)(java.lang.Object)
						Delete_Find_Min.$instance.f1S(
							candidateSet.evaluate($ec), 
							$ec).evaluate(
							$ec));
				RTValue min = $recordCase2.getOrdinalFieldValue(1);
				RTValue candidateSetWithoutMin = 
					$recordCase2.getOrdinalFieldValue(2);

				RTValue letVar_newSatisfiedSet = 
					Stable_Topological_Sort__sort_Helper__5.newSatisfiedSet$14$def_Lazy(
						min, 
						satisfiedSet, 
						$ec);

				RTValue satisfiedSet$ = letVar_newSatisfiedSet;
					reversedList = 
					Stable_Topological_Sort__sort_Helper__5.newReversedList$13$def_Lazy(
						min, 
						reversedList, 
						$ec);
				satisfiedSet = satisfiedSet$;
					candidateSet = 
					Stable_Topological_Sort__sort_Helper__5.newCandidateSet$16$def_Lazy(
						graph, 
						min, 
						reverseGraph, 
						letVar_newSatisfiedSet, 
						candidateSetWithoutMin, 
						$ec);
				continue TRLoop;
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Stable_Topological_Sort__sort_Helper__5 function;

		private RTValue stableTopologicalSort$reverseGraph$4;

		private RTValue stableTopologicalSort$graph$1;

		private RTValue stableTopologicalSort$reversedList$8;

		private RTValue stableTopologicalSort$satisfiedSet$9;

		private RTValue stableTopologicalSort$candidateSet$10;

		public RTAppS(Stable_Topological_Sort__sort_Helper__5 $function, RTValue $stableTopologicalSort$reverseGraph$4, RTValue $stableTopologicalSort$graph$1, RTValue $stableTopologicalSort$reversedList$8, RTValue $stableTopologicalSort$satisfiedSet$9, RTValue $stableTopologicalSort$candidateSet$10) {
			assert (
				((((($function != null) && 
				($stableTopologicalSort$reverseGraph$4 != null)) && 
				($stableTopologicalSort$graph$1 != null)) && 
				($stableTopologicalSort$reversedList$8 != null)) && 
				($stableTopologicalSort$satisfiedSet$9 != null)) && 
				($stableTopologicalSort$candidateSet$10 != null)) : (badConsArgMsg());
			function = $function;
				stableTopologicalSort$reverseGraph$4 = 
				$stableTopologicalSort$reverseGraph$4;
			stableTopologicalSort$graph$1 = $stableTopologicalSort$graph$1;
				stableTopologicalSort$reversedList$8 = 
				$stableTopologicalSort$reversedList$8;
				stableTopologicalSort$satisfiedSet$9 = 
				$stableTopologicalSort$satisfiedSet$9;
				stableTopologicalSort$candidateSet$10 = 
				$stableTopologicalSort$candidateSet$10;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f5S(
						RTValue.lastRef(
							stableTopologicalSort$reverseGraph$4, 
							stableTopologicalSort$reverseGraph$4 = null), 
						RTValue.lastRef(
							stableTopologicalSort$graph$1, 
							stableTopologicalSort$graph$1 = null), 
						RTValue.lastRef(
							stableTopologicalSort$reversedList$8, 
							stableTopologicalSort$reversedList$8 = null), 
						RTValue.lastRef(
							stableTopologicalSort$satisfiedSet$9, 
							stableTopologicalSort$satisfiedSet$9 = null), 
						RTValue.lastRef(
							stableTopologicalSort$candidateSet$10, 
							stableTopologicalSort$candidateSet$10 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			stableTopologicalSort$reverseGraph$4 = null;
			stableTopologicalSort$graph$1 = null;
			stableTopologicalSort$reversedList$8 = null;
			stableTopologicalSort$satisfiedSet$9 = null;
			stableTopologicalSort$candidateSet$10 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 5;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return stableTopologicalSort$reverseGraph$4;
				}

				case 1: {
					return stableTopologicalSort$graph$1;
				}

				case 2: {
					return stableTopologicalSort$reversedList$8;
				}

				case 3: {
					return stableTopologicalSort$satisfiedSet$9;
				}

				case 4: {
					return stableTopologicalSort$candidateSet$10;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 5)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
