package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class _lambda__reverse__1 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__reverse__1 $instance = 
		new _lambda__reverse__1();

	private _lambda__reverse__1() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$reverse$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$reverse$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue accum2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue endVertex = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue startVertex = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(endVertex, endVertex = null), 
				RTValue.lastRef(accum2, accum2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$1
	 */
	public final RTValue f3L(RTValue startVertex, RTValue endVertex, RTValue accum2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(endVertex, endVertex = null), 
				RTValue.lastRef(accum2, accum2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$1
	 */
	public final RTValue f3S(RTValue startVertex, RTValue endVertex, RTValue accum2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new TYPE_List.CAL_Cons(
				RTRecordValue.makeTupleRecord(
					new RTValue[] {endVertex, startVertex}), 
				accum2);
	}

}
