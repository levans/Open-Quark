package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_Set.Difference;
import org.openquark.cal_Cal_Collections_Set.Is_Empty;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Flatten_Components__remove_Component_Set__7 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Flatten_Components__remove_Component_Set__7 $instance = 
		new Flatten_Components__remove_Component_Set__7();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Flatten_Components__remove_Component_Set__7() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "flattenComponents$removeComponentSet$7";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.flattenComponents$removeComponentSet$7";
	}

	private static final RTValue updatedSet$13$def_Lazy(RTValue set, RTValue componentSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Difference.$instance, 
				_dict___Ord___Int.$instance, 
				set, 
				componentSet);
	}

	private static final RTValue updatedSet$13$def_Strict(RTValue set, RTValue componentSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Difference.$instance.f3S(
				_dict___Ord___Int.$instance, 
				set.evaluate($ec), 
				componentSet.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$removeComponentSet$7
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue set = $rootNode.getArgValue();
		RTValue componentSet = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(componentSet, componentSet = null), 
				RTValue.lastRef(set, set = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$removeComponentSet$7
	 */
	public final RTValue f2L(RTValue componentSet, RTValue set, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(componentSet, componentSet = null), 
				RTValue.lastRef(set, set = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$removeComponentSet$7
	 */
	public final RTValue f2S(RTValue componentSet, RTValue set, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_updatedSet = 
			Flatten_Components__remove_Component_Set__7.updatedSet$13$def_Lazy(
				set, 
				componentSet, 
				$ec);

		// Top level supercombinator logic
		if (Is_Empty.$instance.fUnboxed1S(letVar_updatedSet.evaluate($ec), $ec)) {
			return Flatten_Components__remove_Component_Set__7.i_Nothing;
		} else {
			return new TYPE_Maybe.CAL_Just(letVar_updatedSet);
		}
	}

}
