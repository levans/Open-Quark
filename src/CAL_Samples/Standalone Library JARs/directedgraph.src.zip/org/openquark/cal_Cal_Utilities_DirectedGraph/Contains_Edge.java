package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.From_Just;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;

public final class Contains_Edge extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Contains_Edge $instance = new Contains_Edge();

	private Contains_Edge() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "containsEdge";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.containsEdge";
	}

	private static final RTValue endVertexNum$8$def_Lazy(RTValue maybeEndVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(From_Just.$instance, maybeEndVertexNum);
	}

	private static final RTValue endVertexNum$8$def_Strict(RTValue maybeEndVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeEndVertexNum.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final int endVertexNum$8$def_Unboxed(RTValue maybeEndVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeEndVertexNum.evaluate($ec), 
				$ec).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue maybeEndVertexNum$7$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_23, RTValue graph, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Get_Maybe_Vertex_Number.$instance, 
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				endVertex);
	}

	private static final RTValue maybeEndVertexNum$7$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_23, RTValue graph, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Get_Maybe_Vertex_Number.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				endVertex, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue startVertexNum$6$def_Lazy(RTValue maybeStartVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_Just.$instance, 
				maybeStartVertexNum);
	}

	private static final RTValue startVertexNum$6$def_Strict(RTValue maybeStartVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeStartVertexNum.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final int startVertexNum$6$def_Unboxed(RTValue maybeStartVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeStartVertexNum.evaluate($ec), 
				$ec).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue maybeStartVertexNum$5$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_23, RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Get_Maybe_Vertex_Number.$instance, 
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				startVertex);
	}

	private static final RTValue maybeStartVertexNum$5$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_23, RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Get_Maybe_Vertex_Number.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				startVertex, 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsEdge
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue edge = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_23 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_23, 
					$dictvarCal_Core_Prelude_Eq_23 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(edge, edge = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsEdge
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_23, RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_23, 
					$dictvarCal_Core_Prelude_Eq_23 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(edge, edge = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsEdge
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_23, RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)edge.evaluate($ec));
		RTValue startVertex = $recordCase1.getOrdinalFieldValue(1);
		RTValue endVertex = $recordCase1.getOrdinalFieldValue(2);

		RTValue letVar_maybeStartVertexNum = 
			Contains_Edge.maybeStartVertexNum$5$def_Lazy(
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				startVertex, 
				$ec);
		RTValue letVar_maybeEndVertexNum = 
			Contains_Edge.maybeEndVertexNum$7$def_Lazy(
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				endVertex, 
				$ec);

		return 
			RTData.CAL_Boolean.make(
				Is_Just.$instance.fUnboxed1S(
					letVar_maybeStartVertexNum.evaluate($ec), 
					$ec) && 
				(Is_Just.$instance.fUnboxed1S(
					letVar_maybeEndVertexNum.evaluate($ec), 
					$ec) && 
				Contains_Edge_Internal.$instance.fUnboxed4S(
					$dictvarCal_Core_Prelude_Eq_23, 
					graph, 
					Contains_Edge.startVertexNum$6$def_Lazy(
						letVar_maybeStartVertexNum, 
						$ec), 
					Contains_Edge.endVertexNum$8$def_Lazy(
						letVar_maybeEndVertexNum, 
						$ec), 
					$ec)));
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.containsEdge
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Eq_23, RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)edge.evaluate($ec));
		RTValue startVertex = $recordCase1.getOrdinalFieldValue(1);
		RTValue endVertex = $recordCase1.getOrdinalFieldValue(2);

		RTValue letVar_maybeStartVertexNum = 
			Contains_Edge.maybeStartVertexNum$5$def_Lazy(
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				startVertex, 
				$ec);
		RTValue letVar_maybeEndVertexNum = 
			Contains_Edge.maybeEndVertexNum$7$def_Lazy(
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				endVertex, 
				$ec);

		return 
			Is_Just.$instance.fUnboxed1S(
				letVar_maybeStartVertexNum.evaluate($ec), 
				$ec) && 
			(Is_Just.$instance.fUnboxed1S(
				letVar_maybeEndVertexNum.evaluate($ec), 
				$ec) && 
			Contains_Edge_Internal.$instance.fUnboxed4S(
				$dictvarCal_Core_Prelude_Eq_23, 
				graph, 
				Contains_Edge.startVertexNum$6$def_Lazy(
					letVar_maybeStartVertexNum, 
					$ec), 
				Contains_Edge.endVertexNum$8$def_Lazy(
					letVar_maybeEndVertexNum, 
					$ec), 
				$ec));
	}

}
