package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;

public final class Exists_Reachable_Cycle extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Exists_Reachable_Cycle $instance = 
		new Exists_Reachable_Cycle();

	private Exists_Reachable_Cycle() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "existsReachableCycle";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.existsReachableCycle";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsReachableCycle
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue startVertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_8 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_8, 
					$dictvarCal_Core_Prelude_Eq_8 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsReachableCycle
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_8, RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_8, 
					$dictvarCal_Core_Prelude_Eq_8 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsReachableCycle
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_8, RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Is_Just.$instance.f1S(
				Find_Reachable_Cycle.$instance.f3S(
					$dictvarCal_Core_Prelude_Eq_8, 
					graph, 
					startVertex, 
					$ec).evaluate(
					$ec), 
				$ec);
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.existsReachableCycle
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Eq_8, RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = 
			f3S($dictvarCal_Core_Prelude_Eq_8, graph, startVertex, $ec);

		$dictvarCal_Core_Prelude_Eq_8 = null;
		graph = null;
		startVertex = null;
		return $result.evaluate($ec).getBooleanValue();
	}

}
