package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Add_Edges__accumulate_Existing_Edges__11 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Edges__accumulate_Existing_Edges__11 $instance = 
		new Add_Edges__accumulate_Existing_Edges__11();

	private Add_Edges__accumulate_Existing_Edges__11() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addEdges$accumulateExistingEdges$11";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.addEdges$accumulateExistingEdges$11";
	}

	private static final RTValue vertex2$18$def_Lazy(RTValue pair2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pair2.getValue())).getOrdinalFieldValue(
				2);
	}

	private static final RTValue vertex2$18$def_Strict(RTValue pair2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pair2.getValue())).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$accumulateExistingEdges$11
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue pair2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue accum = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue vertex1 = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue existsEdgeFn = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				RTValue.lastRef(vertex1, vertex1 = null), 
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				RTValue.lastRef(pair2.evaluate($ec), pair2 = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$accumulateExistingEdges$11
	 */
	public final RTValue f4L(RTValue existsEdgeFn, RTValue vertex1, RTValue accum, RTValue pair2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				RTValue.lastRef(vertex1, vertex1 = null), 
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				RTValue.lastRef(pair2.evaluate($ec), pair2 = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$accumulateExistingEdges$11
	 */
	public final RTValue f4S(RTValue existsEdgeFn, RTValue vertex1, RTValue accum, RTValue pair2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (existsEdgeFn.f2L(
			vertex1, 
			Add_Edges__accumulate_Existing_Edges__11.vertex2$18$def_Lazy(
				pair2.getValue(), 
				$ec), 
			$ec).evaluate(
			$ec).getBooleanValue()) {
			return new TYPE_List.CAL_Cons(pair2.getValue(), accum.getValue());
		} else {
			return accum.getValue();
		}
	}

}
