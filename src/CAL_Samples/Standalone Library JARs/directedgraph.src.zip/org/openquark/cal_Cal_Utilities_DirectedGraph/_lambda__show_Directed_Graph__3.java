package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Append_String;
import org.openquark.cal_Cal_Core_Prelude.Subtract_Int;
import org.openquark.cal_Cal_Core_Prelude._dict___Num___Int;

public final class _lambda__show_Directed_Graph__3 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_String $L1_String_N = 
		RTData.CAL_String.make("}\n");

	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__show_Directed_Graph__3 $instance = 
		new _lambda__show_Directed_Graph__3();

	private _lambda__show_Directed_Graph__3() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$showDirectedGraph$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$showDirectedGraph$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$showDirectedGraph$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNum = $rootNode.getArgValue();
		RTValue accum = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$showDirectedGraph$3
	 */
	public final RTValue f2L(RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$showDirectedGraph$3
	 */
	public final RTValue f2S(RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)accum.evaluate($ec));
		RTValue indent = $recordCase1.getOrdinalFieldValue(1);
		RTValue text = $recordCase1.getOrdinalFieldValue(2);

		return 
			RTRecordValue.makeTupleRecord(
				new RTValue[] {new RTFullApp.General._2._L(Subtract_Int.$instance, indent, new RTFullApp.General._1._S(Show_Directed_Graph__indent_Diff__3.$instance, _dict___Num___Int.$instance)), new RTFullApp.General._2._L(Append_String.$instance, text, new RTFullApp.General._2._L(Append_String.$instance, new RTFullApp.General._1._S(Show_Directed_Graph__make_Indent_String__4.$instance, new RTFullApp.General._2._L(Subtract_Int.$instance, indent, new RTFullApp.General._1._S(Show_Directed_Graph__indent_Diff__3.$instance, _dict___Num___Int.$instance))), _lambda__show_Directed_Graph__3.$L1_String_N))});
	}

}
