package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Const__;
import org.openquark.cal_Cal_Core_Prelude.Flip;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Topological_Sort extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Topological_Sort $instance = new Topological_Sort();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Cons i_Cons = TYPE_List.CAL_Cons.make();

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Topological_Sort() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "topologicalSort";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.topologicalSort";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.topologicalSort
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_2 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_2, 
					$dictvarCal_Core_Prelude_Eq_2 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.topologicalSort
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_2, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_2, 
					$dictvarCal_Core_Prelude_Eq_2 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.topologicalSort
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_2, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Indices_To_Vertices.$instance.f2S(
				graph, 
				new RTFullApp.General._7._S(
					Fold_D_F_S_Internal.$instance, 
					$dictvarCal_Core_Prelude_Eq_2, 
					Topological_Sort.i_Nothing, 
					Const__.$instance, 
					Const__.$instance, 
					new RTPartialApp._3._1(
						Flip.$instance, 
						Topological_Sort.i_Cons), 
					Topological_Sort.i_Nil, 
					graph), 
				$ec);
	}

}
