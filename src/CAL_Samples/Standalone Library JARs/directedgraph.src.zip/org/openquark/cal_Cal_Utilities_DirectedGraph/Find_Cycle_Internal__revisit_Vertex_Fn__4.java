package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_List.Find_Index;
import org.openquark.cal_Cal_Core_Prelude.Add_Int;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;
import org.openquark.cal_Cal_Core_Prelude.Take;

public final class Find_Cycle_Internal__revisit_Vertex_Fn__4 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_1 = RTData.CAL_Int.make(1);

	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Cycle_Internal__revisit_Vertex_Fn__4 $instance = 
		new Find_Cycle_Internal__revisit_Vertex_Fn__4();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_findCycleInternal_1356_21 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"findCycleInternal", 
			1356, 
			21);

	private Find_Cycle_Internal__revisit_Vertex_Fn__4() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findCycleInternal$revisitVertexFn$4";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.findCycleInternal$revisitVertexFn$4";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal$revisitVertexFn$4
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNum = $rootNode.getArgValue();
		RTValue accum = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal$revisitVertexFn$4
	 */
	public final RTValue f2L(RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal$revisitVertexFn$4
	 */
	public final RTValue f2S(RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)accum.evaluate($ec));
		RTValue path = $recordCase1.getOrdinalFieldValue(1);
		RTValue isCycle = $recordCase1.getOrdinalFieldValue(2);

		if (isCycle.evaluate($ec).getBooleanValue()) {
			return accum;
		} else {
			TYPE_Maybe $case2;

			switch (($case2 = (((TYPE_Maybe)(java.lang.Object)Find_Index.$instance.f2S(new RTPartialApp._2._1(_lambda__find_Cycle_Internal__1.$instance, vertexNum), path.evaluate($ec), $ec).evaluate($ec)))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nothing
					return accum;
				}

				case 1: {
					// Cal.Core.Prelude.Just
					// Decompose data type to access members.
					RTValue index = $case2.get_value();

					return 
						RTRecordValue.makeTupleRecord(
							new RTValue[] {new RTFullApp.General._2._L(Take.$instance, new RTFullApp.General._2._L(Add_Int.$instance, index, Find_Cycle_Internal__revisit_Vertex_Fn__4.$L1_Int_1), path), RTData.CAL_Boolean.make(true)});
				}

				default: {
					return 
						badSwitchIndex(
							Find_Cycle_Internal__revisit_Vertex_Fn__4.Cal_Utilities_DirectedGraph_findCycleInternal_1356_21);
				}
			}
		}
	}

}
