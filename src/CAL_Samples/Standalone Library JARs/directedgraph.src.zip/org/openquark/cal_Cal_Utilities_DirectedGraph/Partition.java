package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.From_List;
import org.openquark.cal_Cal_Collections_IntMap.To_Asc_List;
import org.openquark.cal_Cal_Collections_List.Map_Just;
import org.openquark.cal_Cal_Collections_Set.From_Distinct_Asc_List;
import org.openquark.cal_Cal_Core_Prelude.Compose;
import org.openquark.cal_Cal_Core_Prelude.Fst;
import org.openquark.cal_Cal_Core_Prelude.Map;
import org.openquark.cal_Cal_Core_Prelude.Snd;

public final class Partition extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Partition $instance = new Partition();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_partition_1482_45 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "partition", 1482, 45);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Directed_Graph.CAL_Directed_Graph i_DirectedGraph = 
		TYPE_Directed_Graph.CAL_Directed_Graph.make();

	private Partition() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "partition";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.partition";
	}

	private static final RTValue vertexMap1$14$def_Lazy(RTValue list1, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._1._L(From_List.$instance, list1);
	}

	private static final RTValue vertexMap1$14$def_Strict(RTValue list1, RTExecutionContext $ec) throws CALExecutorException {
		return From_List.$instance.f1S(list1.evaluate($ec), $ec).evaluate($ec);
	}

	private static final RTValue edges2$17$def_Lazy(RTValue edges, RTValue vertexNums1, RTValue vertexNums2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_List.$instance, 
				new RTFullApp.General._2._L(
					Map_Just.$instance, 
					new RTPartialApp._3._2(
						Partition__get_Maybe_Adjacency_Node__13.$instance, 
						edges.getValue(), 
						new RTFullApp.General._1._L(
							From_Distinct_Asc_List.$instance, 
							vertexNums1)), 
					vertexNums2));
	}

	private static final RTValue edges2$17$def_Strict(RTValue edges, RTValue vertexNums1, RTValue vertexNums2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_List.$instance.f1S(
				Map_Just.$instance.f2S(
					new RTPartialApp._3._2(
						Partition__get_Maybe_Adjacency_Node__13.$instance, 
						edges.getValue(), 
						new RTFullApp.General._1._L(
							From_Distinct_Asc_List.$instance, 
							vertexNums1)), 
					vertexNums2.evaluate($ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue vertexMap2$15$def_Lazy(RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._1._L(From_List.$instance, list2);
	}

	private static final RTValue vertexMap2$15$def_Strict(RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		return From_List.$instance.f1S(list2.evaluate($ec), $ec).evaluate($ec);
	}

	private static final RTValue edges1$16$def_Lazy(RTValue edges, RTValue vertexNums2, RTValue vertexNums1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_List.$instance, 
				new RTFullApp.General._2._L(
					Map_Just.$instance, 
					new RTPartialApp._3._2(
						Partition__get_Maybe_Adjacency_Node__13.$instance, 
						edges.getValue(), 
						new RTFullApp.General._1._L(
							From_Distinct_Asc_List.$instance, 
							vertexNums2)), 
					vertexNums1));
	}

	private static final RTValue edges1$16$def_Strict(RTValue edges, RTValue vertexNums2, RTValue vertexNums1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_List.$instance.f1S(
				Map_Just.$instance.f2S(
					new RTPartialApp._3._2(
						Partition__get_Maybe_Adjacency_Node__13.$instance, 
						edges.getValue(), 
						new RTFullApp.General._1._L(
							From_Distinct_Asc_List.$instance, 
							vertexNums2)), 
					vertexNums1.evaluate($ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue graph2$19$def_Lazy(RTValue list2, RTValue edges, RTValue vertexNums1, RTValue vertexNums2, int nextVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Partition.i_DirectedGraph, 
				RTData.CAL_Int.make(nextVertexNum), 
				Partition.vertexMap2$15$def_Lazy(list2, $ec), 
				Partition.edges2$17$def_Lazy(
					edges.getValue(), 
					vertexNums1, 
					vertexNums2, 
					$ec));
	}

	private static final RTValue graph2$19$def_Strict(RTValue list2, RTValue edges, RTValue vertexNums1, RTValue vertexNums2, int nextVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new TYPE_Directed_Graph.CAL_Directed_Graph(
				nextVertexNum, 
				Partition.vertexMap2$15$def_Strict(list2, $ec), 
				Partition.edges2$17$def_Strict(
					edges.getValue(), 
					vertexNums1, 
					vertexNums2, 
					$ec));
	}

	private static final RTValue graph1$18$def_Lazy(RTValue edges, RTValue vertexNums2, RTValue vertexNums1, RTValue list1, int nextVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Partition.i_DirectedGraph, 
				RTData.CAL_Int.make(nextVertexNum), 
				Partition.vertexMap1$14$def_Lazy(list1, $ec), 
				Partition.edges1$16$def_Lazy(
					edges.getValue(), 
					vertexNums2, 
					vertexNums1, 
					$ec));
	}

	private static final RTValue graph1$18$def_Strict(RTValue edges, RTValue vertexNums2, RTValue vertexNums1, RTValue list1, int nextVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new TYPE_Directed_Graph.CAL_Directed_Graph(
				nextVertexNum, 
				Partition.vertexMap1$14$def_Strict(list1, $ec), 
				Partition.edges1$16$def_Strict(
					edges.getValue(), 
					vertexNums2, 
					vertexNums1, 
					$ec));
	}

	private static final RTValue vertexNums2$8$def_Lazy(RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._2._L(Map.$instance, Fst.$instance, list2);
	}

	private static final RTValue vertexNums2$8$def_Strict(RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Map.$instance.f2S(Fst.$instance, list2.evaluate($ec), $ec).evaluate(
				$ec);
	}

	private static final RTValue vertexNums1$7$def_Lazy(RTValue list1, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._2._L(Map.$instance, Fst.$instance, list1);
	}

	private static final RTValue vertexNums1$7$def_Strict(RTValue list1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Map.$instance.f2S(Fst.$instance, list1.evaluate($ec), $ec).evaluate(
				$ec);
	}

	private static final RTValue list2$5$def_Lazy(RTValue pattern_list1_list2, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_list1_list2, 2);
	}

	private static final RTValue list2$5$def_Strict(RTValue pattern_list1_list2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_list1_list2.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue vertexPairs$3$def_Lazy(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				To_Asc_List.$instance, 
				new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
					graph, 
					0, 
					1, 
					Partition.Cal_Utilities_DirectedGraph_partition_1482_45));
	}

	private static final RTValue vertexPairs$3$def_Strict(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			To_Asc_List.$instance.f1S(
				(((RTCons)(java.lang.Object)
					graph.evaluate($ec))).getFieldByIndex(
					0, 
					1, 
					Partition.Cal_Utilities_DirectedGraph_partition_1482_45).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue list1$4$def_Lazy(RTValue pattern_list1_list2, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_list1_list2, 1);
	}

	private static final RTValue list1$4$def_Strict(RTValue pattern_list1_list2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_list1_list2.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_list1_list2$6$def_Lazy(RTValue graph, RTValue partitionFn, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._S(
				org.openquark.cal_Cal_Collections_List.Partition.$instance, 
				new RTPartialApp._3._2(
					Compose.$instance, 
					partitionFn, 
					Snd.$instance), 
				Partition.vertexPairs$3$def_Lazy(graph, $ec));
	}

	private static final RTValue $pattern_list1_list2$6$def_Strict(RTValue graph, RTValue partitionFn, RTExecutionContext $ec) throws CALExecutorException {
		return 
			org.openquark.cal_Cal_Collections_List.Partition.$instance.f2S(
				new RTPartialApp._3._2(
					Compose.$instance, 
					partitionFn, 
					Snd.$instance), 
				Partition.vertexPairs$3$def_Lazy(graph, $ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.partition
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue partitionFn = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_14 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_14, 
					$dictvarCal_Core_Prelude_Eq_14 = null), 
				RTValue.lastRef(partitionFn, partitionFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.partition
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_14, RTValue partitionFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_14, 
					$dictvarCal_Core_Prelude_Eq_14 = null), 
				RTValue.lastRef(partitionFn, partitionFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.partition
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_14, RTValue partitionFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_pattern_list1_list2 = 
			Partition.$pattern_list1_list2$6$def_Lazy(graph, partitionFn, $ec);
		RTValue letVar_list1 = 
			Partition.list1$4$def_Lazy(letVar_pattern_list1_list2, $ec);
		RTValue letVar_list2 = 
			Partition.list2$5$def_Lazy(letVar_pattern_list1_list2, $ec);

		// Top level supercombinator logic

		RTCons $case1 = ((RTCons)(java.lang.Object)graph.evaluate($ec));

		// Cal.Utilities.DirectedGraph.DirectedGraph
		// Decompose data type to access members.
		TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar1 = 
			((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)$case1);

		int nextVertexNum$U = $dcCaseVar1.get_nextVertexNum_As_Int();
		RTValue $_ = $dcCaseVar1.get_vertexMap();
		RTValue edges = $dcCaseVar1.get_edges();
		RTValue letVar_vertexNums1 = 
			Partition.vertexNums1$7$def_Lazy(letVar_list1, $ec);
		RTValue letVar_vertexNums2 = 
			Partition.vertexNums2$8$def_Lazy(letVar_list2, $ec);

		return 
			RTRecordValue.makeTupleRecord(
				new RTValue[] {Partition.graph1$18$def_Lazy(edges, letVar_vertexNums2, letVar_vertexNums1, letVar_list1, nextVertexNum$U, $ec), Partition.graph2$19$def_Lazy(letVar_list2, edges, letVar_vertexNums1, letVar_vertexNums2, nextVertexNum$U, $ec)});
	}

}
