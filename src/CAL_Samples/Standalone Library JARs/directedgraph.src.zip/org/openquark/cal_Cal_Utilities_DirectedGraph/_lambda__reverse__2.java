package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_Set.Fold_R;

public final class _lambda__reverse__2 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__reverse__2 $instance = 
		new _lambda__reverse__2();

	private _lambda__reverse__2() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$reverse$2";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$reverse$2";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$2
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue accum = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue neighbourSet = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue startVertex = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(neighbourSet, neighbourSet = null), 
				RTValue.lastRef(accum, accum = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$2
	 */
	public final RTValue f3L(RTValue startVertex, RTValue neighbourSet, RTValue accum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(neighbourSet, neighbourSet = null), 
				RTValue.lastRef(accum, accum = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$2
	 */
	public final RTValue f3S(RTValue startVertex, RTValue neighbourSet, RTValue accum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Fold_R.RTAppS(
				Fold_R.$instance, 
				new RTPartialApp._3._1(
					_lambda__reverse__1.$instance, 
					startVertex), 
				accum, 
				neighbourSet.evaluate($ec));
	}

}
