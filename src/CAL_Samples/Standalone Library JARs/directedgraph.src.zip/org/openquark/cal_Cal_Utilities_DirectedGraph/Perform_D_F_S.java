package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Perform_D_F_S extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Perform_D_F_S $instance = new Perform_D_F_S();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Perform_D_F_S() {
	}

	public final int getArity() {
		return 7;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "performDFS";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.performDFS";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.performDFS
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue init = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue visited = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue startVertexNum = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue finishVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue revisitVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue startVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue getChildrenFn = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f7S(
				RTValue.lastRef(getChildrenFn, getChildrenFn = null), 
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(revisitVertexFn, revisitVertexFn = null), 
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(startVertexNum, startVertexNum = null), 
				RTValue.lastRef(visited, visited = null), 
				RTValue.lastRef(init, init = null), 
				$ec);
	}

	/**
	 * f7L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.performDFS
	 */
	public final RTValue f7L(RTValue getChildrenFn, RTValue startVertexFn, RTValue revisitVertexFn, RTValue finishVertexFn, RTValue startVertexNum, RTValue visited, RTValue init, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f7S(
				RTValue.lastRef(getChildrenFn, getChildrenFn = null), 
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(revisitVertexFn, revisitVertexFn = null), 
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(startVertexNum, startVertexNum = null), 
				RTValue.lastRef(visited, visited = null), 
				RTValue.lastRef(init, init = null), 
				$ec);
	}

	/**
	 * f7S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.performDFS
	 */
	public final RTValue f7S(RTValue getChildrenFn, RTValue startVertexFn, RTValue revisitVertexFn, RTValue finishVertexFn, RTValue startVertexNum, RTValue visited, RTValue init, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Perform_D_F_S__dfs_Loop__8.RTAppS(
				Perform_D_F_S__dfs_Loop__8.$instance, 
				finishVertexFn, 
				revisitVertexFn, 
				getChildrenFn, 
				startVertexFn, 
				new TYPE_List.CAL_Cons(
					RTRecordValue.makeTupleRecord(
						new RTValue[] {startVertexNum, RTData.CAL_Boolean.make(false)}), 
					Perform_D_F_S.i_Nil), 
				visited.evaluate($ec), 
				init.evaluate($ec));
	}

}
