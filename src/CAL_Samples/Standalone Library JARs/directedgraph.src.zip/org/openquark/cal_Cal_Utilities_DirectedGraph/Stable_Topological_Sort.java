package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.Elems;
import org.openquark.cal_Cal_Collections_IntMap.Keys;
import org.openquark.cal_Cal_Collections_List.Sort;
import org.openquark.cal_Cal_Collections_Set.Difference;
import org.openquark.cal_Cal_Collections_Set.From_Distinct_Asc_List;
import org.openquark.cal_Cal_Collections_Set.TYPE_Set;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Stable_Topological_Sort extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Stable_Topological_Sort $instance = 
		new Stable_Topological_Sort();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_stableTopologicalSort_1098_79 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"stableTopologicalSort", 
			1098, 
			79);

	private static final ErrorInfo Cal_Utilities_DirectedGraph_stableTopologicalSort_1099_88 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"stableTopologicalSort", 
			1099, 
			88);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Stable_Topological_Sort() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "stableTopologicalSort";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.stableTopologicalSort";
	}

	private static final RTValue vertexNumSet$2$def_Lazy(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_Distinct_Asc_List.$instance, 
				(new RTFullApp.General._1._S(
					Sort.$instance, 
					_dict___Ord___Int.$instance)).apply(
					new RTFullApp.General._1._L(
						Keys.$instance, 
						new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
							graph, 
							0, 
							1, 
							Stable_Topological_Sort.Cal_Utilities_DirectedGraph_stableTopologicalSort_1098_79))));
	}

	private static final RTValue vertexNumSet$2$def_Strict(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Distinct_Asc_List.$instance.f1S(
				Sort.$instance.f1S(_dict___Ord___Int.$instance, $ec).evaluate(
					$ec).f1L(
					new RTFullApp.General._1._L(
						Keys.$instance, 
						new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
							graph, 
							0, 
							1, 
							Stable_Topological_Sort.Cal_Utilities_DirectedGraph_stableTopologicalSort_1098_79)), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue reverseGraph$4$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_39, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._S(
				Reverse.$instance, 
				$dictvarCal_Core_Prelude_Eq_39, 
				graph);
	}

	private static final RTValue reverseGraph$4$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_39, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Reverse.$instance.f2S(
				$dictvarCal_Core_Prelude_Eq_39, 
				graph, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue noIncomingSet$3$def_Lazy(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Fold_Left_Strict.$instance, 
				new RTPartialApp._3._1(
					Difference.$instance, 
					_dict___Ord___Int.$instance), 
				Stable_Topological_Sort.vertexNumSet$2$def_Lazy(graph, $ec), 
				new RTFullApp.General._1._L(
					Elems.$instance, 
					new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
						graph, 
						0, 
						2, 
						Stable_Topological_Sort.Cal_Utilities_DirectedGraph_stableTopologicalSort_1099_88)));
	}

	private static final RTValue noIncomingSet$3$def_Strict(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_Left_Strict.$instance.f3S(
				new RTPartialApp._3._1(
					Difference.$instance, 
					_dict___Ord___Int.$instance), 
				Stable_Topological_Sort.vertexNumSet$2$def_Strict(graph, $ec), 
				Elems.$instance.f1S(
					(((RTCons)(java.lang.Object)
						graph.evaluate($ec))).getFieldByIndex(
						0, 
						2, 
						Stable_Topological_Sort.Cal_Utilities_DirectedGraph_stableTopologicalSort_1099_88).evaluate(
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stableTopologicalSort
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_39 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_39, 
					$dictvarCal_Core_Prelude_Eq_39 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stableTopologicalSort
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_39, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_39, 
					$dictvarCal_Core_Prelude_Eq_39 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stableTopologicalSort
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_39, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Indices_To_Vertices.$instance.f2S(
				graph, 
				new Stable_Topological_Sort__sort_Helper__5.RTAppS(
					Stable_Topological_Sort__sort_Helper__5.$instance, 
					Stable_Topological_Sort.reverseGraph$4$def_Lazy(
						$dictvarCal_Core_Prelude_Eq_39, 
						graph, 
						$ec), 
					graph, 
					Stable_Topological_Sort.i_Nil, 
					Stable_Topological_Sort.i_Tip, 
					Stable_Topological_Sort.noIncomingSet$3$def_Lazy(
						graph, 
						$ec)), 
				$ec);
	}

}
