package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Update;
import org.openquark.cal_Cal_Collections_List.Sort;
import org.openquark.cal_Cal_Collections_List.Tail;
import org.openquark.cal_Cal_Collections_Set.From_Distinct_Asc_List;
import org.openquark.cal_Cal_Core_Prelude.Flip;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;
import org.openquark.cal_Cal_Core_Prelude.Zip;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Flatten_Components__flatten_Component__2 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Flatten_Components__flatten_Component__2 $instance = 
		new Flatten_Components__flatten_Component__2();

	private Flatten_Components__flatten_Component__2() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "flattenComponents$flattenComponent$2";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.flattenComponents$flattenComponent$2";
	}

	private static final RTValue componentSet$6$def_Lazy(RTValue sortedComponent, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_Distinct_Asc_List.$instance, 
				sortedComponent);
	}

	private static final RTValue componentSet$6$def_Strict(RTValue sortedComponent, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Distinct_Asc_List.$instance.f1S(
				sortedComponent.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue insertionOrderEdges$9$def_Lazy(RTValue sortedComponent, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Zip.$instance, 
				sortedComponent, 
				new RTFullApp.General._1._L(Tail.$instance, sortedComponent));
	}

	private static final RTValue insertionOrderEdges$9$def_Strict(RTValue sortedComponent, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Zip.$instance.f2S(
				sortedComponent.evaluate($ec), 
				new RTFullApp.General._1._L(Tail.$instance, sortedComponent), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue edges_internalRemoved$10$def_Lazy(RTValue sortedComponent, RTValue oldEdges, RTValue component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new Fold_Left_Strict.RTAppS(
				Fold_Left_Strict.$instance, 
				new RTPartialApp._3._1(
					Flip.$instance, 
					new RTPartialApp._3._1(
						Update.$instance, 
						new RTPartialApp._2._1(
							Flatten_Components__remove_Component_Set__7.$instance, 
							Flatten_Components__flatten_Component__2.componentSet$6$def_Lazy(
								sortedComponent, 
								$ec)))), 
				oldEdges.getValue(), 
				component.getValue());
	}

	private static final RTValue edges_internalRemoved$10$def_Strict(RTValue sortedComponent, RTValue oldEdges, RTValue component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_Left_Strict.$instance.f3S(
				new RTPartialApp._3._1(
					Flip.$instance, 
					new RTPartialApp._3._1(
						Update.$instance, 
						new RTPartialApp._2._1(
							Flatten_Components__remove_Component_Set__7.$instance, 
							Flatten_Components__flatten_Component__2.componentSet$6$def_Lazy(
								sortedComponent, 
								$ec)))), 
				oldEdges.getValue(), 
				component.getValue(), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue edges_insertionOrderAdded$11$def_Lazy(RTValue sortedComponent, RTValue oldEdges, RTValue component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Fold_Left_Strict.$instance, 
				Flatten_Components__insert_Edge__8.$instance, 
				Flatten_Components__flatten_Component__2.edges_internalRemoved$10$def_Lazy(
					sortedComponent, 
					oldEdges.getValue(), 
					component.getValue(), 
					$ec), 
				Flatten_Components__flatten_Component__2.insertionOrderEdges$9$def_Lazy(
					sortedComponent, 
					$ec));
	}

	private static final RTValue edges_insertionOrderAdded$11$def_Strict(RTValue sortedComponent, RTValue oldEdges, RTValue component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_Left_Strict.$instance.f3S(
				Flatten_Components__insert_Edge__8.$instance, 
				Flatten_Components__flatten_Component__2.edges_internalRemoved$10$def_Strict(
					sortedComponent, 
					oldEdges.getValue(), 
					component.getValue(), 
					$ec), 
				Flatten_Components__flatten_Component__2.insertionOrderEdges$9$def_Strict(
					sortedComponent, 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue sortedComponent$5$def_Lazy(RTValue component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(new RTFullApp.General._1._S(
				Sort.$instance, 
				_dict___Ord___Int.$instance)).apply(
				component.getValue());
	}

	private static final RTValue sortedComponent$5$def_Strict(RTValue component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Sort.$instance.f1S(_dict___Ord___Int.$instance, $ec).evaluate(
				$ec).f1L(
				component.getValue(), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$flattenComponent$2
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue component = $rootNode.getArgValue();
		RTValue oldEdges = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(oldEdges.evaluate($ec), oldEdges = null), 
				RTValue.lastRef(component.evaluate($ec), component = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$flattenComponent$2
	 */
	public final RTValue f2L(RTValue oldEdges, RTValue component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(oldEdges.evaluate($ec), oldEdges = null), 
				RTValue.lastRef(component.evaluate($ec), component = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$flattenComponent$2
	 */
	public final RTValue f2S(RTValue oldEdges, RTValue component, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Flatten_Components__flatten_Component__2.edges_insertionOrderAdded$11$def_Lazy(
				Flatten_Components__flatten_Component__2.sortedComponent$5$def_Lazy(
					component.getValue(), 
					$ec), 
				oldEdges.getValue(), 
				component.getValue(), 
				$ec);
	}

}
