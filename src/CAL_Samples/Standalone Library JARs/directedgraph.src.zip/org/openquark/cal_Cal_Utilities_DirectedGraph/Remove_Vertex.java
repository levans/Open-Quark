package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.Delete;
import org.openquark.cal_Cal_Collections_IntMap.Map;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Remove_Vertex extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Remove_Vertex $instance = new Remove_Vertex();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_removeVertex_445_5 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "removeVertex", 445, 5);

	private Remove_Vertex() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "removeVertex";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.removeVertex";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeVertex
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue oldGraph = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_21 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_21, 
					$dictvarCal_Core_Prelude_Eq_21 = null), 
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeVertex
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_21, RTValue oldGraph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_21, 
					$dictvarCal_Core_Prelude_Eq_21 = null), 
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeVertex
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_21, RTValue oldGraph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)Get_Maybe_Vertex_Number.$instance.f3S($dictvarCal_Core_Prelude_Eq_21, oldGraph, vertex, $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return oldGraph;
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue vertexNum = $case1.get_value();


				RTCons $case2 = 
					((RTCons)(java.lang.Object)oldGraph.evaluate($ec));

				// Cal.Utilities.DirectedGraph.DirectedGraph
				// Decompose data type to access members.
				TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar2 = 
					((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)
						$case2);

				int nextVertexNum$U = $dcCaseVar2.get_nextVertexNum_As_Int();
				RTValue oldVertexMap = $dcCaseVar2.get_vertexMap();
				RTValue oldEdges = $dcCaseVar2.get_edges();

				return 
					new TYPE_Directed_Graph.CAL_Directed_Graph(
						nextVertexNum$U, 
						Delete.$instance.f2S(
							vertexNum.evaluate($ec).getOrdinalValue(), 
							oldVertexMap, 
							$ec).evaluate(
							$ec), 
						Map.$instance.f2S(
							new RTPartialApp._3._2(
								org.openquark.cal_Cal_Collections_Set.Delete.$instance, 
								_dict___Ord___Int.$instance, 
								vertexNum), 
							Delete.$instance.f2S(
								vertexNum.evaluate($ec).getOrdinalValue(), 
								oldEdges, 
								$ec).evaluate(
								$ec), 
							$ec).evaluate(
							$ec));
			}

			default: {
				return 
					badSwitchIndex(
						Remove_Vertex.Cal_Utilities_DirectedGraph_removeVertex_445_5);
			}
		}
	}

}
