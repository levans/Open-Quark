package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTDeepSeq;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.Keys;
import org.openquark.cal_Cal_Collections_Set.TYPE_Set;
import org.openquark.cal_Cal_Core_Debug.Show_Internal;
import org.openquark.cal_Cal_Core_Debug.Trace;
import org.openquark.cal_Cal_Core_Prelude.Append_String;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Fold_D_F_S_Internal extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_String $L1_String_Folddfsinternal_InvalidStartNode = 
		RTData.CAL_String.make("foldDFSInternal: Invalid start node\n");

	private static final RTData.CAL_String $L2_String_NinGraphN = 
		RTData.CAL_String.make("\nin graph\n");

	private static final RTData.CAL_String $L3_String_N = 
		RTData.CAL_String.make("\n");

	/**
	 * Singleton instance of this class.
	 */
	public static final Fold_D_F_S_Internal $instance = 
		new Fold_D_F_S_Internal();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_foldDFSInternal_979_9 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "foldDFSInternal", 979, 9);

	private static final ErrorInfo Cal_Utilities_DirectedGraph_foldDFSInternal_980_61 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "foldDFSInternal", 980, 61);

	private static final ErrorInfo Cal_Utilities_DirectedGraph_foldDFSInternal_982_13 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "foldDFSInternal", 982, 13);

	private static final ErrorInfo Cal_Utilities_DirectedGraph_foldDFSInternal_992_43 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "foldDFSInternal", 992, 43);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Fold_D_F_S_Internal() {
	}

	public final int getArity() {
		return 7;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "foldDFSInternal";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.foldDFSInternal";
	}

	private static final RTValue message$23$def_Lazy(RTValue startVertex, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Append_String.$instance, 
				Fold_D_F_S_Internal.$L1_String_Folddfsinternal_InvalidStartNode, 
				new RTFullApp.General._2._L(
					Append_String.$instance, 
					new RTFullApp.General._2._L(
						RTDeepSeq.$instance, 
						startVertex, 
						new RTFullApp.General._1._S(
							Show_Internal.$instance, 
							startVertex)), 
					new RTFullApp.General._2._L(
						Append_String.$instance, 
						Fold_D_F_S_Internal.$L2_String_NinGraphN, 
						new RTFullApp.General._2._L(
							Append_String.$instance, 
							new RTFullApp.General._2._L(
								RTDeepSeq.$instance, 
								graph, 
								new RTFullApp.General._1._S(
									Show_Internal.$instance, 
									graph)), 
							Fold_D_F_S_Internal.$L3_String_N))));
	}

	private static final RTValue message$23$def_Strict(RTValue startVertex, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			RTData.CAL_String.make(
				"foldDFSInternal: Invalid start node\n".concat(
					RTDeepSeq.$instance.f2S(
						startVertex.evaluate($ec), 
						new RTFullApp.General._1._S(
							Show_Internal.$instance, 
							startVertex), 
						$ec).evaluate(
						$ec).getStringValue().concat(
						"\nin graph\n".concat(
							RTDeepSeq.$instance.f2S(
								graph.evaluate($ec), 
								new RTFullApp.General._1._S(
									Show_Internal.$instance, 
									graph), 
								$ec).evaluate(
								$ec).getStringValue().concat(
								"\n")))));
	}

	private static final java.lang.String message$23$def_Unboxed(RTValue startVertex, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			"foldDFSInternal: Invalid start node\n".concat(
				RTDeepSeq.$instance.f2S(
					startVertex.evaluate($ec), 
					new RTFullApp.General._1._S(
						Show_Internal.$instance, 
						startVertex), 
					$ec).evaluate(
					$ec).getStringValue().concat(
					"\nin graph\n".concat(
						RTDeepSeq.$instance.f2S(
							graph.evaluate($ec), 
							new RTFullApp.General._1._S(
								Show_Internal.$instance, 
								graph), 
							$ec).evaluate(
							$ec).getStringValue().concat(
							"\n"))));
	}

	private static final RTValue dfsHelper$7$def_Lazy(RTValue graph, RTValue startVertexFn, RTValue revisitVertexFn, RTValue finishVertexFn, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTPartialApp._7._4(
				Perform_D_F_S.$instance, 
				new RTPartialApp._2._1(Get_Neighbour_List.$instance, graph), 
				startVertexFn, 
				revisitVertexFn, 
				finishVertexFn);
	}

	private static final RTValue dfsHelper$7$def_Strict(RTValue graph, RTValue startVertexFn, RTValue revisitVertexFn, RTValue finishVertexFn, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTPartialApp._7._4(
				Perform_D_F_S.$instance, 
				new RTPartialApp._2._1(Get_Neighbour_List.$instance, graph), 
				startVertexFn, 
				revisitVertexFn, 
				finishVertexFn);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue init = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue finishVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue revisitVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue startVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue maybeStartVertex = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_1 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f7S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_1, 
					$dictvarCal_Core_Prelude_Eq_1 = null), 
				RTValue.lastRef(maybeStartVertex, maybeStartVertex = null), 
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(revisitVertexFn, revisitVertexFn = null), 
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(init, init = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f7L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal
	 */
	public final RTValue f7L(RTValue $dictvarCal_Core_Prelude_Eq_1, RTValue maybeStartVertex, RTValue startVertexFn, RTValue revisitVertexFn, RTValue finishVertexFn, RTValue init, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f7S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_1, 
					$dictvarCal_Core_Prelude_Eq_1 = null), 
				RTValue.lastRef(maybeStartVertex, maybeStartVertex = null), 
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(revisitVertexFn, revisitVertexFn = null), 
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(init, init = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f7S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal
	 */
	public final RTValue f7S(RTValue $dictvarCal_Core_Prelude_Eq_1, RTValue maybeStartVertex, RTValue startVertexFn, RTValue revisitVertexFn, RTValue finishVertexFn, RTValue init, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)maybeStartVertex.evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return 
					new Fold_D_F_S_Internal__dfs_All__9.RTAppS(
						Fold_D_F_S_Internal__dfs_All__9.$instance, 
						Fold_D_F_S_Internal.dfsHelper$7$def_Lazy(
							graph, 
							startVertexFn, 
							revisitVertexFn, 
							finishVertexFn, 
							$ec), 
						Fold_D_F_S_Internal.i_Tip, 
						init.evaluate($ec), 
						Keys.$instance.f1S(
							(((RTCons)(java.lang.Object)
								graph.evaluate($ec))).getFieldByIndex(
								0, 
								1, 
								Fold_D_F_S_Internal.Cal_Utilities_DirectedGraph_foldDFSInternal_980_61).evaluate(
								$ec), 
							$ec).evaluate(
							$ec));
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue startVertex = $case1.get_value();

				TYPE_Maybe $case2;

				switch (($case2 = (((TYPE_Maybe)(java.lang.Object)Get_Maybe_Vertex_Number.$instance.f3S($dictvarCal_Core_Prelude_Eq_1, graph, startVertex, $ec).evaluate($ec)))).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.Nothing
						return 
							Trace.$instance.f1S(
								Fold_D_F_S_Internal.message$23$def_Unboxed(
									startVertex, 
									graph, 
									$ec), 
								$ec).evaluate(
								$ec).apply(
								new RTError.RTAppS(
									RTError.$instance, 
									RTData.CAL_Opaque.make(
										Fold_D_F_S_Internal.Cal_Utilities_DirectedGraph_foldDFSInternal_992_43), 
									"Invalid start node."));
					}

					case 1: {
						// Cal.Core.Prelude.Just
						// Decompose data type to access members.
						RTValue startVertexNum = $case2.get_value();

						return 
							Fold_D_F_S_Internal__dfs_Reachable__8.$instance.f3S(
								Fold_D_F_S_Internal.dfsHelper$7$def_Lazy(
									graph, 
									startVertexFn, 
									revisitVertexFn, 
									finishVertexFn, 
									$ec), 
								init, 
								startVertexNum.evaluate($ec).getOrdinalValue(), 
								$ec);
					}

					default: {
						return 
							badSwitchIndex(
								Fold_D_F_S_Internal.Cal_Utilities_DirectedGraph_foldDFSInternal_982_13);
					}
				}
			}

			default: {
				return 
					badSwitchIndex(
						Fold_D_F_S_Internal.Cal_Utilities_DirectedGraph_foldDFSInternal_979_9);
			}
		}
	}

}
