package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.From_List;
import org.openquark.cal_Cal_Collections_IntMap.TYPE_Int_Map;
import org.openquark.cal_Cal_Core_Prelude.Length;
import org.openquark.cal_Cal_Core_Prelude.Up_From_Int;
import org.openquark.cal_Cal_Core_Prelude.Zip;

public final class Edgeless_Graph extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Edgeless_Graph $instance = new Edgeless_Graph();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Int_Map.CAL_Nil i_Nil = 
		TYPE_Int_Map.CAL_Nil.make();

	private Edgeless_Graph() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "edgelessGraph";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.edgelessGraph";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.edgelessGraph
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertices = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_12 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_12, 
					$dictvarCal_Core_Prelude_Eq_12 = null), 
				RTValue.lastRef(vertices, vertices = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.edgelessGraph
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_12, RTValue vertices, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_12, 
					$dictvarCal_Core_Prelude_Eq_12 = null), 
				RTValue.lastRef(vertices, vertices = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.edgelessGraph
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_12, RTValue vertices, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new TYPE_Directed_Graph.CAL_Directed_Graph(
				Length.$instance.fUnboxed1S(vertices.evaluate($ec), $ec), 
				From_List.$instance.f1S(
					Zip.$instance.f2S(
						Up_From_Int.$instance.f1S(0, $ec).evaluate($ec), 
						vertices, 
						$ec).evaluate(
						$ec), 
					$ec).evaluate(
					$ec), 
				Edgeless_Graph.i_Nil);
	}

}
