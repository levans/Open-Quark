package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_Set.Member;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Contains_Edge_Internal extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Contains_Edge_Internal $instance = 
		new Contains_Edge_Internal();

	private Contains_Edge_Internal() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "containsEdgeInternal";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.containsEdgeInternal";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsEdgeInternal
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue endVertexNum = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue startVertexNum = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue graph = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_22 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_22, 
					$dictvarCal_Core_Prelude_Eq_22 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertexNum, startVertexNum = null), 
				RTValue.lastRef(endVertexNum, endVertexNum = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsEdgeInternal
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Prelude_Eq_22, RTValue graph, RTValue startVertexNum, RTValue endVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_22, 
					$dictvarCal_Core_Prelude_Eq_22 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertexNum, startVertexNum = null), 
				RTValue.lastRef(endVertexNum, endVertexNum = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsEdgeInternal
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Prelude_Eq_22, RTValue graph, RTValue startVertexNum, RTValue endVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Member.RTAppS(
				Member.$instance, 
				_dict___Ord___Int.$instance, 
				endVertexNum.evaluate($ec), 
				Get_Neighbour_Set.$instance.f2S(
					graph, 
					startVertexNum, 
					$ec).evaluate(
					$ec));
	}

	/**
	 * fUnboxed4S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.containsEdgeInternal
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed4S(RTValue $dictvarCal_Core_Prelude_Eq_22, RTValue graph, RTValue startVertexNum, RTValue endVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(new Member.RTAppS(
				Member.$instance, 
				_dict___Ord___Int.$instance, 
				endVertexNum.evaluate($ec), 
				Get_Neighbour_Set.$instance.f2S(
					graph, 
					startVertexNum, 
					$ec).evaluate(
					$ec))).evaluate(
				$ec).getBooleanValue();
	}

}
