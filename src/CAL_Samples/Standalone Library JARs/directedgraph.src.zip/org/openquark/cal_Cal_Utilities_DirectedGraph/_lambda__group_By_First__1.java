package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Head;
import org.openquark.cal_Cal_Collections_List.Unzip;

public final class _lambda__group_By_First__1 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__group_By_First__1 $instance = 
		new _lambda__group_By_First__1();

	private _lambda__group_By_First__1() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$groupByFirst$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$groupByFirst$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$groupByFirst$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue group = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(group, group = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$groupByFirst$1
	 */
	public final RTValue f1L(RTValue group, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(group, group = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$groupByFirst$1
	 */
	public final RTValue f1S(RTValue group, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTRecordValue.makeTupleRecord(
				new RTValue[] {new RTRecordSelection.Ordinal(new RTFullApp.General._1._L(Head.$instance, group), 1), new RTRecordSelection.Ordinal(new RTFullApp.General._1._L(Unzip.$instance, group), 2)});
	}

}
