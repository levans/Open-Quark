package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Reverse;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find_Cycle_Internal extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Cycle_Internal $instance = 
		new Find_Cycle_Internal();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Find_Cycle_Internal() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findCycleInternal";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.findCycleInternal";
	}

	private static final RTValue isCycle$7$def_Lazy(RTValue pattern_path_isCycle, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_path_isCycle, 2);
	}

	private static final RTValue isCycle$7$def_Strict(RTValue pattern_path_isCycle, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_path_isCycle.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final boolean isCycle$7$def_Unboxed(RTValue pattern_path_isCycle, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_path_isCycle.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec).getBooleanValue();
	}

	private static final RTValue path$6$def_Lazy(RTValue pattern_path_isCycle, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_path_isCycle, 1);
	}

	private static final RTValue path$6$def_Strict(RTValue pattern_path_isCycle, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_path_isCycle.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_path_isCycle$8$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_6, RTValue maybeStartVertex, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._7._S(
				Fold_D_F_S_Internal.$instance, 
				$dictvarCal_Core_Prelude_Eq_6, 
				maybeStartVertex, 
				Find_Cycle_Internal__start_Vertex_Fn__3.$instance, 
				Find_Cycle_Internal__revisit_Vertex_Fn__4.$instance, 
				Find_Cycle_Internal__finish_Vertex_Fn__5.$instance, 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {Find_Cycle_Internal.i_Nil, RTData.CAL_Boolean.make(false)}), 
				graph);
	}

	private static final RTValue $pattern_path_isCycle$8$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_6, RTValue maybeStartVertex, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_D_F_S_Internal.$instance.f7S(
				$dictvarCal_Core_Prelude_Eq_6, 
				maybeStartVertex, 
				Find_Cycle_Internal__start_Vertex_Fn__3.$instance, 
				Find_Cycle_Internal__revisit_Vertex_Fn__4.$instance, 
				Find_Cycle_Internal__finish_Vertex_Fn__5.$instance, 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {Find_Cycle_Internal.i_Nil, RTData.CAL_Boolean.make(false)}), 
				graph, 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue maybeStartVertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_6 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_6, 
					$dictvarCal_Core_Prelude_Eq_6 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(maybeStartVertex, maybeStartVertex = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_6, RTValue graph, RTValue maybeStartVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_6, 
					$dictvarCal_Core_Prelude_Eq_6 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(maybeStartVertex, maybeStartVertex = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_6, RTValue graph, RTValue maybeStartVertex, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_pattern_path_isCycle = 
			Find_Cycle_Internal.$pattern_path_isCycle$8$def_Lazy(
				$dictvarCal_Core_Prelude_Eq_6, 
				maybeStartVertex, 
				graph, 
				$ec);

		// Top level supercombinator logic
		if (Find_Cycle_Internal.isCycle$7$def_Unboxed(
			letVar_pattern_path_isCycle, 
			$ec)) {
			return 
				new TYPE_Maybe.CAL_Just(
					new RTFullApp.General._1._L(
						Reverse.$instance, 
						new RTFullApp.General._2._S(
							Indices_To_Vertices.$instance, 
							graph, 
							Find_Cycle_Internal.path$6$def_Lazy(
								letVar_pattern_path_isCycle, 
								$ec))));
		} else {
			return Find_Cycle_Internal.i_Nothing;
		}
	}

}
