package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Make_Predicate_Graph extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Make_Predicate_Graph $instance = 
		new Make_Predicate_Graph();

	private Make_Predicate_Graph() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "makePredicateGraph";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.makePredicateGraph";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.makePredicateGraph
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue existsEdgeFn = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue vertices = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_30 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_30, 
					$dictvarCal_Core_Prelude_Eq_30 = null), 
				RTValue.lastRef(vertices, vertices = null), 
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.makePredicateGraph
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_30, RTValue vertices, RTValue existsEdgeFn, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_30, 
					$dictvarCal_Core_Prelude_Eq_30 = null), 
				RTValue.lastRef(vertices, vertices = null), 
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.makePredicateGraph
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_30, RTValue vertices, RTValue existsEdgeFn, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Add_Edges.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_30, 
				new RTFullApp.General._2._S(
					Edgeless_Graph.$instance, 
					$dictvarCal_Core_Prelude_Eq_30, 
					vertices), 
				existsEdgeFn, 
				$ec);
	}

}
