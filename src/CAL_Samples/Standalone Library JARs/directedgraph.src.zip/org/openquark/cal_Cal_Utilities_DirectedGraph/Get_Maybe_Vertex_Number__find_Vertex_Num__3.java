package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Get_Maybe_Vertex_Number__find_Vertex_Num__3 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Maybe_Vertex_Number__find_Vertex_Num__3 $instance = 
		new Get_Maybe_Vertex_Number__find_Vertex_Num__3();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Get_Maybe_Vertex_Number__find_Vertex_Num__3() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getMaybeVertexNumber$findVertexNum$3";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.getMaybeVertexNumber$findVertexNum$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getMaybeVertexNumber$findVertexNum$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue pair = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue result = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue vertex = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_0 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_0, 
					$dictvarCal_Core_Prelude_Eq_0 = null), 
				RTValue.lastRef(vertex, vertex = null), 
				RTValue.lastRef(result.evaluate($ec), result = null), 
				RTValue.lastRef(pair.evaluate($ec), pair = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getMaybeVertexNumber$findVertexNum$3
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Prelude_Eq_0, RTValue vertex, RTValue result, RTValue pair, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_0, 
					$dictvarCal_Core_Prelude_Eq_0 = null), 
				RTValue.lastRef(vertex, vertex = null), 
				RTValue.lastRef(result.evaluate($ec), result = null), 
				RTValue.lastRef(pair.evaluate($ec), pair = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getMaybeVertexNumber$findVertexNum$3
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Prelude_Eq_0, RTValue vertex, RTValue result, RTValue pair, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (Is_Just.$instance.fUnboxed1S(result.getValue(), $ec)) {
			return result.getValue();
		} else {

			RTRecordValue $recordCase2 = 
				((RTRecordValue)(java.lang.Object)pair.getValue());
			RTValue key = $recordCase2.getOrdinalFieldValue(1);
			RTValue val = $recordCase2.getOrdinalFieldValue(2);

			if ((new RTOApp3(
				$dictvarCal_Core_Prelude_Eq_0, 
				Get_Maybe_Vertex_Number__find_Vertex_Num__3.$L1_Int_0, 
				val, 
				vertex)).evaluate(
				$ec).getBooleanValue()) {
				return new TYPE_Maybe.CAL_Just(key);
			} else {
				return Get_Maybe_Vertex_Number__find_Vertex_Num__3.i_Nothing;
			}
		}
	}

}
