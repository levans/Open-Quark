package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Merge_Vertices_Internal__update_Vertex2_Fn__17 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Merge_Vertices_Internal__update_Vertex2_Fn__17 $instance = 
		new Merge_Vertices_Internal__update_Vertex2_Fn__17();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Merge_Vertices_Internal__update_Vertex2_Fn__17() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mergeVerticesInternal$updateVertex2Fn$17";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.mergeVerticesInternal$updateVertex2Fn$17";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$updateVertex2Fn$17
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue destSet = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(destSet, destSet = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$updateVertex2Fn$17
	 */
	public final RTValue f1L(RTValue destSet, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(destSet, destSet = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$updateVertex2Fn$17
	 */
	public final RTValue f1S(RTValue destSet, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return Merge_Vertices_Internal__update_Vertex2_Fn__17.i_Nothing;
	}

}
