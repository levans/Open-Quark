package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class _lambda__equals_Directed_Graph_Ignore_Insertion_Order__1 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__equals_Directed_Graph_Ignore_Insertion_Order__1 $instance = 
		new _lambda__equals_Directed_Graph_Ignore_Insertion_Order__1();

	private _lambda__equals_Directed_Graph_Ignore_Insertion_Order__1() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$equalsDirectedGraphIgnoreInsertionOrder$1";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.$lambda$equalsDirectedGraphIgnoreInsertionOrder$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$equalsDirectedGraphIgnoreInsertionOrder$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue num2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph2 = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue vertexNumPerm = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue graph1 = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(graph1, graph1 = null), 
				RTValue.lastRef(
					vertexNumPerm.evaluate($ec), 
					vertexNumPerm = null), 
				RTValue.lastRef(graph2, graph2 = null), 
				RTValue.lastRef(num2, num2 = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$equalsDirectedGraphIgnoreInsertionOrder$1
	 */
	public final RTValue f4L(RTValue graph1, RTValue vertexNumPerm, RTValue graph2, RTValue num2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(graph1, graph1 = null), 
				RTValue.lastRef(
					vertexNumPerm.evaluate($ec), 
					vertexNumPerm = null), 
				RTValue.lastRef(graph2, graph2 = null), 
				RTValue.lastRef(num2, num2 = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$equalsDirectedGraphIgnoreInsertionOrder$1
	 */
	public final RTValue f4S(RTValue graph1, RTValue vertexNumPerm, RTValue graph2, RTValue num2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Equals_Directed_Graph_Ignore_Insertion_Order__same_Neighbours__13.$instance.f5S(
				graph1, 
				vertexNumPerm.getValue(), 
				graph2, 
				new RTFullApp.General._2._S(
					Equals_Directed_Graph_Ignore_Insertion_Order__translate_Num2__12.$instance, 
					vertexNumPerm.getValue(), 
					num2), 
				num2, 
				$ec);
	}

	/**
	 * fUnboxed4S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$equalsDirectedGraphIgnoreInsertionOrder$1
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed4S(RTValue graph1, RTValue vertexNumPerm, RTValue graph2, RTValue num2, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = f4S(graph1, vertexNumPerm, graph2, num2, $ec);

		graph1 = null;
		vertexNumPerm = null;
		graph2 = null;
		num2 = null;
		return $result.evaluate($ec).getBooleanValue();
	}

}
