package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_Set.To_Asc_List;

public final class Get_Neighbour_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Neighbour_List $instance = new Get_Neighbour_List();

	private Get_Neighbour_List() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getNeighbourList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.getNeighbourList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbourList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue startVertexNum = $rootNode.getArgValue();
		RTValue graph = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertexNum, startVertexNum = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbourList
	 */
	public final RTValue f2L(RTValue graph, RTValue startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertexNum, startVertexNum = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbourList
	 */
	public final RTValue f2S(RTValue graph, RTValue startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			To_Asc_List.$instance.f1S(
				Get_Neighbour_Set.$instance.f2S(
					graph, 
					startVertexNum, 
					$ec).evaluate(
					$ec), 
				$ec);
	}

}
