package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.To_Asc_List;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;

public final class Add_Edges extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Edges $instance = new Add_Edges();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_addEdges_315_45 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "addEdges", 315, 45);

	private Add_Edges() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addEdges";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.addEdges";
	}

	private static final RTValue vertexPairs$3$def_Lazy(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				To_Asc_List.$instance, 
				new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
					graph, 
					0, 
					1, 
					Add_Edges.Cal_Utilities_DirectedGraph_addEdges_315_45));
	}

	private static final RTValue vertexPairs$3$def_Strict(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			To_Asc_List.$instance.f1S(
				(((RTCons)(java.lang.Object)
					graph.evaluate($ec))).getFieldByIndex(
					0, 
					1, 
					Add_Edges.Cal_Utilities_DirectedGraph_addEdges_315_45).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue existsEdgeFn = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_29 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_29, 
					$dictvarCal_Core_Prelude_Eq_29 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_29, RTValue graph, RTValue existsEdgeFn, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_29, 
					$dictvarCal_Core_Prelude_Eq_29 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_29, RTValue graph, RTValue existsEdgeFn, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_vertexPairs = 
			Add_Edges.vertexPairs$3$def_Lazy(graph, $ec);

		// Top level supercombinator logic
		return 
			new Fold_Left_Strict.RTAppS(
				Fold_Left_Strict.$instance, 
				new RTPartialApp._4._2(
					Add_Edges__add_New_Endpoints_For_Vertex__4.$instance, 
					existsEdgeFn, 
					letVar_vertexPairs), 
				graph.evaluate($ec), 
				letVar_vertexPairs.evaluate($ec));
	}

}
