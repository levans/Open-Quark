package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;

public final class Exists_Path extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Exists_Path $instance = new Exists_Path();

	private Exists_Path() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "existsPath";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.existsPath";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsPath
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue endVertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue startVertex = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue graph = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_19 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_19, 
					$dictvarCal_Core_Prelude_Eq_19 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(endVertex, endVertex = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsPath
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Prelude_Eq_19, RTValue graph, RTValue startVertex, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_19, 
					$dictvarCal_Core_Prelude_Eq_19 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(endVertex, endVertex = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsPath
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Prelude_Eq_19, RTValue graph, RTValue startVertex, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Is_Just.$instance.f1S(
				Find_Path.$instance.f4S(
					$dictvarCal_Core_Prelude_Eq_19, 
					graph, 
					startVertex, 
					endVertex, 
					$ec).evaluate(
					$ec), 
				$ec);
	}

	/**
	 * fUnboxed4S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.existsPath
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed4S(RTValue $dictvarCal_Core_Prelude_Eq_19, RTValue graph, RTValue startVertex, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = 
			f4S(
				$dictvarCal_Core_Prelude_Eq_19, 
				graph, 
				startVertex, 
				endVertex, 
				$ec);

		$dictvarCal_Core_Prelude_Eq_19 = null;
		graph = null;
		startVertex = null;
		endVertex = null;
		return $result.evaluate($ec).getBooleanValue();
	}

}
