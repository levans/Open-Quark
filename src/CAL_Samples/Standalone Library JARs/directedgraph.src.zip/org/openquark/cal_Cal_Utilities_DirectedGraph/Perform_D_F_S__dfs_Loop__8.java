package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_Set.Insert;
import org.openquark.cal_Cal_Collections_Set.Member;
import org.openquark.cal_Cal_Core_Prelude.Append_List;
import org.openquark.cal_Cal_Core_Prelude.Repeat;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.Zip;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Perform_D_F_S__dfs_Loop__8 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Perform_D_F_S__dfs_Loop__8 $instance = 
		new Perform_D_F_S__dfs_Loop__8();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_performDFS_1015_13 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "performDFS", 1015, 13);

	private Perform_D_F_S__dfs_Loop__8() {
	}

	public final int getArity() {
		return 7;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "performDFS$dfsLoop$8";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.performDFS$dfsLoop$8";
	}

	private static final RTValue newAccum$19$def_Lazy(RTValue startVertexFn, RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return startVertexFn.apply(accum.getValue(), vertexNum);
	}

	private static final RTValue newAccum$19$def_Strict(RTValue startVertexFn, RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return startVertexFn.f2L(accum.getValue(), vertexNum, $ec).evaluate($ec);
	}

	private static final RTValue children$16$def_Lazy(RTValue getChildrenFn, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return getChildrenFn.apply(vertexNum);
	}

	private static final RTValue children$16$def_Strict(RTValue getChildrenFn, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return getChildrenFn.f1L(vertexNum, $ec).evaluate($ec);
	}

	private static final RTValue newVisited$18$def_Lazy(RTValue vertexNum, RTValue visited, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Insert.$instance, 
				_dict___Ord___Int.$instance, 
				vertexNum, 
				visited.getValue());
	}

	private static final RTValue newVisited$18$def_Strict(RTValue vertexNum, RTValue visited, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Insert.$instance.f3S(
				_dict___Ord___Int.$instance, 
				vertexNum, 
				visited.getValue(), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue newStack$17$def_Lazy(RTValue getChildrenFn, RTValue vertexNum, RTValue stackBottom, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Append_List.$instance, 
				new RTFullApp.General._2._L(
					Zip.$instance, 
					Perform_D_F_S__dfs_Loop__8.children$16$def_Lazy(
						getChildrenFn, 
						vertexNum, 
						$ec), 
					new RTFullApp.General._1._S(
						Repeat.$instance, 
						RTData.CAL_Boolean.make(false))), 
				new TYPE_List.CAL_Cons(
					RTRecordValue.makeTupleRecord(
						new RTValue[] {vertexNum, RTData.CAL_Boolean.make(true)}), 
					stackBottom));
	}

	private static final RTValue newStack$17$def_Strict(RTValue getChildrenFn, RTValue vertexNum, RTValue stackBottom, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Append_List.$instance.f2S(
				Zip.$instance.f2S(
					Perform_D_F_S__dfs_Loop__8.children$16$def_Strict(
						getChildrenFn, 
						vertexNum, 
						$ec), 
					new RTFullApp.General._1._S(
						Repeat.$instance, 
						RTData.CAL_Boolean.make(false)), 
					$ec).evaluate(
					$ec), 
				new TYPE_List.CAL_Cons(
					RTRecordValue.makeTupleRecord(
						new RTValue[] {vertexNum, RTData.CAL_Boolean.make(true)}), 
					stackBottom), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.performDFS$dfsLoop$8
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue accum = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue visited = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue stack = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue startVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue getChildrenFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue revisitVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue finishVertexFn = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f7S(
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(revisitVertexFn, revisitVertexFn = null), 
				RTValue.lastRef(getChildrenFn, getChildrenFn = null), 
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(stack.evaluate($ec), stack = null), 
				RTValue.lastRef(visited.evaluate($ec), visited = null), 
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				$ec);
	}

	/**
	 * f7L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.performDFS$dfsLoop$8
	 */
	public final RTValue f7L(RTValue finishVertexFn, RTValue revisitVertexFn, RTValue getChildrenFn, RTValue startVertexFn, RTValue stack, RTValue visited, RTValue accum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f7S(
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(revisitVertexFn, revisitVertexFn = null), 
				RTValue.lastRef(getChildrenFn, getChildrenFn = null), 
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(stack.evaluate($ec), stack = null), 
				RTValue.lastRef(visited.evaluate($ec), visited = null), 
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				$ec);
	}

	/**
	 * f7S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.performDFS$dfsLoop$8
	 */
	public final RTValue f7S(RTValue finishVertexFn, RTValue revisitVertexFn, RTValue getChildrenFn, RTValue startVertexFn, RTValue stack, RTValue visited, RTValue accum, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)stack.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return 
						RTRecordValue.makeTupleRecord(
							new RTValue[] {visited.getValue(), accum.getValue()});
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue stackTop = $case1.get_head();
					RTValue stackBottom = $case1.get_tail();


					RTRecordValue $recordCase2 = 
						((RTRecordValue)(java.lang.Object)
							stackTop.evaluate($ec));
					RTValue vertexNum = 
						$recordCase2.getOrdinalFieldValue(1);
					RTValue finished = $recordCase2.getOrdinalFieldValue(2);

					if (finished.evaluate($ec).getBooleanValue()) {
						stack = stackBottom.evaluate($ec);
							accum = 
							finishVertexFn.f2L(
								accum.getValue(), 
								vertexNum, 
								$ec).evaluate(
								$ec);
						continue TRLoop;
					} else {
						if (Member.$instance.fUnboxed3S(
							_dict___Ord___Int.$instance, 
							vertexNum.evaluate($ec), 
							visited.getValue(), 
							$ec)) {
							stack = stackBottom.evaluate($ec);
								accum = 
								revisitVertexFn.f2L(
									accum.getValue(), 
									vertexNum, 
									$ec).evaluate(
									$ec);
							continue TRLoop;
						} else {
								stack = 
								Perform_D_F_S__dfs_Loop__8.newStack$17$def_Strict(
									getChildrenFn, 
									vertexNum, 
									stackBottom, 
									$ec);
								visited = 
								Perform_D_F_S__dfs_Loop__8.newVisited$18$def_Strict(
									vertexNum, 
									visited.getValue(), 
									$ec);
								accum = 
								Perform_D_F_S__dfs_Loop__8.newAccum$19$def_Strict(
									startVertexFn, 
									accum.getValue(), 
									vertexNum, 
									$ec);
							continue TRLoop;
						}
					}
				}

				default: {
					return 
						badSwitchIndex(
							Perform_D_F_S__dfs_Loop__8.Cal_Utilities_DirectedGraph_performDFS_1015_13);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Perform_D_F_S__dfs_Loop__8 function;

		private RTValue performDFS$finishVertexFn$4;

		private RTValue performDFS$revisitVertexFn$3;

		private RTValue performDFS$getChildrenFn$1;

		private RTValue performDFS$startVertexFn$2;

		private RTValue performDFS$stack$9;

		private RTValue performDFS$visited$10;

		private RTValue performDFS$accum$11;

		public RTAppS(Perform_D_F_S__dfs_Loop__8 $function, RTValue $performDFS$finishVertexFn$4, RTValue $performDFS$revisitVertexFn$3, RTValue $performDFS$getChildrenFn$1, RTValue $performDFS$startVertexFn$2, RTValue $performDFS$stack$9, RTValue $performDFS$visited$10, RTValue $performDFS$accum$11) {
			assert (
				((((((($function != null) && 
				($performDFS$finishVertexFn$4 != null)) && 
				($performDFS$revisitVertexFn$3 != null)) && 
				($performDFS$getChildrenFn$1 != null)) && 
				($performDFS$startVertexFn$2 != null)) && 
				($performDFS$stack$9 != null)) && 
				($performDFS$visited$10 != null)) && 
				($performDFS$accum$11 != null)) : (badConsArgMsg());
			function = $function;
			performDFS$finishVertexFn$4 = $performDFS$finishVertexFn$4;
			performDFS$revisitVertexFn$3 = $performDFS$revisitVertexFn$3;
			performDFS$getChildrenFn$1 = $performDFS$getChildrenFn$1;
			performDFS$startVertexFn$2 = $performDFS$startVertexFn$2;
			performDFS$stack$9 = $performDFS$stack$9;
			performDFS$visited$10 = $performDFS$visited$10;
			performDFS$accum$11 = $performDFS$accum$11;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f7S(
						RTValue.lastRef(
							performDFS$finishVertexFn$4, 
							performDFS$finishVertexFn$4 = null), 
						RTValue.lastRef(
							performDFS$revisitVertexFn$3, 
							performDFS$revisitVertexFn$3 = null), 
						RTValue.lastRef(
							performDFS$getChildrenFn$1, 
							performDFS$getChildrenFn$1 = null), 
						RTValue.lastRef(
							performDFS$startVertexFn$2, 
							performDFS$startVertexFn$2 = null), 
						RTValue.lastRef(
							performDFS$stack$9, 
							performDFS$stack$9 = null), 
						RTValue.lastRef(
							performDFS$visited$10, 
							performDFS$visited$10 = null), 
						RTValue.lastRef(
							performDFS$accum$11, 
							performDFS$accum$11 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			performDFS$finishVertexFn$4 = null;
			performDFS$revisitVertexFn$3 = null;
			performDFS$getChildrenFn$1 = null;
			performDFS$startVertexFn$2 = null;
			performDFS$stack$9 = null;
			performDFS$visited$10 = null;
			performDFS$accum$11 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 7;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return performDFS$finishVertexFn$4;
				}

				case 1: {
					return performDFS$revisitVertexFn$3;
				}

				case 2: {
					return performDFS$getChildrenFn$1;
				}

				case 3: {
					return performDFS$startVertexFn$2;
				}

				case 4: {
					return performDFS$stack$9;
				}

				case 5: {
					return performDFS$visited$10;
				}

				case 6: {
					return performDFS$accum$11;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 7)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
