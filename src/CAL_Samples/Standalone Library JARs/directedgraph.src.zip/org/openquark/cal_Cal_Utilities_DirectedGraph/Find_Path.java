package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Reverse;
import org.openquark.cal_Cal_Core_Prelude.Const__;
import org.openquark.cal_Cal_Core_Prelude.From_Just;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find_Path extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Path $instance = new Find_Path();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Find_Path() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findPath";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.findPath";
	}

	private static final RTValue reachesEnd$9$def_Lazy(RTValue pattern_path_reachesEnd, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_path_reachesEnd, 2);
	}

	private static final RTValue reachesEnd$9$def_Strict(RTValue pattern_path_reachesEnd, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_path_reachesEnd.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final boolean reachesEnd$9$def_Unboxed(RTValue pattern_path_reachesEnd, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_path_reachesEnd.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec).getBooleanValue();
	}

	private static final RTValue endVertexNum$6$def_Lazy(RTValue maybeEndVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(From_Just.$instance, maybeEndVertexNum);
	}

	private static final RTValue endVertexNum$6$def_Strict(RTValue maybeEndVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeEndVertexNum.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final int endVertexNum$6$def_Unboxed(RTValue maybeEndVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeEndVertexNum.evaluate($ec), 
				$ec).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue path$8$def_Lazy(RTValue pattern_path_reachesEnd, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_path_reachesEnd, 1);
	}

	private static final RTValue path$8$def_Strict(RTValue pattern_path_reachesEnd, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_path_reachesEnd.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_path_reachesEnd$10$def_Lazy(RTValue maybeEndVertexNum, RTValue $dictvarCal_Core_Prelude_Eq_18, RTValue startVertex, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._7._S(
				Fold_D_F_S_Internal.$instance, 
				$dictvarCal_Core_Prelude_Eq_18, 
				new TYPE_Maybe.CAL_Just(startVertex), 
				new RTPartialApp._3._1(
					Find_Path__start_Vertex_Fn__7.$instance, 
					Find_Path.endVertexNum$6$def_Lazy(maybeEndVertexNum, $ec)), 
				Const__.$instance, 
				Const__.$instance, 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {Find_Path.i_Nil, RTData.CAL_Boolean.make(false)}), 
				graph);
	}

	private static final RTValue $pattern_path_reachesEnd$10$def_Strict(RTValue maybeEndVertexNum, RTValue $dictvarCal_Core_Prelude_Eq_18, RTValue startVertex, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_D_F_S_Internal.$instance.f7S(
				$dictvarCal_Core_Prelude_Eq_18, 
				new TYPE_Maybe.CAL_Just(startVertex), 
				new RTPartialApp._3._1(
					Find_Path__start_Vertex_Fn__7.$instance, 
					Find_Path.endVertexNum$6$def_Lazy(maybeEndVertexNum, $ec)), 
				Const__.$instance, 
				Const__.$instance, 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {Find_Path.i_Nil, RTData.CAL_Boolean.make(false)}), 
				graph, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue maybeEndVertexNum$5$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_18, RTValue graph, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Get_Maybe_Vertex_Number.$instance, 
				$dictvarCal_Core_Prelude_Eq_18, 
				graph, 
				endVertex);
	}

	private static final RTValue maybeEndVertexNum$5$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_18, RTValue graph, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Get_Maybe_Vertex_Number.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_18, 
				graph, 
				endVertex, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue maybeStartVertexNum$4$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_18, RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Get_Maybe_Vertex_Number.$instance, 
				$dictvarCal_Core_Prelude_Eq_18, 
				graph, 
				startVertex);
	}

	private static final RTValue maybeStartVertexNum$4$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_18, RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Get_Maybe_Vertex_Number.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_18, 
				graph, 
				startVertex, 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPath
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue endVertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue startVertex = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue graph = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_18 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_18, 
					$dictvarCal_Core_Prelude_Eq_18 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(endVertex, endVertex = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPath
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Prelude_Eq_18, RTValue graph, RTValue startVertex, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_18, 
					$dictvarCal_Core_Prelude_Eq_18 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(endVertex, endVertex = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPath
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Prelude_Eq_18, RTValue graph, RTValue startVertex, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_maybeEndVertexNum = 
			Find_Path.maybeEndVertexNum$5$def_Lazy(
				$dictvarCal_Core_Prelude_Eq_18, 
				graph, 
				endVertex, 
				$ec);
		RTValue letVar_pattern_path_reachesEnd = 
			Find_Path.$pattern_path_reachesEnd$10$def_Lazy(
				letVar_maybeEndVertexNum, 
				$dictvarCal_Core_Prelude_Eq_18, 
				startVertex, 
				graph, 
				$ec);

		// Top level supercombinator logic
		if (Is_Just.$instance.fUnboxed1S(
			Find_Path.maybeStartVertexNum$4$def_Strict(
				$dictvarCal_Core_Prelude_Eq_18, 
				graph, 
				startVertex, 
				$ec), 
			$ec) && 
		(Is_Just.$instance.fUnboxed1S(
			letVar_maybeEndVertexNum.evaluate($ec), 
			$ec) && 
		Find_Path.reachesEnd$9$def_Unboxed(letVar_pattern_path_reachesEnd, $ec))) {
			return 
				new TYPE_Maybe.CAL_Just(
					new RTFullApp.General._1._L(
						Reverse.$instance, 
						new RTFullApp.General._2._S(
							Indices_To_Vertices.$instance, 
							graph, 
							Find_Path.path$8$def_Lazy(
								letVar_pattern_path_reachesEnd, 
								$ec))));
		} else {
			return Find_Path.i_Nothing;
		}
	}

}
