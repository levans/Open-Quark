package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Fold_D_F_S_Internal__dfs_All__9 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Fold_D_F_S_Internal__dfs_All__9 $instance = 
		new Fold_D_F_S_Internal__dfs_All__9();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_foldDFSInternal_969_13 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "foldDFSInternal", 969, 13);

	private Fold_D_F_S_Internal__dfs_All__9() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "foldDFSInternal$dfsAll$9";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.foldDFSInternal$dfsAll$9";
	}

	private static final RTValue newVertexNums$19$def_Lazy(RTValue newVisited, RTValue ns, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._S(
				Filter_List_Strict.$instance, 
				new RTPartialApp._2._1(
					_lambda__fold_D_F_S_Internal__1.$instance, 
					newVisited), 
				ns);
	}

	private static final RTValue newVertexNums$19$def_Strict(RTValue newVisited, RTValue ns, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Filter_List_Strict.$instance.f2S(
				new RTPartialApp._2._1(
					_lambda__fold_D_F_S_Internal__1.$instance, 
					newVisited), 
				ns, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue newAccum$17$def_Lazy(RTValue pattern_newVisited_newAccum, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_newVisited_newAccum, 2);
	}

	private static final RTValue newAccum$17$def_Strict(RTValue pattern_newVisited_newAccum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_newVisited_newAccum.evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue newVisited$16$def_Lazy(RTValue pattern_newVisited_newAccum, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_newVisited_newAccum, 1);
	}

	private static final RTValue newVisited$16$def_Strict(RTValue pattern_newVisited_newAccum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_newVisited_newAccum.evaluate(
					$ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_newVisited_newAccum$18$def_Lazy(RTValue dfsHelper, RTValue n, RTValue visited, RTValue accum, RTExecutionContext $ec) throws CALExecutorException {
		return dfsHelper.apply(n, visited.getValue(), accum.getValue());
	}

	private static final RTValue $pattern_newVisited_newAccum$18$def_Strict(RTValue dfsHelper, RTValue n, RTValue visited, RTValue accum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			dfsHelper.f3L(
				n, 
				visited.getValue(), 
				accum.getValue(), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal$dfsAll$9
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNums = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue accum = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue visited = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue dfsHelper = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(dfsHelper, dfsHelper = null), 
				RTValue.lastRef(visited.evaluate($ec), visited = null), 
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				RTValue.lastRef(vertexNums.evaluate($ec), vertexNums = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal$dfsAll$9
	 */
	public final RTValue f4L(RTValue dfsHelper, RTValue visited, RTValue accum, RTValue vertexNums, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(dfsHelper, dfsHelper = null), 
				RTValue.lastRef(visited.evaluate($ec), visited = null), 
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				RTValue.lastRef(vertexNums.evaluate($ec), vertexNums = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal$dfsAll$9
	 */
	public final RTValue f4S(RTValue dfsHelper, RTValue visited, RTValue accum, RTValue vertexNums, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)vertexNums.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return accum.getValue();
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue n = $case1.get_head();
					RTValue ns = $case1.get_tail();
					RTValue letVar_pattern_newVisited_newAccum = 
						Fold_D_F_S_Internal__dfs_All__9.$pattern_newVisited_newAccum$18$def_Lazy(
							dfsHelper, 
							n, 
							visited.getValue(), 
							accum.getValue(), 
							$ec);
					RTValue letVar_newVisited = 
						Fold_D_F_S_Internal__dfs_All__9.newVisited$16$def_Lazy(
							letVar_pattern_newVisited_newAccum, 
							$ec);

					RTValue visited$ = letVar_newVisited.evaluate($ec);
					visited = visited$;
						accum = 
						Fold_D_F_S_Internal__dfs_All__9.newAccum$17$def_Strict(
							letVar_pattern_newVisited_newAccum, 
							$ec);
						vertexNums = 
						Fold_D_F_S_Internal__dfs_All__9.newVertexNums$19$def_Strict(
							letVar_newVisited, 
							ns, 
							$ec);
					continue TRLoop;
				}

				default: {
					return 
						badSwitchIndex(
							Fold_D_F_S_Internal__dfs_All__9.Cal_Utilities_DirectedGraph_foldDFSInternal_969_13);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Fold_D_F_S_Internal__dfs_All__9 function;

		private RTValue foldDFSInternal$dfsHelper$7;

		private RTValue foldDFSInternal$visited$11;

		private RTValue foldDFSInternal$accum$12;

		private RTValue foldDFSInternal$vertexNums$13;

		public RTAppS(Fold_D_F_S_Internal__dfs_All__9 $function, RTValue $foldDFSInternal$dfsHelper$7, RTValue $foldDFSInternal$visited$11, RTValue $foldDFSInternal$accum$12, RTValue $foldDFSInternal$vertexNums$13) {
			assert (
				(((($function != null) && 
				($foldDFSInternal$dfsHelper$7 != null)) && 
				($foldDFSInternal$visited$11 != null)) && 
				($foldDFSInternal$accum$12 != null)) && 
				($foldDFSInternal$vertexNums$13 != null)) : (badConsArgMsg());
			function = $function;
			foldDFSInternal$dfsHelper$7 = $foldDFSInternal$dfsHelper$7;
			foldDFSInternal$visited$11 = $foldDFSInternal$visited$11;
			foldDFSInternal$accum$12 = $foldDFSInternal$accum$12;
			foldDFSInternal$vertexNums$13 = $foldDFSInternal$vertexNums$13;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f4S(
						RTValue.lastRef(
							foldDFSInternal$dfsHelper$7, 
							foldDFSInternal$dfsHelper$7 = null), 
						RTValue.lastRef(
							foldDFSInternal$visited$11, 
							foldDFSInternal$visited$11 = null), 
						RTValue.lastRef(
							foldDFSInternal$accum$12, 
							foldDFSInternal$accum$12 = null), 
						RTValue.lastRef(
							foldDFSInternal$vertexNums$13, 
							foldDFSInternal$vertexNums$13 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			foldDFSInternal$dfsHelper$7 = null;
			foldDFSInternal$visited$11 = null;
			foldDFSInternal$accum$12 = null;
			foldDFSInternal$vertexNums$13 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 4;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return foldDFSInternal$dfsHelper$7;
				}

				case 1: {
					return foldDFSInternal$visited$11;
				}

				case 2: {
					return foldDFSInternal$accum$12;
				}

				case 3: {
					return foldDFSInternal$vertexNums$13;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 4)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
