package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.From_List;
import org.openquark.cal_Cal_Core_Prelude.Fold_Right;
import org.openquark.cal_Cal_Core_Prelude.Length;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;
import org.openquark.cal_Cal_Core_Prelude.Up_From_Int;
import org.openquark.cal_Cal_Core_Prelude.Zip;

public final class Find_Permutation extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Permutation $instance = new Find_Permutation();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_findPermutation_1619_13 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"findPermutation", 
			1619, 
			13);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Find_Permutation() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findPermutation";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.findPermutation";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPermutation
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue list1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_4 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_4, 
					$dictvarCal_Core_Prelude_Eq_4 = null), 
				RTValue.lastRef(list1, list1 = null), 
				RTValue.lastRef(list2, list2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPermutation
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_4, RTValue list1, RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_4, 
					$dictvarCal_Core_Prelude_Eq_4 = null), 
				RTValue.lastRef(list1, list1 = null), 
				RTValue.lastRef(list2, list2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPermutation
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_4, RTValue list1, RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (Length.$instance.fUnboxed1S(list1.evaluate($ec), $ec) != 
		Length.$instance.fUnboxed1S(list2.evaluate($ec), $ec)) {
			return Find_Permutation.i_Nothing;
		} else {
			TYPE_Maybe $case2;

			switch (($case2 = (((TYPE_Maybe)(java.lang.Object)Fold_Right.$instance.f3S(new RTPartialApp._4._2(Find_Permutation__add_Index__3.$instance, $dictvarCal_Core_Prelude_Eq_4, list2), new TYPE_Maybe.CAL_Just(Find_Permutation.i_Nil), list1.evaluate($ec), $ec).evaluate($ec)))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nothing
					return Find_Permutation.i_Nothing;
				}

				case 1: {
					// Cal.Core.Prelude.Just
					// Decompose data type to access members.
					RTValue image = $case2.get_value();

					return 
						new TYPE_Maybe.CAL_Just(
							new RTFullApp.General._1._L(
								From_List.$instance, 
								new RTFullApp.General._2._L(
									Zip.$instance, 
									new Up_From_Int.RTAppS(
										Up_From_Int.$instance, 
										0), 
									image)));
				}

				default: {
					return 
						badSwitchIndex(
							Find_Permutation.Cal_Utilities_DirectedGraph_findPermutation_1619_13);
				}
			}
		}
	}

}
