package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Concat_String;
import org.openquark.cal_Cal_Core_Prelude.Repeat;
import org.openquark.cal_Cal_Core_Prelude.Take;

public final class Show_Directed_Graph__make_Indent_String__4 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_String $L1_String_ = 
		RTData.CAL_String.make(" ");

	/**
	 * Singleton instance of this class.
	 */
	public static final Show_Directed_Graph__make_Indent_String__4 $instance = 
		new Show_Directed_Graph__make_Indent_String__4();

	private Show_Directed_Graph__make_Indent_String__4() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "showDirectedGraph$makeIndentString$4";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.showDirectedGraph$makeIndentString$4";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph$makeIndentString$4
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue num = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(num, num = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph$makeIndentString$4
	 */
	public final RTValue f1L(RTValue num, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(num, num = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph$makeIndentString$4
	 */
	public final RTValue f1S(RTValue num, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Concat_String.$instance.f1S(
				Take.$instance.f2S(
					num.evaluate($ec).getOrdinalValue(), 
					new RTFullApp.General._1._S(
						Repeat.$instance, 
						Show_Directed_Graph__make_Indent_String__4.$L1_String_), 
					$ec).evaluate(
					$ec), 
				$ec);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph$makeIndentString$4
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.String fUnboxed1S(RTValue num, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Concat_String.$instance.f1S(
				Take.$instance.f2S(
					num.evaluate($ec).getOrdinalValue(), 
					new RTFullApp.General._1._S(
						Repeat.$instance, 
						Show_Directed_Graph__make_Indent_String__4.$L1_String_), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec).getStringValue();
	}

}
