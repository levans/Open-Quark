package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Equals_Int;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Find_Path__start_Vertex_Fn__7 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Path__start_Vertex_Fn__7 $instance = 
		new Find_Path__start_Vertex_Fn__7();

	private Find_Path__start_Vertex_Fn__7() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findPath$startVertexFn$7";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.findPath$startVertexFn$7";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPath$startVertexFn$7
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNum = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue accum = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue endVertexNum = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(endVertexNum, endVertexNum = null), 
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPath$startVertexFn$7
	 */
	public final RTValue f3L(RTValue endVertexNum, RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(endVertexNum, endVertexNum = null), 
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPath$startVertexFn$7
	 */
	public final RTValue f3S(RTValue endVertexNum, RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)accum.evaluate($ec));
		RTValue path = $recordCase1.getOrdinalFieldValue(1);
		RTValue reachesEnd = $recordCase1.getOrdinalFieldValue(2);

		if (reachesEnd.evaluate($ec).getBooleanValue()) {
			return accum;
		} else {
			return 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {new TYPE_List.CAL_Cons(vertexNum, path), new RTFullApp.General._2._L(Equals_Int.$instance, vertexNum, endVertexNum)});
		}
	}

}
