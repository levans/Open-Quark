package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;

public final class Exists_Cycle extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Exists_Cycle $instance = new Exists_Cycle();

	private Exists_Cycle() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "existsCycle";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.existsCycle";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsCycle
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_49 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_49, 
					$dictvarCal_Core_Prelude_Eq_49 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsCycle
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_49, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_49, 
					$dictvarCal_Core_Prelude_Eq_49 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.existsCycle
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_49, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Is_Just.$instance.f1S(
				Find_Cycle.$instance.f2S(
					$dictvarCal_Core_Prelude_Eq_49, 
					graph, 
					$ec).evaluate(
					$ec), 
				$ec);
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.existsCycle
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed2S(RTValue $dictvarCal_Core_Prelude_Eq_49, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Is_Just.$instance.f1S(
				Find_Cycle.$instance.f2S(
					$dictvarCal_Core_Prelude_Eq_49, 
					graph, 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec).getBooleanValue();
	}

}
