package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Group_By;
import org.openquark.cal_Cal_Collections_List.Sort;
import org.openquark.cal_Cal_Core_Prelude.Fst;
import org.openquark.cal_Cal_Core_Prelude.Induce_Equality_Function;
import org.openquark.cal_Cal_Core_Prelude.Map;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Ord_____Univeral_Record;

public final class Group_By_First extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	/**
	 * Singleton instance of this class.
	 */
	public static final Group_By_First $instance = new Group_By_First();

	private Group_By_First() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "groupByFirst";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.groupByFirst";
	}

	private static final RTValue sortedTuples$2$def_Lazy(RTValue $dictvarCal_Core_Prelude_Ord_26, RTValue $dictvarCal_Core_Prelude_Ord_27, RTValue tuples, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(new RTFullApp.General._1._S(
				Sort.$instance, 
				new RTPartialApp._2._1(
					_dict___Ord___Ord_____Univeral_Record.$instance__dict_Cal___Core___Prelude___Ord_____Univeral_Record, 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {$dictvarCal_Core_Prelude_Ord_26, $dictvarCal_Core_Prelude_Ord_27})))).apply(
				tuples);
	}

	private static final RTValue sortedTuples$2$def_Strict(RTValue $dictvarCal_Core_Prelude_Ord_26, RTValue $dictvarCal_Core_Prelude_Ord_27, RTValue tuples, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Sort.$instance.f1S(
				new RTPartialApp._2._1(
					_dict___Ord___Ord_____Univeral_Record.$instance__dict_Cal___Core___Prelude___Ord_____Univeral_Record, 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {$dictvarCal_Core_Prelude_Ord_26, $dictvarCal_Core_Prelude_Ord_27})), 
				$ec).evaluate(
				$ec).f1L(
				tuples, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue groupedTuples$3$def_Lazy(RTValue $dictvarCal_Core_Prelude_Ord_26, RTValue $dictvarCal_Core_Prelude_Ord_27, RTValue tuples, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Group_By.$instance, 
				new RTPartialApp._4._2(
					Induce_Equality_Function.$instance, 
					$dictvarCal_Core_Prelude_Ord_26.apply(
						Group_By_First.$L1_Int_0), 
					Fst.$instance), 
				Group_By_First.sortedTuples$2$def_Lazy(
					$dictvarCal_Core_Prelude_Ord_26, 
					$dictvarCal_Core_Prelude_Ord_27, 
					tuples, 
					$ec));
	}

	private static final RTValue groupedTuples$3$def_Strict(RTValue $dictvarCal_Core_Prelude_Ord_26, RTValue $dictvarCal_Core_Prelude_Ord_27, RTValue tuples, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Group_By.$instance.f2S(
				new RTPartialApp._4._2(
					Induce_Equality_Function.$instance, 
					$dictvarCal_Core_Prelude_Ord_26.apply(
						Group_By_First.$L1_Int_0), 
					Fst.$instance), 
				Group_By_First.sortedTuples$2$def_Strict(
					$dictvarCal_Core_Prelude_Ord_26, 
					$dictvarCal_Core_Prelude_Ord_27, 
					tuples, 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.groupByFirst
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue tuples = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue $dictvarCal_Core_Prelude_Ord_27 = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_26 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_26, 
					$dictvarCal_Core_Prelude_Ord_26 = null), 
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_27, 
					$dictvarCal_Core_Prelude_Ord_27 = null), 
				RTValue.lastRef(tuples, tuples = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.groupByFirst
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_26, RTValue $dictvarCal_Core_Prelude_Ord_27, RTValue tuples, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_26, 
					$dictvarCal_Core_Prelude_Ord_26 = null), 
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_27, 
					$dictvarCal_Core_Prelude_Ord_27 = null), 
				RTValue.lastRef(tuples, tuples = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.groupByFirst
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_26, RTValue $dictvarCal_Core_Prelude_Ord_27, RTValue tuples, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Map.$instance.f2S(
				_lambda__group_By_First__1.$instance, 
				Group_By_First.groupedTuples$3$def_Strict(
					$dictvarCal_Core_Prelude_Ord_26, 
					$dictvarCal_Core_Prelude_Ord_27, 
					tuples, 
					$ec), 
				$ec);
	}

}
