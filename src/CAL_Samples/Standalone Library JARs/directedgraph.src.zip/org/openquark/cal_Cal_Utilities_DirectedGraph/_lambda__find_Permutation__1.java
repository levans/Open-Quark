package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class _lambda__find_Permutation__1 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__find_Permutation__1 $instance = 
		new _lambda__find_Permutation__1();

	private _lambda__find_Permutation__1() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$findPermutation$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$findPermutation$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$findPermutation$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue elem2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue elem1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_4 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_4, 
					$dictvarCal_Core_Prelude_Eq_4 = null), 
				RTValue.lastRef(elem1, elem1 = null), 
				RTValue.lastRef(elem2, elem2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$findPermutation$1
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_4, RTValue elem1, RTValue elem2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_4, 
					$dictvarCal_Core_Prelude_Eq_4 = null), 
				RTValue.lastRef(elem1, elem1 = null), 
				RTValue.lastRef(elem2, elem2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$findPermutation$1
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_4, RTValue elem1, RTValue elem2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new RTOApp3(
				$dictvarCal_Core_Prelude_Eq_4, 
				_lambda__find_Permutation__1.$L1_Int_0, 
				elem1, 
				elem2);
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$findPermutation$1
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Eq_4, RTValue elem1, RTValue elem2, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = 
			f3S($dictvarCal_Core_Prelude_Eq_4, elem1, elem2, $ec);

		$dictvarCal_Core_Prelude_Eq_4 = null;
		elem1 = null;
		elem2 = null;
		return $result.evaluate($ec).getBooleanValue();
	}

}
