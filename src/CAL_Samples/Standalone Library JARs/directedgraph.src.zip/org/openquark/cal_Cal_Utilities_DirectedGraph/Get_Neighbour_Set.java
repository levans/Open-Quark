package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.Lookup_With_Default;
import org.openquark.cal_Cal_Collections_Set.TYPE_Set;

public final class Get_Neighbour_Set extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Neighbour_Set $instance = new Get_Neighbour_Set();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_getNeighbourSet_550_50 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "getNeighbourSet", 550, 50);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Get_Neighbour_Set() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getNeighbourSet";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.getNeighbourSet";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbourSet
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue startVertexNum = $rootNode.getArgValue();
		RTValue graph = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertexNum, startVertexNum = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbourSet
	 */
	public final RTValue f2L(RTValue graph, RTValue startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertexNum, startVertexNum = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbourSet
	 */
	public final RTValue f2S(RTValue graph, RTValue startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Lookup_With_Default.$instance.f3S(
				startVertexNum.evaluate($ec).getOrdinalValue(), 
				(((RTCons)(java.lang.Object)
					graph.evaluate($ec))).getFieldByIndex(
					0, 
					2, 
					Get_Neighbour_Set.Cal_Utilities_DirectedGraph_getNeighbourSet_550_50).evaluate(
					$ec), 
				Get_Neighbour_Set.i_Tip, 
				$ec);
	}

}
