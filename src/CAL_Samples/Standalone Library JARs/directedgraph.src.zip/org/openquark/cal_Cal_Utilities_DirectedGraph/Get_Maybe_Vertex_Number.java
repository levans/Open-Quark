package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.To_List;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Get_Maybe_Vertex_Number extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Maybe_Vertex_Number $instance = 
		new Get_Maybe_Vertex_Number();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_getMaybeVertexNumber_372_67 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"getMaybeVertexNumber", 
			372, 
			67);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Get_Maybe_Vertex_Number() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getMaybeVertexNumber";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.getMaybeVertexNumber";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getMaybeVertexNumber
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_0 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_0, 
					$dictvarCal_Core_Prelude_Eq_0 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getMaybeVertexNumber
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_0, RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_0, 
					$dictvarCal_Core_Prelude_Eq_0 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getMaybeVertexNumber
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_0, RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Fold_Left_Strict.RTAppS(
				Fold_Left_Strict.$instance, 
				new RTPartialApp._4._2(
					Get_Maybe_Vertex_Number__find_Vertex_Num__3.$instance, 
					$dictvarCal_Core_Prelude_Eq_0, 
					vertex), 
				Get_Maybe_Vertex_Number.i_Nothing, 
				To_List.$instance.f1S(
					(((RTCons)(java.lang.Object)
						graph.evaluate($ec))).getFieldByIndex(
						0, 
						1, 
						Get_Maybe_Vertex_Number.Cal_Utilities_DirectedGraph_getMaybeVertexNumber_372_67).evaluate(
						$ec), 
					$ec).evaluate(
					$ec));
	}

}
