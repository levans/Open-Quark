package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Map;

public final class Strongly_Connected_Components extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Strongly_Connected_Components $instance = 
		new Strongly_Connected_Components();

	private Strongly_Connected_Components() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "stronglyConnectedComponents";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.stronglyConnectedComponents";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponents
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_50 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_50, 
					$dictvarCal_Core_Prelude_Eq_50 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponents
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_50, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_50, 
					$dictvarCal_Core_Prelude_Eq_50 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponents
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_50, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Map.$instance.f2S(
				new RTPartialApp._2._1(Indices_To_Vertices.$instance, graph), 
				Strongly_Connected_Components_Internal.$instance.f2S(
					$dictvarCal_Core_Prelude_Eq_50, 
					graph, 
					$ec).evaluate(
					$ec), 
				$ec);
	}

}
