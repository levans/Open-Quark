package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Const__;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Fold_In_Depth_First_Search_Order extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Fold_In_Depth_First_Search_Order $instance = 
		new Fold_In_Depth_First_Search_Order();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Fold_In_Depth_First_Search_Order() {
	}

	public final int getArity() {
		return 5;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "foldInDepthFirstSearchOrder";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.foldInDepthFirstSearchOrder";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldInDepthFirstSearchOrder
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue init = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue finishVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue startVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_16 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f5S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_16, 
					$dictvarCal_Core_Prelude_Eq_16 = null), 
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(init, init = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f5L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldInDepthFirstSearchOrder
	 */
	public final RTValue f5L(RTValue $dictvarCal_Core_Prelude_Eq_16, RTValue startVertexFn, RTValue finishVertexFn, RTValue init, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f5S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_16, 
					$dictvarCal_Core_Prelude_Eq_16 = null), 
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(init, init = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f5S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldInDepthFirstSearchOrder
	 */
	public final RTValue f5S(RTValue $dictvarCal_Core_Prelude_Eq_16, RTValue startVertexFn, RTValue finishVertexFn, RTValue init, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Fold_D_F_S_Internal.$instance.f7S(
				$dictvarCal_Core_Prelude_Eq_16, 
				Fold_In_Depth_First_Search_Order.i_Nothing, 
				new RTPartialApp._4._2(
					_lambda__fold_In_Depth_First_Search_Order__1.$instance, 
					startVertexFn, 
					graph), 
				Const__.$instance, 
				new RTPartialApp._4._2(
					_lambda__fold_In_Depth_First_Search_Order__2.$instance, 
					finishVertexFn, 
					graph), 
				init, 
				graph, 
				$ec);
	}

}
