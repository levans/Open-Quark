package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Is_Empty extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Is_Empty $instance = new Is_Empty();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_isEmpty_181_25 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "isEmpty", 181, 25);

	private Is_Empty() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "isEmpty";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.isEmpty";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.isEmpty
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.isEmpty
	 */
	public final RTValue f1L(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.isEmpty
	 */
	public final RTValue f1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Collections_IntMap.Is_Empty.$instance.f1S(
				(((RTCons)(java.lang.Object)
					graph.evaluate($ec))).getFieldByIndex(
					0, 
					1, 
					Is_Empty.Cal_Utilities_DirectedGraph_isEmpty_181_25).evaluate(
					$ec), 
				$ec);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.isEmpty
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Collections_IntMap.Is_Empty.$instance.f1S(
				(((RTCons)(java.lang.Object)
					graph.evaluate($ec))).getFieldByIndex(
					0, 
					1, 
					Is_Empty.Cal_Utilities_DirectedGraph_isEmpty_181_25).evaluate(
					$ec), 
				$ec).evaluate(
				$ec).getBooleanValue();
	}

}
