package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.TYPE_Int_Map;

public final class Empty_Graph extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Empty_Graph $instance = new Empty_Graph();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Int_Map.CAL_Nil i_Nil = 
		TYPE_Int_Map.CAL_Nil.make();

	private Empty_Graph() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "emptyGraph";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.emptyGraph";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.emptyGraph
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $dictvarCal_Core_Prelude_Eq_46 = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_46, 
					$dictvarCal_Core_Prelude_Eq_46 = null), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.emptyGraph
	 */
	public final RTValue f1L(RTValue $dictvarCal_Core_Prelude_Eq_46, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_46, 
					$dictvarCal_Core_Prelude_Eq_46 = null), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.emptyGraph
	 */
	public final RTValue f1S(RTValue $dictvarCal_Core_Prelude_Eq_46, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new TYPE_Directed_Graph.CAL_Directed_Graph(
				0, 
				Empty_Graph.i_Nil, 
				Empty_Graph.i_Nil);
	}

}
