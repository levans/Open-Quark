package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_Set.Equals_Set;
import org.openquark.cal_Cal_Collections_Set.Map;
import org.openquark.cal_Cal_Core_Prelude._dict___Eq___Int;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Equals_Directed_Graph_Ignore_Insertion_Order__same_Neighbours__13 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Equals_Directed_Graph_Ignore_Insertion_Order__same_Neighbours__13 $instance = 
		new Equals_Directed_Graph_Ignore_Insertion_Order__same_Neighbours__13();

	private Equals_Directed_Graph_Ignore_Insertion_Order__same_Neighbours__13() {
	}

	public final int getArity() {
		return 5;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "equalsDirectedGraphIgnoreInsertionOrder$sameNeighbours$13";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$sameNeighbours$13";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$sameNeighbours$13
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNum2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue vertexNum1 = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue graph2 = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue vertexNumPerm = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue graph1 = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f5S(
				RTValue.lastRef(graph1, graph1 = null), 
				RTValue.lastRef(
					vertexNumPerm.evaluate($ec), 
					vertexNumPerm = null), 
				RTValue.lastRef(graph2, graph2 = null), 
				RTValue.lastRef(vertexNum1, vertexNum1 = null), 
				RTValue.lastRef(vertexNum2, vertexNum2 = null), 
				$ec);
	}

	/**
	 * f5L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$sameNeighbours$13
	 */
	public final RTValue f5L(RTValue graph1, RTValue vertexNumPerm, RTValue graph2, RTValue vertexNum1, RTValue vertexNum2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f5S(
				RTValue.lastRef(graph1, graph1 = null), 
				RTValue.lastRef(
					vertexNumPerm.evaluate($ec), 
					vertexNumPerm = null), 
				RTValue.lastRef(graph2, graph2 = null), 
				RTValue.lastRef(vertexNum1, vertexNum1 = null), 
				RTValue.lastRef(vertexNum2, vertexNum2 = null), 
				$ec);
	}

	/**
	 * f5S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$sameNeighbours$13
	 */
	public final RTValue f5S(RTValue graph1, RTValue vertexNumPerm, RTValue graph2, RTValue vertexNum1, RTValue vertexNum2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Equals_Set.$instance.f3S(
				_dict___Eq___Int.$instance, 
				Get_Neighbour_Set.$instance.f2S(
					graph1, 
					vertexNum1, 
					$ec).evaluate(
					$ec), 
				Map.$instance.f4S(
					_dict___Ord___Int.$instance, 
					_dict___Ord___Int.$instance, 
					new RTPartialApp._2._1(
						Equals_Directed_Graph_Ignore_Insertion_Order__translate_Num2__12.$instance, 
						vertexNumPerm.getValue()), 
					Get_Neighbour_Set.$instance.f2S(
						graph2, 
						vertexNum2, 
						$ec).evaluate(
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec);
	}

	/**
	 * fUnboxed5S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$sameNeighbours$13
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed5S(RTValue graph1, RTValue vertexNumPerm, RTValue graph2, RTValue vertexNum1, RTValue vertexNum2, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = 
			f5S(graph1, vertexNumPerm, graph2, vertexNum1, vertexNum2, $ec);

		graph1 = null;
		vertexNumPerm = null;
		graph2 = null;
		vertexNum1 = null;
		vertexNum2 = null;
		return $result.evaluate($ec).getBooleanValue();
	}

}
