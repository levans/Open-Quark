package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTOApp2;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Show_Directed_Graph__indent_Diff__3 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_12 = RTData.CAL_Int.make(12);

	private static final RTData.CAL_Int $L2_Int_2 = RTData.CAL_Int.make(2);

	/**
	 * Singleton instance of this class.
	 */
	public static final Show_Directed_Graph__indent_Diff__3 $instance = 
		new Show_Directed_Graph__indent_Diff__3();

	private Show_Directed_Graph__indent_Diff__3() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "showDirectedGraph$indentDiff$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.showDirectedGraph$indentDiff$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph$indentDiff$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $dictvarCal_Core_Prelude_Num_36 = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Num_36, 
					$dictvarCal_Core_Prelude_Num_36 = null), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph$indentDiff$3
	 */
	public final RTValue f1L(RTValue $dictvarCal_Core_Prelude_Num_36, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Num_36, 
					$dictvarCal_Core_Prelude_Num_36 = null), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph$indentDiff$3
	 */
	public final RTValue f1S(RTValue $dictvarCal_Core_Prelude_Num_36, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new RTOApp2(
				$dictvarCal_Core_Prelude_Num_36, 
				Show_Directed_Graph__indent_Diff__3.$L1_Int_12, 
				Show_Directed_Graph__indent_Diff__3.$L2_Int_2);
	}

}
