package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.Elems;
import org.openquark.cal_Cal_Collections_List.Sum;
import org.openquark.cal_Cal_Collections_Set.Size;
import org.openquark.cal_Cal_Core_Prelude.Map;
import org.openquark.cal_Cal_Core_Prelude._dict___Num___Int;

public final class Get_Edge_Count extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Edge_Count $instance = new Get_Edge_Count();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_getEdgeCount_145_49 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "getEdgeCount", 145, 49);

	private Get_Edge_Count() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getEdgeCount";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.getEdgeCount";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getEdgeCount
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getEdgeCount
	 */
	public final RTValue f1L(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getEdgeCount
	 */
	public final RTValue f1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Sum.$instance.f1S(_dict___Num___Int.$instance, $ec).evaluate(
				$ec).apply(
				new RTFullApp.General._2._L(
					Map.$instance, 
					Size.$instance, 
					new RTFullApp.General._1._L(
						Elems.$instance, 
						new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
							graph, 
							0, 
							2, 
							Get_Edge_Count.Cal_Utilities_DirectedGraph_getEdgeCount_145_49))));
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.getEdgeCount
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Sum.$instance.f1S(_dict___Num___Int.$instance, $ec).evaluate(
				$ec).apply(
				new RTFullApp.General._2._L(
					Map.$instance, 
					Size.$instance, 
					new RTFullApp.General._1._L(
						Elems.$instance, 
						new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
							graph, 
							0, 
							2, 
							Get_Edge_Count.Cal_Utilities_DirectedGraph_getEdgeCount_145_49)))).evaluate(
				$ec).getOrdinalValue();
	}

}
