package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Get_Neighbours extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Neighbours $instance = new Get_Neighbours();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_getNeighbours_591_5 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "getNeighbours", 591, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Get_Neighbours() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getNeighbours";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.getNeighbours";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbours
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_32 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_32, 
					$dictvarCal_Core_Prelude_Eq_32 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbours
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_32, RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_32, 
					$dictvarCal_Core_Prelude_Eq_32 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getNeighbours
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_32, RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)Get_Maybe_Vertex_Number.$instance.f3S($dictvarCal_Core_Prelude_Eq_32, graph, vertex, $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return Get_Neighbours.i_Nil;
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue vertexNum = $case1.get_value();

				return 
					Indices_To_Vertices.$instance.f2S(
						graph, 
						new RTFullApp.General._2._S(
							Get_Neighbour_List.$instance, 
							graph, 
							vertexNum), 
						$ec);
			}

			default: {
				return 
					badSwitchIndex(
						Get_Neighbours.Cal_Utilities_DirectedGraph_getNeighbours_591_5);
			}
		}
	}

}
