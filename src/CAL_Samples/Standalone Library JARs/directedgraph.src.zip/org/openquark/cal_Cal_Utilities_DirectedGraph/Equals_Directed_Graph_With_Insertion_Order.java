package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude._equals___List;

public final class Equals_Directed_Graph_With_Insertion_Order extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Equals_Directed_Graph_With_Insertion_Order $instance = 
		new Equals_Directed_Graph_With_Insertion_Order();

	private Equals_Directed_Graph_With_Insertion_Order() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "equalsDirectedGraphWithInsertionOrder";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.equalsDirectedGraphWithInsertionOrder";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphWithInsertionOrder
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph1 = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_41 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_41, 
					$dictvarCal_Core_Prelude_Eq_41 = null), 
				RTValue.lastRef(graph1, graph1 = null), 
				RTValue.lastRef(graph2, graph2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphWithInsertionOrder
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_41, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_41, 
					$dictvarCal_Core_Prelude_Eq_41 = null), 
				RTValue.lastRef(graph1, graph1 = null), 
				RTValue.lastRef(graph2, graph2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphWithInsertionOrder
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_41, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(
				_equals___List.$instance.fUnboxed3S(
					$dictvarCal_Core_Prelude_Eq_41, 
					Get_Vertices_In_Insertion_Order.$instance.f1S(
						graph1, 
						$ec).evaluate(
						$ec), 
					Get_Vertices_In_Insertion_Order.$instance.f1S(
						graph2, 
						$ec).evaluate(
						$ec), 
					$ec) && 
				Equals_Directed_Graph_Ignore_Insertion_Order.$instance.fUnboxed3S(
					$dictvarCal_Core_Prelude_Eq_41, 
					graph1, 
					graph2, 
					$ec));
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphWithInsertionOrder
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Eq_41, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			_equals___List.$instance.fUnboxed3S(
				$dictvarCal_Core_Prelude_Eq_41, 
				Get_Vertices_In_Insertion_Order.$instance.f1S(
					graph1, 
					$ec).evaluate(
					$ec), 
				Get_Vertices_In_Insertion_Order.$instance.f1S(
					graph2, 
					$ec).evaluate(
					$ec), 
				$ec) && 
			Equals_Directed_Graph_Ignore_Insertion_Order.$instance.fUnboxed3S(
				$dictvarCal_Core_Prelude_Eq_41, 
				graph1, 
				graph2, 
				$ec);
	}

}
