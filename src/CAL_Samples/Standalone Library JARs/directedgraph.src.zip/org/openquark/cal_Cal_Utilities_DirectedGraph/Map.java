package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.To_List;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Map extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Map $instance = new Map();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_map_678_51 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "map", 678, 51);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Directed_Graph.CAL_Directed_Graph i_DirectedGraph = 
		TYPE_Directed_Graph.CAL_Directed_Graph.make();

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Map() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "map";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.map";
	}

	private static final RTValue mapEntries$7$def_Lazy(RTValue mappedGraph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				To_List.$instance, 
				new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
					mappedGraph, 
					0, 
					1, 
					Map.Cal_Utilities_DirectedGraph_map_678_51));
	}

	private static final RTValue mapEntries$7$def_Strict(RTValue mappedGraph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			To_List.$instance.f1S(
				(((RTCons)(java.lang.Object)
					mappedGraph.evaluate($ec))).getFieldByIndex(
					0, 
					1, 
					Map.Cal_Utilities_DirectedGraph_map_678_51).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue mappedGraph$6$def_Lazy(int nextVertexNum, RTValue mapFn, RTValue vertexMap, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Map.i_DirectedGraph, 
				RTData.CAL_Int.make(nextVertexNum), 
				new RTFullApp.General._2._S(
					org.openquark.cal_Cal_Collections_IntMap.Map.$instance, 
					mapFn, 
					vertexMap.getValue()), 
				edges.getValue());
	}

	private static final RTValue mappedGraph$6$def_Strict(int nextVertexNum, RTValue mapFn, RTValue vertexMap, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new TYPE_Directed_Graph.CAL_Directed_Graph(
				nextVertexNum, 
				org.openquark.cal_Cal_Collections_IntMap.Map.$instance.f2S(
					mapFn, 
					vertexMap.getValue(), 
					$ec).evaluate(
					$ec), 
				edges.getValue());
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.map
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue mapFn = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_43 = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_42 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_42, 
					$dictvarCal_Core_Prelude_Eq_42 = null), 
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_43, 
					$dictvarCal_Core_Prelude_Eq_43 = null), 
				RTValue.lastRef(mapFn, mapFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.map
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Prelude_Eq_42, RTValue $dictvarCal_Core_Prelude_Eq_43, RTValue mapFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_42, 
					$dictvarCal_Core_Prelude_Eq_42 = null), 
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_43, 
					$dictvarCal_Core_Prelude_Eq_43 = null), 
				RTValue.lastRef(mapFn, mapFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.map
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Prelude_Eq_42, RTValue $dictvarCal_Core_Prelude_Eq_43, RTValue mapFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTCons $case1 = ((RTCons)(java.lang.Object)graph.evaluate($ec));

		// Cal.Utilities.DirectedGraph.DirectedGraph
		// Decompose data type to access members.
		TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar1 = 
			((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)$case1);

		int nextVertexNum$U = $dcCaseVar1.get_nextVertexNum_As_Int();
		RTValue vertexMap = $dcCaseVar1.get_vertexMap();
		RTValue edges = $dcCaseVar1.get_edges();
		RTValue letVar_mappedGraph = 
			Map.mappedGraph$6$def_Lazy(
				nextVertexNum$U, 
				mapFn, 
				vertexMap, 
				edges, 
				$ec);

		return 
			(((RTRecordValue)(java.lang.Object)
				Fold_Left_Strict.$instance.f3S(
					new RTPartialApp._3._1(
						Map__merge_If_Duplicate__8.$instance, 
						$dictvarCal_Core_Prelude_Eq_43), 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {Map.i_Nil, letVar_mappedGraph}), 
					Map.mapEntries$7$def_Strict(letVar_mappedGraph, $ec), 
					$ec).evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

}
