package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Insert_With;
import org.openquark.cal_Cal_Collections_Set.Single;
import org.openquark.cal_Cal_Collections_Set.Union;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Flatten_Components__insert_Edge__8 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Flatten_Components__insert_Edge__8 $instance = 
		new Flatten_Components__insert_Edge__8();

	private Flatten_Components__insert_Edge__8() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "flattenComponents$insertEdge$8";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.flattenComponents$insertEdge$8";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$insertEdge$8
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue edgePair = $rootNode.getArgValue();
		RTValue edges = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(edges.evaluate($ec), edges = null), 
				RTValue.lastRef(edgePair.evaluate($ec), edgePair = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$insertEdge$8
	 */
	public final RTValue f2L(RTValue edges, RTValue edgePair, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(edges.evaluate($ec), edges = null), 
				RTValue.lastRef(edgePair.evaluate($ec), edgePair = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents$insertEdge$8
	 */
	public final RTValue f2S(RTValue edges, RTValue edgePair, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)edgePair.getValue());
		RTValue startVertexNum = $recordCase1.getOrdinalFieldValue(1);
		RTValue endVertexNum = $recordCase1.getOrdinalFieldValue(2);

		return 
			Insert_With.$instance.f4S(
				new RTPartialApp._3._1(
					Union.$instance, 
					_dict___Ord___Int.$instance), 
				startVertexNum.evaluate($ec).getOrdinalValue(), 
				new RTFullApp.General._1._S(Single.$instance, endVertexNum), 
				edges.getValue(), 
				$ec);
	}

}
