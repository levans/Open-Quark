package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Filter extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Filter $instance = new Filter();

	private Filter() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "filter";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.filter";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filter
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue filterFn = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_15 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_15, 
					$dictvarCal_Core_Prelude_Eq_15 = null), 
				RTValue.lastRef(filterFn, filterFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filter
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_15, RTValue filterFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_15, 
					$dictvarCal_Core_Prelude_Eq_15 = null), 
				RTValue.lastRef(filterFn, filterFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filter
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_15, RTValue filterFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(((RTRecordValue)(java.lang.Object)
				Partition.$instance.f3S(
					$dictvarCal_Core_Prelude_Eq_15, 
					filterFn, 
					graph, 
					$ec).evaluate(
					$ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

}
