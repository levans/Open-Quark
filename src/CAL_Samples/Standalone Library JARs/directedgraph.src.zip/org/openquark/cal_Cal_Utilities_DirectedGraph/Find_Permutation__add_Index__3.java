package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_List.Find_Index;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find_Permutation__add_Index__3 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Permutation__add_Index__3 $instance = 
		new Find_Permutation__add_Index__3();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_findPermutation_1607_13 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"findPermutation", 
			1607, 
			13);

	private static final ErrorInfo Cal_Utilities_DirectedGraph_findPermutation_1610_17 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"findPermutation", 
			1610, 
			17);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Find_Permutation__add_Index__3() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findPermutation$addIndex$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.findPermutation$addIndex$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPermutation$addIndex$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue accum = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue elem1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue list2 = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_4 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_4, 
					$dictvarCal_Core_Prelude_Eq_4 = null), 
				RTValue.lastRef(list2, list2 = null), 
				RTValue.lastRef(elem1, elem1 = null), 
				RTValue.lastRef(accum, accum = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPermutation$addIndex$3
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Prelude_Eq_4, RTValue list2, RTValue elem1, RTValue accum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_4, 
					$dictvarCal_Core_Prelude_Eq_4 = null), 
				RTValue.lastRef(list2, list2 = null), 
				RTValue.lastRef(elem1, elem1 = null), 
				RTValue.lastRef(accum, accum = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findPermutation$addIndex$3
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Prelude_Eq_4, RTValue list2, RTValue elem1, RTValue accum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)accum.evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return Find_Permutation__add_Index__3.i_Nothing;
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue perm = $case1.get_value();

				TYPE_Maybe $case2;

				switch (($case2 = (((TYPE_Maybe)(java.lang.Object)Find_Index.$instance.f2S(new RTPartialApp._3._2(_lambda__find_Permutation__1.$instance, $dictvarCal_Core_Prelude_Eq_4, elem1), list2.evaluate($ec), $ec).evaluate($ec)))).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.Nothing
						return Find_Permutation__add_Index__3.i_Nothing;
					}

					case 1: {
						// Cal.Core.Prelude.Just
						// Decompose data type to access members.
						RTValue index = $case2.get_value();

						return 
							new TYPE_Maybe.CAL_Just(
								new TYPE_List.CAL_Cons(index, perm));
					}

					default: {
						return 
							badSwitchIndex(
								Find_Permutation__add_Index__3.Cal_Utilities_DirectedGraph_findPermutation_1610_17);
					}
				}
			}

			default: {
				return 
					badSwitchIndex(
						Find_Permutation__add_Index__3.Cal_Utilities_DirectedGraph_findPermutation_1607_13);
			}
		}
	}

}
