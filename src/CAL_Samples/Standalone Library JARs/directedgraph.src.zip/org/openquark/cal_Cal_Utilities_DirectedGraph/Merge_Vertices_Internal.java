package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Map;
import org.openquark.cal_Cal_Collections_IntMap.Update;
import org.openquark.cal_Cal_Collections_Set.Delete;
import org.openquark.cal_Cal_Core_Prelude.Compose;
import org.openquark.cal_Cal_Core_Prelude.Const__;
import org.openquark.cal_Cal_Core_Prelude.If;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Merge_Vertices_Internal extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Merge_Vertices_Internal $instance = 
		new Merge_Vertices_Internal();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Just i_Just = TYPE_Maybe.CAL_Just.make();

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Merge_Vertices_Internal() {
	}

	public final int getArity() {
		return 6;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mergeVerticesInternal";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.mergeVerticesInternal";
	}

	private static final RTValue without1To2$14$def_Lazy(RTValue vertex2Num, RTValue vertex1Num, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Update.$instance, 
				new RTPartialApp._3._2(
					Compose.$instance, 
					Merge_Vertices_Internal.i_Just, 
					new RTPartialApp._3._2(
						Delete.$instance, 
						_dict___Ord___Int.$instance, 
						vertex2Num)), 
				vertex1Num, 
				edges.getValue());
	}

	private static final RTValue without1To2$14$def_Strict(RTValue vertex2Num, RTValue vertex1Num, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Update.$instance.f3S(
				new RTPartialApp._3._2(
					Compose.$instance, 
					Merge_Vertices_Internal.i_Just, 
					new RTPartialApp._3._2(
						Delete.$instance, 
						_dict___Ord___Int.$instance, 
						vertex2Num)), 
				vertex1Num.evaluate($ec).getOrdinalValue(), 
				edges.getValue(), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue without2To1$15$def_Lazy(RTValue vertex2Num, RTValue vertex1Num, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Update.$instance, 
				new RTPartialApp._3._2(
					Compose.$instance, 
					Merge_Vertices_Internal.i_Just, 
					new RTPartialApp._3._2(
						Delete.$instance, 
						_dict___Ord___Int.$instance, 
						vertex1Num)), 
				vertex2Num, 
				Merge_Vertices_Internal.without1To2$14$def_Lazy(
					vertex2Num, 
					vertex1Num, 
					edges.getValue(), 
					$ec));
	}

	private static final RTValue without2To1$15$def_Strict(RTValue vertex2Num, RTValue vertex1Num, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Update.$instance.f3S(
				new RTPartialApp._3._2(
					Compose.$instance, 
					Merge_Vertices_Internal.i_Just, 
					new RTPartialApp._3._2(
						Delete.$instance, 
						_dict___Ord___Int.$instance, 
						vertex1Num)), 
				vertex2Num.evaluate($ec).getOrdinalValue(), 
				Merge_Vertices_Internal.without1To2$14$def_Strict(
					vertex2Num, 
					vertex1Num, 
					edges.getValue(), 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue filteredEdges$10$def_Lazy(RTValue retainLoops, RTValue edges, RTValue vertex2Num, RTValue vertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				If.$instance, 
				retainLoops, 
				edges.getValue(), 
				Merge_Vertices_Internal.without2To1$15$def_Lazy(
					vertex2Num, 
					vertex1Num, 
					edges.getValue(), 
					$ec));
	}

	private static final RTValue filteredEdges$10$def_Strict(RTValue retainLoops, RTValue edges, RTValue vertex2Num, RTValue vertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			retainLoops.evaluate($ec).getBooleanValue() ? 
			(((RTValue)(java.lang.Object)edges.getValue())) : 
			Merge_Vertices_Internal.without2To1$15$def_Strict(
				vertex2Num, 
				vertex1Num, 
				edges.getValue(), 
				$ec);
	}

	private static final RTValue outEdgesMerged$11$def_Lazy(RTValue retainLoops, RTValue edges, RTValue vertex2Num, RTValue vertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_filteredEdges = 
			Merge_Vertices_Internal.filteredEdges$10$def_Lazy(
				retainLoops, 
				edges.getValue(), 
				vertex2Num, 
				vertex1Num, 
				$ec);

		return 
			new RTFullApp.General._3._L(
				Update.$instance, 
				Merge_Vertices_Internal__update_Vertex2_Fn__17.$instance, 
				vertex2Num, 
				new RTFullApp.General._3._L(
					Update.$instance, 
					new RTPartialApp._3._2(
						Merge_Vertices_Internal__update_Vertex1_Fn__16.$instance, 
						vertex2Num, 
						letVar_filteredEdges), 
					vertex1Num, 
					letVar_filteredEdges));
	}

	private static final RTValue outEdgesMerged$11$def_Strict(RTValue retainLoops, RTValue edges, RTValue vertex2Num, RTValue vertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_filteredEdges = 
			Merge_Vertices_Internal.filteredEdges$10$def_Lazy(
				retainLoops, 
				edges.getValue(), 
				vertex2Num, 
				vertex1Num, 
				$ec);

		return 
			Update.$instance.f3S(
				Merge_Vertices_Internal__update_Vertex2_Fn__17.$instance, 
				vertex2Num.evaluate($ec).getOrdinalValue(), 
				Update.$instance.f3S(
					new RTPartialApp._3._2(
						Merge_Vertices_Internal__update_Vertex1_Fn__16.$instance, 
						vertex2Num, 
						letVar_filteredEdges), 
					vertex1Num.evaluate($ec).getOrdinalValue(), 
					letVar_filteredEdges.evaluate($ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue inEdgesMerged$12$def_Lazy(RTValue retainLoops, RTValue edges, RTValue vertex2Num, RTValue vertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Map.$instance, 
				new RTPartialApp._4._3(
					org.openquark.cal_Cal_Collections_Set.Map.$instance, 
					_dict___Ord___Int.$instance, 
					_dict___Ord___Int.$instance, 
					new RTPartialApp._3._2(
						Merge_Vertices_Internal__replace_Num__9.$instance, 
						vertex2Num, 
						vertex1Num)), 
				Merge_Vertices_Internal.outEdgesMerged$11$def_Lazy(
					retainLoops, 
					edges.getValue(), 
					vertex2Num, 
					vertex1Num, 
					$ec));
	}

	private static final RTValue inEdgesMerged$12$def_Strict(RTValue retainLoops, RTValue edges, RTValue vertex2Num, RTValue vertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Map.$instance.f2S(
				new RTPartialApp._4._3(
					org.openquark.cal_Cal_Collections_Set.Map.$instance, 
					_dict___Ord___Int.$instance, 
					_dict___Ord___Int.$instance, 
					new RTPartialApp._3._2(
						Merge_Vertices_Internal__replace_Num__9.$instance, 
						vertex2Num, 
						vertex1Num)), 
				Merge_Vertices_Internal.outEdgesMerged$11$def_Strict(
					retainLoops, 
					edges.getValue(), 
					vertex2Num, 
					vertex1Num, 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue mergedVertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue vertex2Num = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue vertex1Num = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue retainLoops = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue graph = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_3 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f6S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_3, 
					$dictvarCal_Core_Prelude_Eq_3 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(retainLoops, retainLoops = null), 
				RTValue.lastRef(vertex1Num, vertex1Num = null), 
				RTValue.lastRef(vertex2Num, vertex2Num = null), 
				RTValue.lastRef(mergedVertex, mergedVertex = null), 
				$ec);
	}

	/**
	 * f6L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal
	 */
	public final RTValue f6L(RTValue $dictvarCal_Core_Prelude_Eq_3, RTValue graph, RTValue retainLoops, RTValue vertex1Num, RTValue vertex2Num, RTValue mergedVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f6S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_3, 
					$dictvarCal_Core_Prelude_Eq_3 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(retainLoops, retainLoops = null), 
				RTValue.lastRef(vertex1Num, vertex1Num = null), 
				RTValue.lastRef(vertex2Num, vertex2Num = null), 
				RTValue.lastRef(mergedVertex, mergedVertex = null), 
				$ec);
	}

	/**
	 * f6S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal
	 */
	public final RTValue f6S(RTValue $dictvarCal_Core_Prelude_Eq_3, RTValue graph, RTValue retainLoops, RTValue vertex1Num, RTValue vertex2Num, RTValue mergedVertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTCons $case1 = ((RTCons)(java.lang.Object)graph.evaluate($ec));

		// Cal.Utilities.DirectedGraph.DirectedGraph
		// Decompose data type to access members.
		TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar1 = 
			((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)$case1);

		int nextVertexNum$U = $dcCaseVar1.get_nextVertexNum_As_Int();
		RTValue vertexMap = $dcCaseVar1.get_vertexMap();
		RTValue edges = $dcCaseVar1.get_edges();

		if (vertex1Num.evaluate($ec).getOrdinalValue() == 
		vertex2Num.evaluate($ec).getOrdinalValue()) {
			return 
				new TYPE_Directed_Graph.CAL_Directed_Graph(
					nextVertexNum$U, 
					Update.$instance.f3S(
						new RTPartialApp._2._1(
							Const__.$instance, 
							new TYPE_Maybe.CAL_Just(mergedVertex)), 
						vertex1Num.evaluate($ec).getOrdinalValue(), 
						vertexMap, 
						$ec).evaluate(
						$ec), 
					edges);
		} else {
			return 
				new TYPE_Directed_Graph.CAL_Directed_Graph(
					nextVertexNum$U, 
					Update.$instance.f3S(
						new RTPartialApp._2._1(
							Const__.$instance, 
							Merge_Vertices_Internal.i_Nothing), 
						vertex2Num.evaluate($ec).getOrdinalValue(), 
						Update.$instance.f3S(
							new RTPartialApp._2._1(
								Const__.$instance, 
								new TYPE_Maybe.CAL_Just(mergedVertex)), 
							vertex1Num.evaluate($ec).getOrdinalValue(), 
							vertexMap, 
							$ec).evaluate(
							$ec), 
						$ec).evaluate(
						$ec), 
					Merge_Vertices_Internal.inEdgesMerged$12$def_Strict(
						retainLoops, 
						edges, 
						vertex2Num, 
						vertex1Num, 
						$ec));
		}
	}

}
