package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.From_List;
import org.openquark.cal_Cal_Collections_IntMap.To_List;
import org.openquark.cal_Cal_Collections_List.All;
import org.openquark.cal_Cal_Collections_List.Unzip;
import org.openquark.cal_Cal_Core_Prelude.From_Just;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;
import org.openquark.cal_Cal_Core_Prelude.Zip;

public final class Equals_Directed_Graph_Ignore_Insertion_Order extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Equals_Directed_Graph_Ignore_Insertion_Order $instance = 
		new Equals_Directed_Graph_Ignore_Insertion_Order();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_equalsDirectedGraphIgnoreInsertionOrder_1664_69 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"equalsDirectedGraphIgnoreInsertionOrder", 
			1664, 
			69);

	private static final ErrorInfo Cal_Utilities_DirectedGraph_equalsDirectedGraphIgnoreInsertionOrder_1665_69 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"equalsDirectedGraphIgnoreInsertionOrder", 
			1665, 
			69);

	private Equals_Directed_Graph_Ignore_Insertion_Order() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "equalsDirectedGraphIgnoreInsertionOrder";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder";
	}

	private static final RTValue vertices1$4$def_Lazy(RTValue pattern_vertexNums1_vertices1, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_vertexNums1_vertices1, 2);
	}

	private static final RTValue vertices1$4$def_Strict(RTValue pattern_vertexNums1_vertices1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_vertexNums1_vertices1.evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue vertexNums1$3$def_Lazy(RTValue pattern_vertexNums1_vertices1, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_vertexNums1_vertices1, 1);
	}

	private static final RTValue vertexNums1$3$def_Strict(RTValue pattern_vertexNums1_vertices1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_vertexNums1_vertices1.evaluate(
					$ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue indexPerm$10$def_Lazy(RTValue maybeIndexPerm, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._1._L(From_Just.$instance, maybeIndexPerm);
	}

	private static final RTValue indexPerm$10$def_Strict(RTValue maybeIndexPerm, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(maybeIndexPerm.evaluate($ec), $ec).evaluate(
				$ec);
	}

	private static final RTValue vertexNumPerm$11$def_Lazy(RTValue maybeIndexPerm, RTValue pattern_vertexNums1_vertices1, RTValue vertexNums2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_List.$instance, 
				new RTFullApp.General._2._L(
					Zip.$instance, 
					new RTFullApp.General._2._S(
						Permute.$instance, 
						Equals_Directed_Graph_Ignore_Insertion_Order.indexPerm$10$def_Lazy(
							maybeIndexPerm, 
							$ec), 
						vertexNums2), 
					Equals_Directed_Graph_Ignore_Insertion_Order.vertexNums1$3$def_Lazy(
						pattern_vertexNums1_vertices1, 
						$ec)));
	}

	private static final RTValue vertexNumPerm$11$def_Strict(RTValue maybeIndexPerm, RTValue pattern_vertexNums1_vertices1, RTValue vertexNums2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_List.$instance.f1S(
				Zip.$instance.f2S(
					Permute.$instance.f2S(
						Equals_Directed_Graph_Ignore_Insertion_Order.indexPerm$10$def_Lazy(
							maybeIndexPerm, 
							$ec), 
						vertexNums2, 
						$ec).evaluate(
						$ec), 
					Equals_Directed_Graph_Ignore_Insertion_Order.vertexNums1$3$def_Lazy(
						pattern_vertexNums1_vertices1, 
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue vertices2$7$def_Lazy(RTValue pattern_vertexNums2_vertices2, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_vertexNums2_vertices2, 2);
	}

	private static final RTValue vertices2$7$def_Strict(RTValue pattern_vertexNums2_vertices2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_vertexNums2_vertices2.evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue edgesMatch$14$def_Lazy(RTValue maybeIndexPerm, RTValue pattern_vertexNums1_vertices1, RTValue vertexNums2, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				All.$instance, 
				new RTPartialApp._4._3(
					_lambda__equals_Directed_Graph_Ignore_Insertion_Order__1.$instance, 
					graph1, 
					Equals_Directed_Graph_Ignore_Insertion_Order.vertexNumPerm$11$def_Lazy(
						maybeIndexPerm, 
						pattern_vertexNums1_vertices1, 
						vertexNums2, 
						$ec), 
					graph2), 
				vertexNums2);
	}

	private static final RTValue edgesMatch$14$def_Strict(RTValue maybeIndexPerm, RTValue pattern_vertexNums1_vertices1, RTValue vertexNums2, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			All.$instance.f2S(
				new RTPartialApp._4._3(
					_lambda__equals_Directed_Graph_Ignore_Insertion_Order__1.$instance, 
					graph1, 
					Equals_Directed_Graph_Ignore_Insertion_Order.vertexNumPerm$11$def_Lazy(
						maybeIndexPerm, 
						pattern_vertexNums1_vertices1, 
						vertexNums2, 
						$ec), 
					graph2), 
				vertexNums2.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final boolean edgesMatch$14$def_Unboxed(RTValue maybeIndexPerm, RTValue pattern_vertexNums1_vertices1, RTValue vertexNums2, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			All.$instance.fUnboxed2S(
				new RTPartialApp._4._3(
					_lambda__equals_Directed_Graph_Ignore_Insertion_Order__1.$instance, 
					graph1, 
					Equals_Directed_Graph_Ignore_Insertion_Order.vertexNumPerm$11$def_Lazy(
						maybeIndexPerm, 
						pattern_vertexNums1_vertices1, 
						vertexNums2, 
						$ec), 
					graph2), 
				vertexNums2.evaluate($ec), 
				$ec);
	}

	private static final RTValue maybeIndexPerm$9$def_Lazy(RTValue pattern_vertexNums2_vertices2, RTValue pattern_vertexNums1_vertices1, RTValue $dictvarCal_Core_Prelude_Eq_5, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Find_Permutation.$instance, 
				$dictvarCal_Core_Prelude_Eq_5, 
				Equals_Directed_Graph_Ignore_Insertion_Order.vertices1$4$def_Lazy(
					pattern_vertexNums1_vertices1, 
					$ec), 
				Equals_Directed_Graph_Ignore_Insertion_Order.vertices2$7$def_Lazy(
					pattern_vertexNums2_vertices2, 
					$ec));
	}

	private static final RTValue maybeIndexPerm$9$def_Strict(RTValue pattern_vertexNums2_vertices2, RTValue pattern_vertexNums1_vertices1, RTValue $dictvarCal_Core_Prelude_Eq_5, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Find_Permutation.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_5, 
				Equals_Directed_Graph_Ignore_Insertion_Order.vertices1$4$def_Lazy(
					pattern_vertexNums1_vertices1, 
					$ec), 
				Equals_Directed_Graph_Ignore_Insertion_Order.vertices2$7$def_Lazy(
					pattern_vertexNums2_vertices2, 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue vertexNums2$6$def_Lazy(RTValue pattern_vertexNums2_vertices2, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_vertexNums2_vertices2, 1);
	}

	private static final RTValue vertexNums2$6$def_Strict(RTValue pattern_vertexNums2_vertices2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_vertexNums2_vertices2.evaluate(
					$ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_vertexNums2_vertices2$8$def_Lazy(RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				Unzip.$instance, 
				new RTFullApp.General._1._L(
					To_List.$instance, 
					new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
						graph2, 
						0, 
						1, 
						Equals_Directed_Graph_Ignore_Insertion_Order.Cal_Utilities_DirectedGraph_equalsDirectedGraphIgnoreInsertionOrder_1665_69)));
	}

	private static final RTValue $pattern_vertexNums2_vertices2$8$def_Strict(RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Unzip.$instance.f1S(
				To_List.$instance.f1S(
					(((RTCons)(java.lang.Object)
						graph2.evaluate($ec))).getFieldByIndex(
						0, 
						1, 
						Equals_Directed_Graph_Ignore_Insertion_Order.Cal_Utilities_DirectedGraph_equalsDirectedGraphIgnoreInsertionOrder_1665_69).evaluate(
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue $pattern_vertexNums1_vertices1$5$def_Lazy(RTValue graph1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				Unzip.$instance, 
				new RTFullApp.General._1._L(
					To_List.$instance, 
					new TYPE_Directed_Graph.CAL_Directed_Graph.FieldSelection(
						graph1, 
						0, 
						1, 
						Equals_Directed_Graph_Ignore_Insertion_Order.Cal_Utilities_DirectedGraph_equalsDirectedGraphIgnoreInsertionOrder_1664_69)));
	}

	private static final RTValue $pattern_vertexNums1_vertices1$5$def_Strict(RTValue graph1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Unzip.$instance.f1S(
				To_List.$instance.f1S(
					(((RTCons)(java.lang.Object)
						graph1.evaluate($ec))).getFieldByIndex(
						0, 
						1, 
						Equals_Directed_Graph_Ignore_Insertion_Order.Cal_Utilities_DirectedGraph_equalsDirectedGraphIgnoreInsertionOrder_1664_69).evaluate(
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph1 = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_5 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_5, 
					$dictvarCal_Core_Prelude_Eq_5 = null), 
				RTValue.lastRef(graph1, graph1 = null), 
				RTValue.lastRef(graph2, graph2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_5, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_5, 
					$dictvarCal_Core_Prelude_Eq_5 = null), 
				RTValue.lastRef(graph1, graph1 = null), 
				RTValue.lastRef(graph2, graph2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_5, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_pattern_vertexNums1_vertices1 = 
			Equals_Directed_Graph_Ignore_Insertion_Order.$pattern_vertexNums1_vertices1$5$def_Lazy(
				graph1, 
				$ec);
		RTValue letVar_pattern_vertexNums2_vertices2 = 
			Equals_Directed_Graph_Ignore_Insertion_Order.$pattern_vertexNums2_vertices2$8$def_Lazy(
				graph2, 
				$ec);
		RTValue letVar_maybeIndexPerm = 
			Equals_Directed_Graph_Ignore_Insertion_Order.maybeIndexPerm$9$def_Lazy(
				letVar_pattern_vertexNums2_vertices2, 
				letVar_pattern_vertexNums1_vertices1, 
				$dictvarCal_Core_Prelude_Eq_5, 
				$ec);

		// Top level supercombinator logic
		if (Is_Just.$instance.fUnboxed1S(
			letVar_maybeIndexPerm.evaluate($ec), 
			$ec)) {
			return 
				Equals_Directed_Graph_Ignore_Insertion_Order.edgesMatch$14$def_Lazy(
					letVar_maybeIndexPerm, 
					letVar_pattern_vertexNums1_vertices1, 
					Equals_Directed_Graph_Ignore_Insertion_Order.vertexNums2$6$def_Lazy(
						letVar_pattern_vertexNums2_vertices2, 
						$ec), 
					graph1, 
					graph2, 
					$ec);
		} else {
			return RTData.CAL_Boolean.make(false);
		}
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Eq_5, RTValue graph1, RTValue graph2, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_pattern_vertexNums1_vertices1 = 
			Equals_Directed_Graph_Ignore_Insertion_Order.$pattern_vertexNums1_vertices1$5$def_Lazy(
				graph1, 
				$ec);
		RTValue letVar_pattern_vertexNums2_vertices2 = 
			Equals_Directed_Graph_Ignore_Insertion_Order.$pattern_vertexNums2_vertices2$8$def_Lazy(
				graph2, 
				$ec);
		RTValue letVar_maybeIndexPerm = 
			Equals_Directed_Graph_Ignore_Insertion_Order.maybeIndexPerm$9$def_Lazy(
				letVar_pattern_vertexNums2_vertices2, 
				letVar_pattern_vertexNums1_vertices1, 
				$dictvarCal_Core_Prelude_Eq_5, 
				$ec);

		// Top level supercombinator logic
		if (Is_Just.$instance.fUnboxed1S(
			letVar_maybeIndexPerm.evaluate($ec), 
			$ec)) {
			return 
				Equals_Directed_Graph_Ignore_Insertion_Order.edgesMatch$14$def_Lazy(
					letVar_maybeIndexPerm, 
					letVar_pattern_vertexNums1_vertices1, 
					Equals_Directed_Graph_Ignore_Insertion_Order.vertexNums2$6$def_Lazy(
						letVar_pattern_vertexNums2_vertices2, 
						$ec), 
					graph1, 
					graph2, 
					$ec).evaluate(
					$ec).getBooleanValue();
		} else {
			return false;
		}
	}

}
