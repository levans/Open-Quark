package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.From_Maybe;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Merge_Vertices extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Merge_Vertices $instance = new Merge_Vertices();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_mergeVertices_740_33 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "mergeVertices", 740, 33);

	private static final ErrorInfo Cal_Utilities_DirectedGraph_mergeVertices_741_33 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "mergeVertices", 741, 33);

	private static final ErrorInfo Cal_Utilities_DirectedGraph_mergeVertices_745_9 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "mergeVertices", 745, 9);

	private Merge_Vertices() {
	}

	public final int getArity() {
		return 6;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mergeVertices";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.mergeVertices";
	}

	private static final RTValue vertex2Num$7$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue vertex2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				From_Maybe.$instance, 
				new RTError.RTAppS(
					RTError.$instance, 
					RTData.CAL_Opaque.make(
						Merge_Vertices.Cal_Utilities_DirectedGraph_mergeVertices_741_33), 
					"Second vertex is invalid."), 
				new RTFullApp.General._3._S(
					Get_Maybe_Vertex_Number.$instance, 
					$dictvarCal_Core_Prelude_Eq_48, 
					graph, 
					vertex2));
	}

	private static final RTValue vertex2Num$7$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue vertex2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Maybe.$instance.f2S(
				new RTError.RTAppS(
					RTError.$instance, 
					RTData.CAL_Opaque.make(
						Merge_Vertices.Cal_Utilities_DirectedGraph_mergeVertices_741_33), 
					"Second vertex is invalid."), 
				Get_Maybe_Vertex_Number.$instance.f3S(
					$dictvarCal_Core_Prelude_Eq_48, 
					graph, 
					vertex2, 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final int vertex2Num$7$def_Unboxed(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue vertex2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Maybe.$instance.f2S(
				new RTError.RTAppS(
					RTError.$instance, 
					RTData.CAL_Opaque.make(
						Merge_Vertices.Cal_Utilities_DirectedGraph_mergeVertices_741_33), 
					"Second vertex is invalid."), 
				Get_Maybe_Vertex_Number.$instance.f3S(
					$dictvarCal_Core_Prelude_Eq_48, 
					graph, 
					vertex2, 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue mergedWithEachother$8$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue vertex2, RTValue retainLoops, RTValue vertex1Num, RTValue mergedVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._6._S(
				Merge_Vertices_Internal.$instance, 
				$dictvarCal_Core_Prelude_Eq_48, 
				graph, 
				retainLoops, 
				vertex1Num, 
				Merge_Vertices.vertex2Num$7$def_Lazy(
					$dictvarCal_Core_Prelude_Eq_48, 
					graph, 
					vertex2, 
					$ec), 
				mergedVertex);
	}

	private static final RTValue mergedWithEachother$8$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue vertex2, RTValue retainLoops, RTValue vertex1Num, RTValue mergedVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Merge_Vertices_Internal.$instance.f6S(
				$dictvarCal_Core_Prelude_Eq_48, 
				graph, 
				retainLoops, 
				vertex1Num, 
				Merge_Vertices.vertex2Num$7$def_Lazy(
					$dictvarCal_Core_Prelude_Eq_48, 
					graph, 
					vertex2, 
					$ec), 
				mergedVertex, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue vertex1Num$6$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue vertex1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				From_Maybe.$instance, 
				new RTError.RTAppS(
					RTError.$instance, 
					RTData.CAL_Opaque.make(
						Merge_Vertices.Cal_Utilities_DirectedGraph_mergeVertices_740_33), 
					"First vertex is invalid."), 
				new RTFullApp.General._3._S(
					Get_Maybe_Vertex_Number.$instance, 
					$dictvarCal_Core_Prelude_Eq_48, 
					graph, 
					vertex1));
	}

	private static final RTValue vertex1Num$6$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue vertex1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Maybe.$instance.f2S(
				new RTError.RTAppS(
					RTError.$instance, 
					RTData.CAL_Opaque.make(
						Merge_Vertices.Cal_Utilities_DirectedGraph_mergeVertices_740_33), 
					"First vertex is invalid."), 
				Get_Maybe_Vertex_Number.$instance.f3S(
					$dictvarCal_Core_Prelude_Eq_48, 
					graph, 
					vertex1, 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final int vertex1Num$6$def_Unboxed(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue vertex1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Maybe.$instance.f2S(
				new RTError.RTAppS(
					RTError.$instance, 
					RTData.CAL_Opaque.make(
						Merge_Vertices.Cal_Utilities_DirectedGraph_mergeVertices_740_33), 
					"First vertex is invalid."), 
				Get_Maybe_Vertex_Number.$instance.f3S(
					$dictvarCal_Core_Prelude_Eq_48, 
					graph, 
					vertex1, 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec).getOrdinalValue();
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVertices
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue mergedVertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue vertex2 = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue vertex1 = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue retainLoops = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue graph = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_48 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f6S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_48, 
					$dictvarCal_Core_Prelude_Eq_48 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(retainLoops, retainLoops = null), 
				RTValue.lastRef(vertex1, vertex1 = null), 
				RTValue.lastRef(vertex2, vertex2 = null), 
				RTValue.lastRef(mergedVertex, mergedVertex = null), 
				$ec);
	}

	/**
	 * f6L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVertices
	 */
	public final RTValue f6L(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue retainLoops, RTValue vertex1, RTValue vertex2, RTValue mergedVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f6S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_48, 
					$dictvarCal_Core_Prelude_Eq_48 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(retainLoops, retainLoops = null), 
				RTValue.lastRef(vertex1, vertex1 = null), 
				RTValue.lastRef(vertex2, vertex2 = null), 
				RTValue.lastRef(mergedVertex, mergedVertex = null), 
				$ec);
	}

	/**
	 * f6S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVertices
	 */
	public final RTValue f6S(RTValue $dictvarCal_Core_Prelude_Eq_48, RTValue graph, RTValue retainLoops, RTValue vertex1, RTValue vertex2, RTValue mergedVertex, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_vertex1Num = 
			Merge_Vertices.vertex1Num$6$def_Lazy(
				$dictvarCal_Core_Prelude_Eq_48, 
				graph, 
				vertex1, 
				$ec);

		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)Get_Maybe_Vertex_Number.$instance.f3S($dictvarCal_Core_Prelude_Eq_48, graph, mergedVertex, $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return 
					Merge_Vertices.mergedWithEachother$8$def_Lazy(
						$dictvarCal_Core_Prelude_Eq_48, 
						graph, 
						vertex2, 
						retainLoops, 
						letVar_vertex1Num, 
						mergedVertex, 
						$ec);
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue mergedVertexNum = $case1.get_value();

				return 
					Merge_Vertices_Internal.$instance.f6S(
						$dictvarCal_Core_Prelude_Eq_48, 
						Merge_Vertices.mergedWithEachother$8$def_Lazy(
							$dictvarCal_Core_Prelude_Eq_48, 
							graph, 
							vertex2, 
							retainLoops, 
							letVar_vertex1Num, 
							mergedVertex, 
							$ec), 
						retainLoops, 
						mergedVertexNum, 
						letVar_vertex1Num, 
						mergedVertex, 
						$ec);
			}

			default: {
				return 
					badSwitchIndex(
						Merge_Vertices.Cal_Utilities_DirectedGraph_mergeVertices_745_9);
			}
		}
	}

}
