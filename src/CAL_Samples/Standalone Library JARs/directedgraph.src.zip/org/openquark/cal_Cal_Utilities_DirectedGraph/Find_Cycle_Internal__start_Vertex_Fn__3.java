package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Find_Cycle_Internal__start_Vertex_Fn__3 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Cycle_Internal__start_Vertex_Fn__3 $instance = 
		new Find_Cycle_Internal__start_Vertex_Fn__3();

	private Find_Cycle_Internal__start_Vertex_Fn__3() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findCycleInternal$startVertexFn$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.findCycleInternal$startVertexFn$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal$startVertexFn$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNum = $rootNode.getArgValue();
		RTValue accum = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal$startVertexFn$3
	 */
	public final RTValue f2L(RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.findCycleInternal$startVertexFn$3
	 */
	public final RTValue f2S(RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)accum.evaluate($ec));
		RTValue path = $recordCase1.getOrdinalFieldValue(1);
		RTValue isCycle = $recordCase1.getOrdinalFieldValue(2);

		if (isCycle.evaluate($ec).getBooleanValue()) {
			return accum;
		} else {
			return 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {new TYPE_List.CAL_Cons(vertexNum, path), isCycle});
		}
	}

}
