package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Fold_R;
import org.openquark.cal_Cal_Collections_IntMap.From_List;
import org.openquark.cal_Cal_Core_Prelude.Map;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Reverse extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Reverse $instance = new Reverse();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Reverse() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "reverse";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.reverse";
	}

	private static final RTValue reversedTuples$5$def_Lazy(RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new Fold_R.RTAppS(
				Fold_R.$instance, 
				_lambda__reverse__2.$instance, 
				Reverse.i_Nil, 
				edges.getValue());
	}

	private static final RTValue reversedTuples$5$def_Strict(RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_R.$instance.f3S(
				_lambda__reverse__2.$instance, 
				Reverse.i_Nil, 
				edges.getValue(), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue reversedNeighbourLists$6$def_Lazy(RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Group_By_First.$instance, 
				_dict___Ord___Int.$instance, 
				_dict___Ord___Int.$instance, 
				Reverse.reversedTuples$5$def_Lazy(edges.getValue(), $ec));
	}

	private static final RTValue reversedNeighbourLists$6$def_Strict(RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Group_By_First.$instance.f3S(
				_dict___Ord___Int.$instance, 
				_dict___Ord___Int.$instance, 
				Reverse.reversedTuples$5$def_Lazy(edges.getValue(), $ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue reversedNeighbourSets$7$def_Lazy(RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Map.$instance, 
				_lambda__reverse__3.$instance, 
				Reverse.reversedNeighbourLists$6$def_Lazy(
					edges.getValue(), 
					$ec));
	}

	private static final RTValue reversedNeighbourSets$7$def_Strict(RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Map.$instance.f2S(
				_lambda__reverse__3.$instance, 
				Reverse.reversedNeighbourLists$6$def_Strict(
					edges.getValue(), 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue reversedEdges$8$def_Lazy(RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_List.$instance, 
				Reverse.reversedNeighbourSets$7$def_Lazy(edges.getValue(), $ec));
	}

	private static final RTValue reversedEdges$8$def_Strict(RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_List.$instance.f1S(
				Reverse.reversedNeighbourSets$7$def_Strict(
					edges.getValue(), 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.reverse
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_28 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_28, 
					$dictvarCal_Core_Prelude_Eq_28 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.reverse
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_28, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_28, 
					$dictvarCal_Core_Prelude_Eq_28 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.reverse
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_28, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTCons $case1 = ((RTCons)(java.lang.Object)graph.evaluate($ec));

		// Cal.Utilities.DirectedGraph.DirectedGraph
		// Decompose data type to access members.
		TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar1 = 
			((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)$case1);

		int nextVertexNum$U = $dcCaseVar1.get_nextVertexNum_As_Int();
		RTValue vertexMap = $dcCaseVar1.get_vertexMap();
		RTValue edges = $dcCaseVar1.get_edges();

		return 
			new TYPE_Directed_Graph.CAL_Directed_Graph(
				nextVertexNum$U, 
				vertexMap, 
				Reverse.reversedEdges$8$def_Strict(edges, $ec));
	}

}
