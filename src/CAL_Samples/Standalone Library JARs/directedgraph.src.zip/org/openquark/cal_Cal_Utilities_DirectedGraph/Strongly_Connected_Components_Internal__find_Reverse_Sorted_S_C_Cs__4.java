package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4 $instance = 
		new Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4()
;

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_stronglyConnectedComponentsInternal_1179_13 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"stronglyConnectedComponentsInternal", 
			1179, 
			13);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "stronglyConnectedComponentsInternal$findReverseSortedSCCs$4";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.stronglyConnectedComponentsInternal$findReverseSortedSCCs$4";
	}

	private static final RTValue component$11$def_Lazy(RTValue pattern_newVisited_component, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_newVisited_component, 2);
	}

	private static final RTValue component$11$def_Strict(RTValue pattern_newVisited_component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_newVisited_component.evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue newVertexNums$14$def_Lazy(RTValue newVisited, RTValue ns, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._S(
				Filter_List_Strict.$instance, 
				new RTPartialApp._2._1(
					_lambda__strongly_Connected_Components_Internal__1.$instance, 
					newVisited), 
				ns);
	}

	private static final RTValue newVertexNums$14$def_Strict(RTValue newVisited, RTValue ns, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Filter_List_Strict.$instance.f2S(
				new RTPartialApp._2._1(
					_lambda__strongly_Connected_Components_Internal__1.$instance, 
					newVisited), 
				ns, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue newComponents$13$def_Lazy(RTValue pattern_newVisited_component, RTValue components, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new TYPE_List.CAL_Cons(
				Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.component$11$def_Lazy(
					pattern_newVisited_component, 
					$ec), 
				components.getValue());
	}

	private static final RTValue newComponents$13$def_Strict(RTValue pattern_newVisited_component, RTValue components, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new TYPE_List.CAL_Cons(
				Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.component$11$def_Lazy(
					pattern_newVisited_component, 
					$ec), 
				components.getValue());
	}

	private static final RTValue newVisited$10$def_Lazy(RTValue pattern_newVisited_component, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_newVisited_component, 1);
	}

	private static final RTValue newVisited$10$def_Strict(RTValue pattern_newVisited_component, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_newVisited_component.evaluate(
					$ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_newVisited_component$12$def_Lazy(RTValue dfsHelper, RTValue n, RTValue visited, RTExecutionContext $ec) throws CALExecutorException {
		return 
			dfsHelper.apply(
				n, 
				visited.getValue(), 
				Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.i_Nil);
	}

	private static final RTValue $pattern_newVisited_component$12$def_Strict(RTValue dfsHelper, RTValue n, RTValue visited, RTExecutionContext $ec) throws CALExecutorException {
		return 
			dfsHelper.f3L(
				n, 
				visited.getValue(), 
				Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.i_Nil, 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponentsInternal$findReverseSortedSCCs$4
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNums = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue components = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue visited = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue dfsHelper = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(dfsHelper, dfsHelper = null), 
				RTValue.lastRef(visited.evaluate($ec), visited = null), 
				RTValue.lastRef(components.evaluate($ec), components = null), 
				RTValue.lastRef(vertexNums.evaluate($ec), vertexNums = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponentsInternal$findReverseSortedSCCs$4
	 */
	public final RTValue f4L(RTValue dfsHelper, RTValue visited, RTValue components, RTValue vertexNums, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(dfsHelper, dfsHelper = null), 
				RTValue.lastRef(visited.evaluate($ec), visited = null), 
				RTValue.lastRef(components.evaluate($ec), components = null), 
				RTValue.lastRef(vertexNums.evaluate($ec), vertexNums = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponentsInternal$findReverseSortedSCCs$4
	 */
	public final RTValue f4S(RTValue dfsHelper, RTValue visited, RTValue components, RTValue vertexNums, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)vertexNums.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return components.getValue();
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue n = $case1.get_head();
					RTValue ns = $case1.get_tail();
					RTValue letVar_pattern_newVisited_component = 
						Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.$pattern_newVisited_component$12$def_Lazy(
							dfsHelper, 
							n, 
							visited.getValue(), 
							$ec);
					RTValue letVar_newVisited = 
						Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.newVisited$10$def_Lazy(
							letVar_pattern_newVisited_component, 
							$ec);

					RTValue visited$ = letVar_newVisited.evaluate($ec);
					visited = visited$;
						components = 
						Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.newComponents$13$def_Strict(
							letVar_pattern_newVisited_component, 
							components.getValue(), 
							$ec);
						vertexNums = 
						Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.newVertexNums$14$def_Strict(
							letVar_newVisited, 
							ns, 
							$ec);
					continue TRLoop;
				}

				default: {
					return 
						badSwitchIndex(
							Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.Cal_Utilities_DirectedGraph_stronglyConnectedComponentsInternal_1179_13);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4 function;

		private RTValue stronglyConnectedComponentsInternal$dfsHelper$3;

		private RTValue stronglyConnectedComponentsInternal$visited$5;

		private RTValue stronglyConnectedComponentsInternal$components$6;

		private RTValue stronglyConnectedComponentsInternal$vertexNums$7;

		public RTAppS(Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4 $function, RTValue $stronglyConnectedComponentsInternal$dfsHelper$3, RTValue $stronglyConnectedComponentsInternal$visited$5, RTValue $stronglyConnectedComponentsInternal$components$6, RTValue $stronglyConnectedComponentsInternal$vertexNums$7) {
			assert (
				(((($function != null) && 
				($stronglyConnectedComponentsInternal$dfsHelper$3 != null)) && 
				($stronglyConnectedComponentsInternal$visited$5 != null)) && 
				($stronglyConnectedComponentsInternal$components$6 != null)) && 
				($stronglyConnectedComponentsInternal$vertexNums$7 != null)) : (badConsArgMsg());
			function = $function;
				stronglyConnectedComponentsInternal$dfsHelper$3 = 
				$stronglyConnectedComponentsInternal$dfsHelper$3;
				stronglyConnectedComponentsInternal$visited$5 = 
				$stronglyConnectedComponentsInternal$visited$5;
				stronglyConnectedComponentsInternal$components$6 = 
				$stronglyConnectedComponentsInternal$components$6;
				stronglyConnectedComponentsInternal$vertexNums$7 = 
				$stronglyConnectedComponentsInternal$vertexNums$7;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f4S(
						RTValue.lastRef(
							stronglyConnectedComponentsInternal$dfsHelper$3, 
								stronglyConnectedComponentsInternal$dfsHelper$3 = 
								null), 
						RTValue.lastRef(
							stronglyConnectedComponentsInternal$visited$5, 
								stronglyConnectedComponentsInternal$visited$5 = 
								null), 
						RTValue.lastRef(
							stronglyConnectedComponentsInternal$components$6, 
								stronglyConnectedComponentsInternal$components$6 = 
								null), 
						RTValue.lastRef(
							stronglyConnectedComponentsInternal$vertexNums$7, 
								stronglyConnectedComponentsInternal$vertexNums$7 = 
								null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			stronglyConnectedComponentsInternal$dfsHelper$3 = null;
			stronglyConnectedComponentsInternal$visited$5 = null;
			stronglyConnectedComponentsInternal$components$6 = null;
			stronglyConnectedComponentsInternal$vertexNums$7 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 4;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return stronglyConnectedComponentsInternal$dfsHelper$3;
				}

				case 1: {
					return stronglyConnectedComponentsInternal$visited$5;
				}

				case 2: {
					return stronglyConnectedComponentsInternal$components$6;
				}

				case 3: {
					return stronglyConnectedComponentsInternal$vertexNums$7;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 4)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
