package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Add_Edge extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Edge $instance = new Add_Edge();

	private Add_Edge() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addEdge";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.addEdge";
	}

	private static final RTValue partiallyUpdatedGraph$6$def_Lazy(RTValue pattern_partiallyUpdatedGraph_startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTRecordSelection.Ordinal(
				pattern_partiallyUpdatedGraph_startVertexNum, 
				1);
	}

	private static final RTValue partiallyUpdatedGraph$6$def_Strict(RTValue pattern_partiallyUpdatedGraph_startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_partiallyUpdatedGraph_startVertexNum.evaluate(
					$ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue endVertexNum$10$def_Lazy(RTValue pattern_updatedGraph_endVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTRecordSelection.Ordinal(pattern_updatedGraph_endVertexNum, 2);
	}

	private static final RTValue endVertexNum$10$def_Strict(RTValue pattern_updatedGraph_endVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_updatedGraph_endVertexNum.evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final int endVertexNum$10$def_Unboxed(RTValue pattern_updatedGraph_endVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_updatedGraph_endVertexNum.evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue endVertex$4$def_Lazy(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(newEdge, 2);
	}

	private static final RTValue endVertex$4$def_Strict(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				newEdge.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue updatedGraph$9$def_Lazy(RTValue pattern_updatedGraph_endVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTRecordSelection.Ordinal(pattern_updatedGraph_endVertexNum, 1);
	}

	private static final RTValue updatedGraph$9$def_Strict(RTValue pattern_updatedGraph_endVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_updatedGraph_endVertexNum.evaluate(
					$ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_updatedGraph_endVertexNum$11$def_Lazy(RTValue newEdge, RTValue pattern_partiallyUpdatedGraph_startVertexNum, RTValue $dictvarCal_Core_Prelude_Eq_11, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Add_Vertex_Internal.$instance, 
				$dictvarCal_Core_Prelude_Eq_11, 
				Add_Edge.partiallyUpdatedGraph$6$def_Lazy(
					pattern_partiallyUpdatedGraph_startVertexNum, 
					$ec), 
				Add_Edge.endVertex$4$def_Lazy(newEdge, $ec));
	}

	private static final RTValue $pattern_updatedGraph_endVertexNum$11$def_Strict(RTValue newEdge, RTValue pattern_partiallyUpdatedGraph_startVertexNum, RTValue $dictvarCal_Core_Prelude_Eq_11, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Add_Vertex_Internal.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_11, 
				Add_Edge.partiallyUpdatedGraph$6$def_Lazy(
					pattern_partiallyUpdatedGraph_startVertexNum, 
					$ec), 
				Add_Edge.endVertex$4$def_Lazy(newEdge, $ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue startVertex$3$def_Lazy(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(newEdge, 1);
	}

	private static final RTValue startVertex$3$def_Strict(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				newEdge.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue startVertexNum$7$def_Lazy(RTValue pattern_partiallyUpdatedGraph_startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTRecordSelection.Ordinal(
				pattern_partiallyUpdatedGraph_startVertexNum, 
				2);
	}

	private static final RTValue startVertexNum$7$def_Strict(RTValue pattern_partiallyUpdatedGraph_startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_partiallyUpdatedGraph_startVertexNum.evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final int startVertexNum$7$def_Unboxed(RTValue pattern_partiallyUpdatedGraph_startVertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_partiallyUpdatedGraph_startVertexNum.evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue $pattern_partiallyUpdatedGraph_startVertexNum$8$def_Lazy(RTValue newEdge, RTValue $dictvarCal_Core_Prelude_Eq_11, RTValue oldGraph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Add_Vertex_Internal.$instance, 
				$dictvarCal_Core_Prelude_Eq_11, 
				oldGraph, 
				Add_Edge.startVertex$3$def_Lazy(newEdge, $ec));
	}

	private static final RTValue $pattern_partiallyUpdatedGraph_startVertexNum$8$def_Strict(RTValue newEdge, RTValue $dictvarCal_Core_Prelude_Eq_11, RTValue oldGraph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Add_Vertex_Internal.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_11, 
				oldGraph, 
				Add_Edge.startVertex$3$def_Lazy(newEdge, $ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdge
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue newEdge = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue oldGraph = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_11 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_11, 
					$dictvarCal_Core_Prelude_Eq_11 = null), 
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(newEdge, newEdge = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdge
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_11, RTValue oldGraph, RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_11, 
					$dictvarCal_Core_Prelude_Eq_11 = null), 
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(newEdge, newEdge = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdge
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_11, RTValue oldGraph, RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_pattern_partiallyUpdatedGraph_startVertexNum = 
			Add_Edge.$pattern_partiallyUpdatedGraph_startVertexNum$8$def_Lazy(
				newEdge, 
				$dictvarCal_Core_Prelude_Eq_11, 
				oldGraph, 
				$ec);
		RTValue letVar_pattern_updatedGraph_endVertexNum = 
			Add_Edge.$pattern_updatedGraph_endVertexNum$11$def_Lazy(
				newEdge, 
				letVar_pattern_partiallyUpdatedGraph_startVertexNum, 
				$dictvarCal_Core_Prelude_Eq_11, 
				$ec);

		// Top level supercombinator logic
		return 
			Add_Edge_Internal.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_11, 
				Add_Edge.updatedGraph$9$def_Lazy(
					letVar_pattern_updatedGraph_endVertexNum, 
					$ec), 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {Add_Edge.startVertexNum$7$def_Lazy(letVar_pattern_partiallyUpdatedGraph_startVertexNum, $ec), Add_Edge.endVertexNum$10$def_Lazy(letVar_pattern_updatedGraph_endVertexNum, $ec)}), 
				$ec);
	}

}
