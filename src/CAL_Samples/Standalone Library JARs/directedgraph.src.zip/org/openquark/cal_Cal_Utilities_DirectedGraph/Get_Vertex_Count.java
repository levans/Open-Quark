package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.Size;

public final class Get_Vertex_Count extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Vertex_Count $instance = new Get_Vertex_Count();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_getVertexCount_134_22 = 
		new ErrorInfo("Cal.Utilities.DirectedGraph", "getVertexCount", 134, 22);

	private Get_Vertex_Count() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getVertexCount";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.getVertexCount";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getVertexCount
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getVertexCount
	 */
	public final RTValue f1L(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.getVertexCount
	 */
	public final RTValue f1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Size.$instance.f1S(
				(((RTCons)(java.lang.Object)
					graph.evaluate($ec))).getFieldByIndex(
					0, 
					1, 
					Get_Vertex_Count.Cal_Utilities_DirectedGraph_getVertexCount_134_22).evaluate(
					$ec), 
				$ec);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.getVertexCount
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Size.$instance.f1S(
				(((RTCons)(java.lang.Object)
					graph.evaluate($ec))).getFieldByIndex(
					0, 
					1, 
					Get_Vertex_Count.Cal_Utilities_DirectedGraph_getVertexCount_134_22).evaluate(
					$ec), 
				$ec).evaluate(
				$ec).getOrdinalValue();
	}

}
