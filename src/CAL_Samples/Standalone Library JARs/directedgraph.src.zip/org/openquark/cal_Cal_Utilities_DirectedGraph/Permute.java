package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Map_Indexed;

public final class Permute extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Permute $instance = new Permute();

	private Permute() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "permute";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.permute";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.permute
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue oldList = $rootNode.getArgValue();
		RTValue perm = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(perm, perm = null), 
				RTValue.lastRef(oldList, oldList = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.permute
	 */
	public final RTValue f2L(RTValue perm, RTValue oldList, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(perm, perm = null), 
				RTValue.lastRef(oldList, oldList = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.permute
	 */
	public final RTValue f2S(RTValue perm, RTValue oldList, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Map_Indexed.$instance.f2S(
				new RTPartialApp._4._2(
					_lambda__permute__1.$instance, 
					oldList, 
					perm), 
				oldList.evaluate($ec), 
				$ec);
	}

}
