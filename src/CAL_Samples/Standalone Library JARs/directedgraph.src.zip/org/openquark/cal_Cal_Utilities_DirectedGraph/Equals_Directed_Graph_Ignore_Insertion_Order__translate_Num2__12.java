package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Find;

public final class Equals_Directed_Graph_Ignore_Insertion_Order__translate_Num2__12 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Equals_Directed_Graph_Ignore_Insertion_Order__translate_Num2__12 $instance = 
		new Equals_Directed_Graph_Ignore_Insertion_Order__translate_Num2__12();

	private Equals_Directed_Graph_Ignore_Insertion_Order__translate_Num2__12() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "equalsDirectedGraphIgnoreInsertionOrder$translateNum2$12";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$translateNum2$12";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$translateNum2$12
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue num2 = $rootNode.getArgValue();
		RTValue vertexNumPerm = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					vertexNumPerm.evaluate($ec), 
					vertexNumPerm = null), 
				RTValue.lastRef(num2, num2 = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$translateNum2$12
	 */
	public final RTValue f2L(RTValue vertexNumPerm, RTValue num2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					vertexNumPerm.evaluate($ec), 
					vertexNumPerm = null), 
				RTValue.lastRef(num2, num2 = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$translateNum2$12
	 */
	public final RTValue f2S(RTValue vertexNumPerm, RTValue num2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Find.$instance.f2S(
				num2.evaluate($ec).getOrdinalValue(), 
				vertexNumPerm.getValue(), 
				$ec);
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.equalsDirectedGraphIgnoreInsertionOrder$translateNum2$12
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed2S(RTValue vertexNumPerm, RTValue num2, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = f2S(vertexNumPerm, num2, $ec);

		vertexNumPerm = null;
		num2 = null;
		return $result.evaluate($ec).getOrdinalValue();
	}

}
