package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_Set.TYPE_Set;
import org.openquark.cal_Cal_Core_Prelude.Const__;
import org.openquark.cal_Cal_Core_Prelude.Flip;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Strongly_Connected_Components_Internal extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Strongly_Connected_Components_Internal $instance = 
		new Strongly_Connected_Components_Internal();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Cons i_Cons = TYPE_List.CAL_Cons.make();

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Strongly_Connected_Components_Internal() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "stronglyConnectedComponentsInternal";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.stronglyConnectedComponentsInternal";
	}

	private static final RTValue dfsHelper$3$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_40, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTPartialApp._7._4(
				Perform_D_F_S.$instance, 
				new RTPartialApp._2._1(
					Get_Neighbour_List.$instance, 
					new RTFullApp.General._2._S(
						Reverse.$instance, 
						$dictvarCal_Core_Prelude_Eq_40, 
						graph)), 
				new RTPartialApp._3._1(
					Flip.$instance, 
					Strongly_Connected_Components_Internal.i_Cons), 
				Const__.$instance, 
				Const__.$instance);
	}

	private static final RTValue dfsHelper$3$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_40, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTPartialApp._7._4(
				Perform_D_F_S.$instance, 
				new RTPartialApp._2._1(
					Get_Neighbour_List.$instance, 
					new RTFullApp.General._2._S(
						Reverse.$instance, 
						$dictvarCal_Core_Prelude_Eq_40, 
						graph)), 
				new RTPartialApp._3._1(
					Flip.$instance, 
					Strongly_Connected_Components_Internal.i_Cons), 
				Const__.$instance, 
				Const__.$instance);
	}

	private static final RTValue verticesByFinisingTime$2$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_40, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._7._S(
				Fold_D_F_S_Internal.$instance, 
				$dictvarCal_Core_Prelude_Eq_40, 
				Strongly_Connected_Components_Internal.i_Nothing, 
				Const__.$instance, 
				Const__.$instance, 
				new RTPartialApp._3._1(
					Flip.$instance, 
					Strongly_Connected_Components_Internal.i_Cons), 
				Strongly_Connected_Components_Internal.i_Nil, 
				graph);
	}

	private static final RTValue verticesByFinisingTime$2$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_40, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_D_F_S_Internal.$instance.f7S(
				$dictvarCal_Core_Prelude_Eq_40, 
				Strongly_Connected_Components_Internal.i_Nothing, 
				Const__.$instance, 
				Const__.$instance, 
				new RTPartialApp._3._1(
					Flip.$instance, 
					Strongly_Connected_Components_Internal.i_Cons), 
				Strongly_Connected_Components_Internal.i_Nil, 
				graph, 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponentsInternal
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_40 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_40, 
					$dictvarCal_Core_Prelude_Eq_40 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponentsInternal
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_40, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_40, 
					$dictvarCal_Core_Prelude_Eq_40 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.stronglyConnectedComponentsInternal
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_40, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Collections_List.Reverse.$instance.f1S(
				Strongly_Connected_Components_Internal__find_Reverse_Sorted_S_C_Cs__4.$instance.f4S(
					Strongly_Connected_Components_Internal.dfsHelper$3$def_Lazy(
						$dictvarCal_Core_Prelude_Eq_40, 
						graph, 
						$ec), 
					Strongly_Connected_Components_Internal.i_Tip, 
					Strongly_Connected_Components_Internal.i_Nil, 
					Strongly_Connected_Components_Internal.verticesByFinisingTime$2$def_Strict(
						$dictvarCal_Core_Prelude_Eq_40, 
						graph, 
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec);
	}

}
