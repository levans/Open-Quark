package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Insert_With;
import org.openquark.cal_Cal_Collections_Set.From_Distinct_Asc_List;
import org.openquark.cal_Cal_Collections_Set.Union;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;
import org.openquark.cal_Cal_Core_Prelude.Is_Empty_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Add_Edges__add_New_Endpoints_For_Vertex__4 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Edges__add_New_Endpoints_For_Vertex__4 $instance = 
		new Add_Edges__add_New_Endpoints_For_Vertex__4();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Add_Edges__add_New_Endpoints_For_Vertex__4() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addEdges$addNewEndpointsForVertex$4";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.addEdges$addNewEndpointsForVertex$4";
	}

	private static final RTValue vertex1$9$def_Lazy(RTValue pair1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pair1.getValue())).getOrdinalFieldValue(
				2);
	}

	private static final RTValue vertex1$9$def_Strict(RTValue pair1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pair1.getValue())).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue newEndpoints$14$def_Lazy(RTValue relevantPairs, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._L(
				From_Distinct_Asc_List.$instance, 
				new RTFullApp.General._3._L(
					Fold_Left_Strict.$instance, 
					Add_Edges__extract_Vertex_Nums__12.$instance, 
					Add_Edges__add_New_Endpoints_For_Vertex__4.i_Nil, 
					relevantPairs));
	}

	private static final RTValue newEndpoints$14$def_Strict(RTValue relevantPairs, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Distinct_Asc_List.$instance.f1S(
				Fold_Left_Strict.$instance.f3S(
					Add_Edges__extract_Vertex_Nums__12.$instance, 
					Add_Edges__add_New_Endpoints_For_Vertex__4.i_Nil, 
					relevantPairs.evaluate($ec), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue relevantPairs$13$def_Lazy(RTValue pair1, RTValue existsEdgeFn, RTValue vertexPairs, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Fold_Left_Strict.$instance, 
				new RTPartialApp._4._2(
					Add_Edges__accumulate_Existing_Edges__11.$instance, 
					existsEdgeFn, 
					Add_Edges__add_New_Endpoints_For_Vertex__4.vertex1$9$def_Lazy(
						pair1.getValue(), 
						$ec)), 
				Add_Edges__add_New_Endpoints_For_Vertex__4.i_Nil, 
				vertexPairs);
	}

	private static final RTValue relevantPairs$13$def_Strict(RTValue pair1, RTValue existsEdgeFn, RTValue vertexPairs, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_Left_Strict.$instance.f3S(
				new RTPartialApp._4._2(
					Add_Edges__accumulate_Existing_Edges__11.$instance, 
					existsEdgeFn, 
					Add_Edges__add_New_Endpoints_For_Vertex__4.vertex1$9$def_Lazy(
						pair1.getValue(), 
						$ec)), 
				Add_Edges__add_New_Endpoints_For_Vertex__4.i_Nil, 
				vertexPairs.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue vertexNum1$8$def_Lazy(RTValue pair1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pair1.getValue())).getOrdinalFieldValue(
				1);
	}

	private static final RTValue vertexNum1$8$def_Strict(RTValue pair1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pair1.getValue())).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final int vertexNum1$8$def_Unboxed(RTValue pair1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pair1.getValue())).getOrdinalFieldValue(
				1).evaluate(
				$ec).getOrdinalValue();
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$addNewEndpointsForVertex$4
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue pair1 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue vertexPairs = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue existsEdgeFn = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				RTValue.lastRef(vertexPairs, vertexPairs = null), 
				RTValue.lastRef(graph.evaluate($ec), graph = null), 
				RTValue.lastRef(pair1.evaluate($ec), pair1 = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$addNewEndpointsForVertex$4
	 */
	public final RTValue f4L(RTValue existsEdgeFn, RTValue vertexPairs, RTValue graph, RTValue pair1, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				RTValue.lastRef(vertexPairs, vertexPairs = null), 
				RTValue.lastRef(graph.evaluate($ec), graph = null), 
				RTValue.lastRef(pair1.evaluate($ec), pair1 = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$addNewEndpointsForVertex$4
	 */
	public final RTValue f4S(RTValue existsEdgeFn, RTValue vertexPairs, RTValue graph, RTValue pair1, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_relevantPairs = 
			Add_Edges__add_New_Endpoints_For_Vertex__4.relevantPairs$13$def_Lazy(
				pair1.getValue(), 
				existsEdgeFn, 
				vertexPairs, 
				$ec);

		// Top level supercombinator logic
		if (Is_Empty_List.$instance.fUnboxed1S(
			letVar_relevantPairs.evaluate($ec), 
			$ec)) {
			return graph.getValue();
		} else {

			RTCons $case2 = ((RTCons)(java.lang.Object)graph.getValue());

			// Cal.Utilities.DirectedGraph.DirectedGraph
			// Decompose data type to access members.
			TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar2 = 
				((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)
					$case2);

			int nextVertexNum$U = $dcCaseVar2.get_nextVertexNum_As_Int();
			RTValue vertexMap = $dcCaseVar2.get_vertexMap();
			RTValue oldEdges = $dcCaseVar2.get_edges();

			return 
				new TYPE_Directed_Graph.CAL_Directed_Graph(
					nextVertexNum$U, 
					vertexMap, 
					Insert_With.$instance.f4S(
						new RTPartialApp._3._1(
							Union.$instance, 
							_dict___Ord___Int.$instance), 
						Add_Edges__add_New_Endpoints_For_Vertex__4.vertexNum1$8$def_Unboxed(
							pair1.getValue(), 
							$ec), 
						Add_Edges__add_New_Endpoints_For_Vertex__4.newEndpoints$14$def_Lazy(
							letVar_relevantPairs, 
							$ec), 
						oldEdges, 
						$ec).evaluate(
						$ec));
		}
	}

}
