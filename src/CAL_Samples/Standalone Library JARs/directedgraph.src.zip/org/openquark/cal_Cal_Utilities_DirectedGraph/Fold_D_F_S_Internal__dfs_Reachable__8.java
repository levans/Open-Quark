package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal_Cal_Collections_Set.TYPE_Set;

public final class Fold_D_F_S_Internal__dfs_Reachable__8 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Fold_D_F_S_Internal__dfs_Reachable__8 $instance = 
		new Fold_D_F_S_Internal__dfs_Reachable__8();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Fold_D_F_S_Internal__dfs_Reachable__8() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "foldDFSInternal$dfsReachable$8";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.foldDFSInternal$dfsReachable$8";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal$dfsReachable$8
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNum$L = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue init = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue dfsHelper = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(dfsHelper, dfsHelper = null), 
				RTValue.lastRef(init, init = null), 
				vertexNum$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal$dfsReachable$8
	 */
	public final RTValue f3L(RTValue dfsHelper, RTValue init, RTValue vertexNum$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(dfsHelper, dfsHelper = null), 
				RTValue.lastRef(init, init = null), 
				vertexNum$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.foldDFSInternal$dfsReachable$8
	 */
	public final RTValue f3S(RTValue dfsHelper, RTValue init, int vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(((RTRecordValue)(java.lang.Object)
				dfsHelper.f3L(
					RTData.CAL_Int.make(vertexNum), 
					Fold_D_F_S_Internal__dfs_Reachable__8.i_Tip, 
					init, 
					$ec).evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	public static final class RTAppS extends RTFullApp {
		private final Fold_D_F_S_Internal__dfs_Reachable__8 function;

		private RTValue foldDFSInternal$dfsHelper$7;

		private RTValue foldDFSInternal$init$5;

		private int foldDFSInternal$vertexNum$10;

		public RTAppS(Fold_D_F_S_Internal__dfs_Reachable__8 $function, RTValue $foldDFSInternal$dfsHelper$7, RTValue $foldDFSInternal$init$5, int $foldDFSInternal$vertexNum$10) {
			assert (
				(($function != null) && 
				($foldDFSInternal$dfsHelper$7 != null)) && 
				($foldDFSInternal$init$5 != null)) : (badConsArgMsg());
			function = $function;
			foldDFSInternal$dfsHelper$7 = $foldDFSInternal$dfsHelper$7;
			foldDFSInternal$init$5 = $foldDFSInternal$init$5;
			foldDFSInternal$vertexNum$10 = $foldDFSInternal$vertexNum$10;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							foldDFSInternal$dfsHelper$7, 
							foldDFSInternal$dfsHelper$7 = null), 
						RTValue.lastRef(
							foldDFSInternal$init$5, 
							foldDFSInternal$init$5 = null), 
						foldDFSInternal$vertexNum$10, 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			foldDFSInternal$dfsHelper$7 = null;
			foldDFSInternal$init$5 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return foldDFSInternal$dfsHelper$7;
				}

				case 1: {
					return foldDFSInternal$init$5;
				}

				case 2: {
					return RTData.CAL_Int.make(foldDFSInternal$vertexNum$10);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
