package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Merge_Vertices_Internal__replace_Num__9 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Merge_Vertices_Internal__replace_Num__9 $instance = 
		new Merge_Vertices_Internal__replace_Num__9();

	private Merge_Vertices_Internal__replace_Num__9() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mergeVerticesInternal$replaceNum$9";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.mergeVerticesInternal$replaceNum$9";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$replaceNum$9
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue num = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue vertex1Num = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue vertex2Num = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(vertex2Num, vertex2Num = null), 
				RTValue.lastRef(vertex1Num, vertex1Num = null), 
				RTValue.lastRef(num, num = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$replaceNum$9
	 */
	public final RTValue f3L(RTValue vertex2Num, RTValue vertex1Num, RTValue num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(vertex2Num, vertex2Num = null), 
				RTValue.lastRef(vertex1Num, vertex1Num = null), 
				RTValue.lastRef(num, num = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$replaceNum$9
	 */
	public final RTValue f3S(RTValue vertex2Num, RTValue vertex1Num, RTValue num, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (num.evaluate($ec).getOrdinalValue() == 
		vertex2Num.evaluate($ec).getOrdinalValue()) {
			return vertex1Num;
		} else {
			return num;
		}
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$replaceNum$9
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed3S(RTValue vertex2Num, RTValue vertex1Num, RTValue num, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (num.evaluate($ec).getOrdinalValue() == 
		vertex2Num.evaluate($ec).getOrdinalValue()) {
			return vertex1Num.evaluate($ec).getOrdinalValue();
		} else {
			return num.evaluate($ec).getOrdinalValue();
		}
	}

}
