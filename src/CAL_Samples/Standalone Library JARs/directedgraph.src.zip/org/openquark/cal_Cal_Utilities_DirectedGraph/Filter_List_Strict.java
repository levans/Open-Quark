package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Reverse;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Filter_List_Strict extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Filter_List_Strict $instance = new Filter_List_Strict();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Filter_List_Strict() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "filterListStrict";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.filterListStrict";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filterListStrict
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue elements = $rootNode.getArgValue();
		RTValue pred = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(pred, pred = null), 
				RTValue.lastRef(elements, elements = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filterListStrict
	 */
	public final RTValue f2L(RTValue pred, RTValue elements, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(pred, pred = null), 
				RTValue.lastRef(elements, elements = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filterListStrict
	 */
	public final RTValue f2S(RTValue pred, RTValue elements, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Reverse.$instance.f1S(
				Fold_Left_Strict.$instance.f3S(
					new RTPartialApp._3._1(
						Filter_List_Strict__possibly_Cons__3.$instance, 
						pred), 
					Filter_List_Strict.i_Nil, 
					elements.evaluate($ec), 
					$ec).evaluate(
					$ec), 
				$ec);
	}

}
