package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Find;
import org.openquark.cal_Cal_Collections_List.Subscript;

public final class _lambda__permute__1 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__permute__1 $instance = 
		new _lambda__permute__1();

	private _lambda__permute__1() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$permute$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$permute$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$permute$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue index = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue element = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue perm = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue oldList = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(oldList, oldList = null), 
				RTValue.lastRef(perm, perm = null), 
				RTValue.lastRef(element, element = null), 
				RTValue.lastRef(index, index = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$permute$1
	 */
	public final RTValue f4L(RTValue oldList, RTValue perm, RTValue element, RTValue index, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(oldList, oldList = null), 
				RTValue.lastRef(perm, perm = null), 
				RTValue.lastRef(element, element = null), 
				RTValue.lastRef(index, index = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$permute$1
	 */
	public final RTValue f4S(RTValue oldList, RTValue perm, RTValue element, RTValue index, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Subscript.RTAppS(
				Subscript.$instance, 
				oldList.evaluate($ec), 
				Find.$instance.f2S(
					index.evaluate($ec).getOrdinalValue(), 
					perm.evaluate($ec), 
					$ec).evaluate(
					$ec).getOrdinalValue());
	}

}
