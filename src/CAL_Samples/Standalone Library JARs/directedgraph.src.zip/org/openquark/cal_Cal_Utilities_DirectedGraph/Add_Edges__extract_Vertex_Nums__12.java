package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Add_Edges__extract_Vertex_Nums__12 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Edges__extract_Vertex_Nums__12 $instance = 
		new Add_Edges__extract_Vertex_Nums__12();

	private Add_Edges__extract_Vertex_Nums__12() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addEdges$extractVertexNums$12";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.addEdges$extractVertexNums$12";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$extractVertexNums$12
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue next = $rootNode.getArgValue();
		RTValue accum = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				RTValue.lastRef(next.evaluate($ec), next = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$extractVertexNums$12
	 */
	public final RTValue f2L(RTValue accum, RTValue next, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				RTValue.lastRef(next.evaluate($ec), next = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdges$extractVertexNums$12
	 */
	public final RTValue f2S(RTValue accum, RTValue next, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new TYPE_List.CAL_Cons(
				(((RTRecordValue)(java.lang.Object)
					next.getValue())).getOrdinalFieldValue(
					1), 
				accum.getValue());
	}

}
