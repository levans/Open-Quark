package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Filter_List_Strict__possibly_Cons__3 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Filter_List_Strict__possibly_Cons__3 $instance = 
		new Filter_List_Strict__possibly_Cons__3();

	private Filter_List_Strict__possibly_Cons__3() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "filterListStrict$possiblyCons$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.filterListStrict$possiblyCons$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filterListStrict$possiblyCons$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue next = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue accum = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue pred = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(pred, pred = null), 
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				RTValue.lastRef(next.evaluate($ec), next = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filterListStrict$possiblyCons$3
	 */
	public final RTValue f3L(RTValue pred, RTValue accum, RTValue next, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(pred, pred = null), 
				RTValue.lastRef(accum.evaluate($ec), accum = null), 
				RTValue.lastRef(next.evaluate($ec), next = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.filterListStrict$possiblyCons$3
	 */
	public final RTValue f3S(RTValue pred, RTValue accum, RTValue next, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (pred.f1L(next.getValue(), $ec).evaluate($ec).getBooleanValue()) {
			return new TYPE_List.CAL_Cons(next.getValue(), accum.getValue());
		} else {
			return accum.getValue();
		}
	}

}
