package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Update;
import org.openquark.cal_Cal_Core_Prelude.From_Just;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;

public final class Remove_Edge extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Remove_Edge $instance = new Remove_Edge();

	private Remove_Edge() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "removeEdge";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.removeEdge";
	}

	private static final RTValue vertex2$4$def_Lazy(RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(edge, 2);
	}

	private static final RTValue vertex2$4$def_Strict(RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				edge.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue vertex2Num$9$def_Lazy(RTValue maybeVertex2Num, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._1._L(From_Just.$instance, maybeVertex2Num);
	}

	private static final RTValue vertex2Num$9$def_Strict(RTValue maybeVertex2Num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeVertex2Num.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final int vertex2Num$9$def_Unboxed(RTValue maybeVertex2Num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeVertex2Num.evaluate($ec), 
				$ec).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue maybeVertex2Num$8$def_Lazy(RTValue edge, RTValue $dictvarCal_Core_Prelude_Eq_31, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Get_Maybe_Vertex_Number.$instance, 
				$dictvarCal_Core_Prelude_Eq_31, 
				graph, 
				Remove_Edge.vertex2$4$def_Lazy(edge, $ec));
	}

	private static final RTValue maybeVertex2Num$8$def_Strict(RTValue edge, RTValue $dictvarCal_Core_Prelude_Eq_31, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Get_Maybe_Vertex_Number.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_31, 
				graph, 
				Remove_Edge.vertex2$4$def_Lazy(edge, $ec), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue vertex1$3$def_Lazy(RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(edge, 1);
	}

	private static final RTValue vertex1$3$def_Strict(RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				edge.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue vertex1Num$7$def_Lazy(RTValue maybeVertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._1._L(From_Just.$instance, maybeVertex1Num);
	}

	private static final RTValue vertex1Num$7$def_Strict(RTValue maybeVertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeVertex1Num.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	private static final int vertex1Num$7$def_Unboxed(RTValue maybeVertex1Num, RTExecutionContext $ec) throws CALExecutorException {
		return 
			From_Just.$instance.f1S(
				maybeVertex1Num.evaluate($ec), 
				$ec).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue maybeVertex1Num$6$def_Lazy(RTValue edge, RTValue $dictvarCal_Core_Prelude_Eq_31, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Get_Maybe_Vertex_Number.$instance, 
				$dictvarCal_Core_Prelude_Eq_31, 
				graph, 
				Remove_Edge.vertex1$3$def_Lazy(edge, $ec));
	}

	private static final RTValue maybeVertex1Num$6$def_Strict(RTValue edge, RTValue $dictvarCal_Core_Prelude_Eq_31, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Get_Maybe_Vertex_Number.$instance.f3S(
				$dictvarCal_Core_Prelude_Eq_31, 
				graph, 
				Remove_Edge.vertex1$3$def_Lazy(edge, $ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeEdge
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue edge = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_31 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_31, 
					$dictvarCal_Core_Prelude_Eq_31 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(edge, edge = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeEdge
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_31, RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_31, 
					$dictvarCal_Core_Prelude_Eq_31 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(edge, edge = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeEdge
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_31, RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_maybeVertex1Num = 
			Remove_Edge.maybeVertex1Num$6$def_Lazy(
				edge, 
				$dictvarCal_Core_Prelude_Eq_31, 
				graph, 
				$ec);
		RTValue letVar_maybeVertex2Num = 
			Remove_Edge.maybeVertex2Num$8$def_Lazy(
				edge, 
				$dictvarCal_Core_Prelude_Eq_31, 
				graph, 
				$ec);

		// Top level supercombinator logic
		if (Is_Just.$instance.fUnboxed1S(
			letVar_maybeVertex1Num.evaluate($ec), 
			$ec) && 
		Is_Just.$instance.fUnboxed1S(letVar_maybeVertex2Num.evaluate($ec), $ec)) {

			RTCons $case2 = ((RTCons)(java.lang.Object)graph.evaluate($ec));

			// Cal.Utilities.DirectedGraph.DirectedGraph
			// Decompose data type to access members.
			TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar2 = 
				((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)
					$case2);

			int nextVertexNum$U = $dcCaseVar2.get_nextVertexNum_As_Int();
			RTValue vertexMap = $dcCaseVar2.get_vertexMap();
			RTValue edges = $dcCaseVar2.get_edges();

			return 
				new TYPE_Directed_Graph.CAL_Directed_Graph(
					nextVertexNum$U, 
					vertexMap, 
					Update.$instance.f3S(
						new RTPartialApp._2._1(
							Remove_Edge__delete_Dest__10.$instance, 
							Remove_Edge.vertex2Num$9$def_Lazy(
								letVar_maybeVertex2Num, 
								$ec)), 
						Remove_Edge.vertex1Num$7$def_Unboxed(
							letVar_maybeVertex1Num, 
							$ec), 
						edges, 
						$ec).evaluate(
						$ec));
		} else {
			return graph;
		}
	}

}
