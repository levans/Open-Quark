package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_Set.From_Distinct_Asc_List;

public final class _lambda__reverse__3 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__reverse__3 $instance = 
		new _lambda__reverse__3();

	private _lambda__reverse__3() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$reverse$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$reverse$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue pair = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(pair, pair = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$3
	 */
	public final RTValue f1L(RTValue pair, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(pair, pair = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$reverse$3
	 */
	public final RTValue f1S(RTValue pair, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTRecordValue.makeTupleRecord(
				new RTValue[] {new RTRecordSelection.Ordinal(pair, 1), new RTFullApp.General._1._L(From_Distinct_Asc_List.$instance, new RTRecordSelection.Ordinal(pair, 2))});
	}

}
