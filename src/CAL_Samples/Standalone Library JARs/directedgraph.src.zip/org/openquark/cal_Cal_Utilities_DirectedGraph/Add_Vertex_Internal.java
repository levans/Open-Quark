package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_IntMap.Insert;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Add_Vertex_Internal extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Vertex_Internal $instance = 
		new Add_Vertex_Internal();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Utilities_DirectedGraph_addVertexInternal_419_5 = 
		new ErrorInfo(
			"Cal.Utilities.DirectedGraph", 
			"addVertexInternal", 
			419, 
			5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Directed_Graph.CAL_Directed_Graph i_DirectedGraph = 
		TYPE_Directed_Graph.CAL_Directed_Graph.make();

	private Add_Vertex_Internal() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addVertexInternal";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.addVertexInternal";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addVertexInternal
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue newVertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue oldGraph = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_9 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_9, 
					$dictvarCal_Core_Prelude_Eq_9 = null), 
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(newVertex, newVertex = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addVertexInternal
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_9, RTValue oldGraph, RTValue newVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_9, 
					$dictvarCal_Core_Prelude_Eq_9 = null), 
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(newVertex, newVertex = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addVertexInternal
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_9, RTValue oldGraph, RTValue newVertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)Get_Maybe_Vertex_Number.$instance.f3S($dictvarCal_Core_Prelude_Eq_9, oldGraph, newVertex, $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing

				RTCons $case2 = 
					((RTCons)(java.lang.Object)oldGraph.evaluate($ec));

				// Cal.Utilities.DirectedGraph.DirectedGraph
				// Decompose data type to access members.
				TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar2 = 
					((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)
						$case2);

				int oldNextNum$U = $dcCaseVar2.get_nextVertexNum_As_Int();
				RTValue oldVertexMap = $dcCaseVar2.get_vertexMap();
				RTValue oldEdges = $dcCaseVar2.get_edges();

				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {new RTFullApp.General._3._L(Add_Vertex_Internal.i_DirectedGraph, RTData.CAL_Int.make(oldNextNum$U + 1), new Insert.RTAppS(Insert.$instance, oldNextNum$U, newVertex, oldVertexMap), oldEdges), RTData.CAL_Int.make(oldNextNum$U)});
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue vertexNum = $case1.get_value();

				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {oldGraph, vertexNum});
			}

			default: {
				return 
					badSwitchIndex(
						Add_Vertex_Internal.Cal_Utilities_DirectedGraph_addVertexInternal_419_5);
			}
		}
	}

}
