package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Is_Just;

public final class Contains_Vertex extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Contains_Vertex $instance = new Contains_Vertex();

	private Contains_Vertex() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "containsVertex";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.containsVertex";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsVertex
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue graph = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_37 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_37, 
					$dictvarCal_Core_Prelude_Eq_37 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsVertex
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_37, RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_37, 
					$dictvarCal_Core_Prelude_Eq_37 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.containsVertex
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_37, RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Is_Just.$instance.f1S(
				Get_Maybe_Vertex_Number.$instance.f3S(
					$dictvarCal_Core_Prelude_Eq_37, 
					graph, 
					vertex, 
					$ec).evaluate(
					$ec), 
				$ec);
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.containsVertex
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Eq_37, RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = 
			f3S($dictvarCal_Core_Prelude_Eq_37, graph, vertex, $ec);

		$dictvarCal_Core_Prelude_Eq_37 = null;
		graph = null;
		vertex = null;
		return $result.evaluate($ec).getBooleanValue();
	}

}
