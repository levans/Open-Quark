package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;

public final class Make_Graph extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Make_Graph $instance = new Make_Graph();

	private Make_Graph() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "makeGraph";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.makeGraph";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.makeGraph
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue edges = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue vertices = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_13 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_13, 
					$dictvarCal_Core_Prelude_Eq_13 = null), 
				RTValue.lastRef(vertices, vertices = null), 
				RTValue.lastRef(edges, edges = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.makeGraph
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_13, RTValue vertices, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_13, 
					$dictvarCal_Core_Prelude_Eq_13 = null), 
				RTValue.lastRef(vertices, vertices = null), 
				RTValue.lastRef(edges, edges = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.makeGraph
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_13, RTValue vertices, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Fold_Left_Strict.RTAppS(
				Fold_Left_Strict.$instance, 
				new RTPartialApp._3._1(
					Add_Edge.$instance, 
					$dictvarCal_Core_Prelude_Eq_13), 
				Edgeless_Graph.$instance.f2S(
					$dictvarCal_Core_Prelude_Eq_13, 
					vertices, 
					$ec).evaluate(
					$ec), 
				edges.evaluate($ec));
	}

}
