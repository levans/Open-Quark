package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;
import org.openquark.cal_Cal_Core_Prelude._dict___Num___Int;

public final class Show_Directed_Graph extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_String $L1_String_ = 
		RTData.CAL_String.make("");

	/**
	 * Singleton instance of this class.
	 */
	public static final Show_Directed_Graph $instance = 
		new Show_Directed_Graph();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Show_Directed_Graph() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "showDirectedGraph";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.showDirectedGraph";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue $dictvarCal_Core_Prelude_Eq_34 = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Debug_Show_33 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Debug_Show_33, 
					$dictvarCal_Core_Debug_Show_33 = null), 
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_34, 
					$dictvarCal_Core_Prelude_Eq_34 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Debug_Show_33, RTValue $dictvarCal_Core_Prelude_Eq_34, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Debug_Show_33, 
					$dictvarCal_Core_Debug_Show_33 = null), 
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_34, 
					$dictvarCal_Core_Prelude_Eq_34 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Debug_Show_33, RTValue $dictvarCal_Core_Prelude_Eq_34, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(((RTRecordValue)(java.lang.Object)
				Fold_D_F_S_Internal.$instance.f7S(
					$dictvarCal_Core_Prelude_Eq_34, 
					Show_Directed_Graph.i_Nothing, 
					new RTPartialApp._4._2(
						_lambda__show_Directed_Graph__1.$instance, 
						$dictvarCal_Core_Debug_Show_33, 
						graph), 
					new RTPartialApp._4._2(
						_lambda__show_Directed_Graph__2.$instance, 
						$dictvarCal_Core_Debug_Show_33, 
						graph), 
					_lambda__show_Directed_Graph__3.$instance, 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {new RTFullApp.General._1._S(Show_Directed_Graph__base_Indent__2.$instance, _dict___Num___Int.$instance), Show_Directed_Graph.$L1_String_}), 
					graph, 
					$ec).evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.showDirectedGraph
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.String fUnboxed3S(RTValue $dictvarCal_Core_Debug_Show_33, RTValue $dictvarCal_Core_Prelude_Eq_34, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(((RTRecordValue)(java.lang.Object)
				Fold_D_F_S_Internal.$instance.f7S(
					$dictvarCal_Core_Prelude_Eq_34, 
					Show_Directed_Graph.i_Nothing, 
					new RTPartialApp._4._2(
						_lambda__show_Directed_Graph__1.$instance, 
						$dictvarCal_Core_Debug_Show_33, 
						graph), 
					new RTPartialApp._4._2(
						_lambda__show_Directed_Graph__2.$instance, 
						$dictvarCal_Core_Debug_Show_33, 
						graph), 
					_lambda__show_Directed_Graph__3.$instance, 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {new RTFullApp.General._1._S(Show_Directed_Graph__base_Indent__2.$instance, _dict___Num___Int.$instance), Show_Directed_Graph.$L1_String_}), 
					graph, 
					$ec).evaluate(
					$ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec).getStringValue();
	}

}
