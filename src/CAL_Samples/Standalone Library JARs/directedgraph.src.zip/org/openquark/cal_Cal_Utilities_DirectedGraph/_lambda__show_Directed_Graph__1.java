package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Add_Int;
import org.openquark.cal_Cal_Core_Prelude.Append_String;
import org.openquark.cal_Cal_Core_Prelude._dict___Num___Int;

public final class _lambda__show_Directed_Graph__1 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_String $L1_String_N = 
		RTData.CAL_String.make(" {\n");

	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__show_Directed_Graph__1 $instance = 
		new _lambda__show_Directed_Graph__1();

	private _lambda__show_Directed_Graph__1() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$showDirectedGraph$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$showDirectedGraph$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$showDirectedGraph$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertexNum = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue accum = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue graph = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Debug_Show_33 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Debug_Show_33, 
					$dictvarCal_Core_Debug_Show_33 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$showDirectedGraph$1
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Debug_Show_33, RTValue graph, RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Debug_Show_33, 
					$dictvarCal_Core_Debug_Show_33 = null), 
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(accum, accum = null), 
				RTValue.lastRef(vertexNum, vertexNum = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$showDirectedGraph$1
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Debug_Show_33, RTValue graph, RTValue accum, RTValue vertexNum, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)accum.evaluate($ec));
		RTValue indent = $recordCase1.getOrdinalFieldValue(1);
		RTValue text = $recordCase1.getOrdinalFieldValue(2);

		return 
			RTRecordValue.makeTupleRecord(
				new RTValue[] {new RTFullApp.General._2._L(Add_Int.$instance, indent, new RTFullApp.General._1._S(Show_Directed_Graph__indent_Diff__3.$instance, _dict___Num___Int.$instance)), new RTFullApp.General._2._L(Append_String.$instance, text, new RTFullApp.General._2._L(Append_String.$instance, new RTFullApp.General._1._S(Show_Directed_Graph__make_Indent_String__4.$instance, indent), new RTFullApp.General._2._L(Append_String.$instance, $dictvarCal_Core_Debug_Show_33.apply(new RTFullApp.General._2._S(Get_Vertex.$instance, graph, vertexNum)), _lambda__show_Directed_Graph__1.$L1_String_N)))});
	}

}
