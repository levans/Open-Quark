package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_Set.Delete;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Remove_Edge__delete_Dest__10 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Remove_Edge__delete_Dest__10 $instance = 
		new Remove_Edge__delete_Dest__10();

	private Remove_Edge__delete_Dest__10() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "removeEdge$deleteDest$10";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.removeEdge$deleteDest$10";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeEdge$deleteDest$10
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue destSet = $rootNode.getArgValue();
		RTValue vertex2Num = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(vertex2Num, vertex2Num = null), 
				RTValue.lastRef(destSet, destSet = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeEdge$deleteDest$10
	 */
	public final RTValue f2L(RTValue vertex2Num, RTValue destSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(vertex2Num, vertex2Num = null), 
				RTValue.lastRef(destSet, destSet = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.removeEdge$deleteDest$10
	 */
	public final RTValue f2S(RTValue vertex2Num, RTValue destSet, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new TYPE_Maybe.CAL_Just(
				new RTFullApp.General._3._L(
					Delete.$instance, 
					_dict___Ord___Int.$instance, 
					vertex2Num, 
					destSet));
	}

}
