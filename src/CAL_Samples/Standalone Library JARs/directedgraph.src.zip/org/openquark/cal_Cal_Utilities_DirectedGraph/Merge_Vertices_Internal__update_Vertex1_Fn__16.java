package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Lookup_With_Default;
import org.openquark.cal_Cal_Collections_Set.TYPE_Set;
import org.openquark.cal_Cal_Collections_Set.Union;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Merge_Vertices_Internal__update_Vertex1_Fn__16 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Merge_Vertices_Internal__update_Vertex1_Fn__16 $instance = 
		new Merge_Vertices_Internal__update_Vertex1_Fn__16();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Merge_Vertices_Internal__update_Vertex1_Fn__16() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mergeVerticesInternal$updateVertex1Fn$16";
	}

	public final java.lang.String getQualifiedName() {
		return 
			"Cal.Utilities.DirectedGraph.mergeVerticesInternal$updateVertex1Fn$16";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$updateVertex1Fn$16
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue destSet = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue filteredEdges = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue vertex2Num = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(vertex2Num, vertex2Num = null), 
				RTValue.lastRef(filteredEdges, filteredEdges = null), 
				RTValue.lastRef(destSet, destSet = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$updateVertex1Fn$16
	 */
	public final RTValue f3L(RTValue vertex2Num, RTValue filteredEdges, RTValue destSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(vertex2Num, vertex2Num = null), 
				RTValue.lastRef(filteredEdges, filteredEdges = null), 
				RTValue.lastRef(destSet, destSet = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.mergeVerticesInternal$updateVertex1Fn$16
	 */
	public final RTValue f3S(RTValue vertex2Num, RTValue filteredEdges, RTValue destSet, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new TYPE_Maybe.CAL_Just(
				new RTFullApp.General._3._L(
					Union.$instance, 
					_dict___Ord___Int.$instance, 
					destSet, 
					new RTFullApp.General._3._L(
						Lookup_With_Default.$instance, 
						vertex2Num, 
						filteredEdges, 
						Merge_Vertices_Internal__update_Vertex1_Fn__16.i_Tip)));
	}

}
