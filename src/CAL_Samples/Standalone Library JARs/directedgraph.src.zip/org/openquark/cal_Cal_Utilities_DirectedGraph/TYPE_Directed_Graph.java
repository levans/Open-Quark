package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTDataConsFieldSelection;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public abstract class TYPE_Directed_Graph extends RTCons {
	final int _nextVertexNum;

	final RTValue _vertexMap;

	final RTValue _edges;

	protected TYPE_Directed_Graph() {
		_nextVertexNum = (-1);
		_vertexMap = null;
		_edges = null;
	}

	protected TYPE_Directed_Graph(int _nextVertexNum$, RTValue _vertexMap$, RTValue _edges$) {
		_nextVertexNum = _nextVertexNum$;
		_vertexMap = _vertexMap$;
		_edges = _edges$;
	}

	public RTValue get_nextVertexNum() {
		return RTData.CAL_Int.make(_nextVertexNum);
	}

	public RTValue get_vertexMap() {
		return _vertexMap;
	}

	public RTValue get_edges() {
		return _edges;
	}

	public int get_nextVertexNum_As_Int() throws CALExecutorException {
		return _nextVertexNum;
	}

	protected final java.lang.String getDCNameByOrdinal(int dcOrdinal) {
		switch (dcOrdinal) {

			case 0: {
				return "DirectedGraph";
			}

		}
		return 
			((java.lang.String)(java.lang.Object)
				RTValue.badValue_Object(
					null, 
					"Invalid DC ordinal in getDCNameByOrdinal() for org.openquark.cal_Cal_Utilities_DirectedGraph.TYPE_Directed_Graph"));
	}

	public static final class CAL_Directed_Graph extends TYPE_Directed_Graph {
		public static final CAL_Directed_Graph $instance = 
			new CAL_Directed_Graph();

		private CAL_Directed_Graph() {
		}

		public CAL_Directed_Graph(int member0, RTValue member1, RTValue member2) {
			super (member0, member1, member2);
			assert ((member1 != null) && (member2 != null)) : (
					"Invalid constructor argument for Cal.Utilities.DirectedGraph.DirectedGraph");
		}

		public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
			// Arguments
			RTValue $arg2 = $rootNode.getArgValue();
			RTValue $currentRootNode;
			RTValue $arg1 = 
				($currentRootNode = $rootNode.prevArg()).getArgValue();
			RTValue $arg0 = $currentRootNode.prevArg().getArgValue();

			return 
				new CAL_Directed_Graph(
					$arg0.evaluate($ec).getOrdinalValue(), 
					$arg1.evaluate($ec), 
					$arg2.evaluate($ec));
		}

		public final RTValue f3L(RTValue member0, RTValue member1, RTValue member2, RTExecutionContext $ec) throws CALExecutorException {
			return 
				new CAL_Directed_Graph(
					member0.evaluate($ec).getOrdinalValue(), 
					member1.evaluate($ec), 
					member2.evaluate($ec));
		}

		public final int getArity() {
			return 3;
		}

		public int getOrdinalValue() {
			return 0;
		}

		public static final CAL_Directed_Graph make() {
			return CAL_Directed_Graph.$instance;
		}

		public final RTValue buildDeepSeq(RTSupercombinator deepSeq, RTValue rhs) throws CALExecutorException {
			return deepSeq.apply(_vertexMap, deepSeq.apply(_edges, rhs));
		}

		public final RTValue getFieldByIndex(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return RTData.CAL_Int.make(_nextVertexNum);
				}

				case 1: {
					return get_vertexMap();
				}

				case 2: {
					return get_edges();
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return null;
		}

		public final int getFieldByIndex_As_Int(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return _nextVertexNum;
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return -1;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Utilities.DirectedGraph";
		}

		public final java.lang.String getUnqualifiedName() {
			return "DirectedGraph";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Utilities.DirectedGraph.DirectedGraph";
		}

		public final boolean isFunctionSingleton() {
			return this == CAL_Directed_Graph.$instance;
		}

		public final CalValue debug_getChild(int childN) {
			if (isFunctionSingleton()) {
				throw new java.lang.IndexOutOfBoundsException();
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(_nextVertexNum);
				}

				case 1: {
					return _vertexMap;
				}

				case 2: {
					return _edges;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

					case 0: {
						return "nextVertexNum";
					}

					case 1: {
						return "vertexMap";
					}

					case 2: {
						return "edges";
					}

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Utilities.DirectedGraph.DirectedGraph";
			}

		}
	}
}
