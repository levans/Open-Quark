package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_IntMap.Insert_With;
import org.openquark.cal_Cal_Collections_Set.Single;
import org.openquark.cal_Cal_Collections_Set.Union;
import org.openquark.cal_Cal_Core_Prelude._dict___Ord___Int;

public final class Add_Edge_Internal extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Edge_Internal $instance = new Add_Edge_Internal();

	private Add_Edge_Internal() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addEdgeInternal";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.addEdgeInternal";
	}

	private static final RTValue endVertexNum$4$def_Lazy(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(newEdge, 2);
	}

	private static final RTValue endVertexNum$4$def_Strict(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				newEdge.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final int endVertexNum$4$def_Unboxed(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				newEdge.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec).getOrdinalValue();
	}

	private static final RTValue startVertexNum$3$def_Lazy(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(newEdge, 1);
	}

	private static final RTValue startVertexNum$3$def_Strict(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				newEdge.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final int startVertexNum$3$def_Unboxed(RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				newEdge.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec).getOrdinalValue();
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdgeInternal
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue newEdge = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue oldGraph = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_10 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_10, 
					$dictvarCal_Core_Prelude_Eq_10 = null), 
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(newEdge, newEdge = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdgeInternal
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_10, RTValue oldGraph, RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_10, 
					$dictvarCal_Core_Prelude_Eq_10 = null), 
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(newEdge, newEdge = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.addEdgeInternal
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_10, RTValue oldGraph, RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTCons $case1 = ((RTCons)(java.lang.Object)oldGraph.evaluate($ec));

		// Cal.Utilities.DirectedGraph.DirectedGraph
		// Decompose data type to access members.
		TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar1 = 
			((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)$case1);

		int nextVertexNum$U = $dcCaseVar1.get_nextVertexNum_As_Int();
		RTValue vertexMap = $dcCaseVar1.get_vertexMap();
		RTValue oldEdges = $dcCaseVar1.get_edges();

		return 
			new TYPE_Directed_Graph.CAL_Directed_Graph(
				nextVertexNum$U, 
				vertexMap, 
				Insert_With.$instance.f4S(
					new RTPartialApp._3._1(
						Union.$instance, 
						_dict___Ord___Int.$instance), 
					Add_Edge_Internal.startVertexNum$3$def_Unboxed(
						newEdge, 
						$ec), 
					new RTFullApp.General._1._S(
						Single.$instance, 
						Add_Edge_Internal.endVertexNum$4$def_Lazy(
							newEdge, 
							$ec)), 
					oldEdges, 
					$ec).evaluate(
					$ec));
	}

}
