package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class _lambda__find_Cycle_Internal__1 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__find_Cycle_Internal__1 $instance = 
		new _lambda__find_Cycle_Internal__1();

	private _lambda__find_Cycle_Internal__1() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$findCycleInternal$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.$lambda$findCycleInternal$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$findCycleInternal$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue x = $rootNode.getArgValue();
		RTValue vertexNum = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(vertexNum, vertexNum = null), 
				RTValue.lastRef(x, x = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$findCycleInternal$1
	 */
	public final RTValue f2L(RTValue vertexNum, RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(vertexNum, vertexNum = null), 
				RTValue.lastRef(x, x = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$findCycleInternal$1
	 */
	public final RTValue f2S(RTValue vertexNum, RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(
				x.evaluate($ec).getOrdinalValue() == 
				vertexNum.evaluate($ec).getOrdinalValue());
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Utilities.DirectedGraph.$lambda$findCycleInternal$1
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed2S(RTValue vertexNum, RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			x.evaluate($ec).getOrdinalValue() == 
			vertexNum.evaluate($ec).getOrdinalValue();
	}

}
