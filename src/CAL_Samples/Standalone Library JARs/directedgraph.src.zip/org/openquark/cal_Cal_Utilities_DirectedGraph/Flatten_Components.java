package org.openquark.cal_Cal_Utilities_DirectedGraph;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;

public final class Flatten_Components extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Flatten_Components $instance = new Flatten_Components();

	private Flatten_Components() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Utilities.DirectedGraph";
	}

	public final java.lang.String getUnqualifiedName() {
		return "flattenComponents";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Utilities.DirectedGraph.flattenComponents";
	}

	private static final RTValue components$21$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_47, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._S(
				Strongly_Connected_Components_Internal.$instance, 
				$dictvarCal_Core_Prelude_Eq_47, 
				graph);
	}

	private static final RTValue components$21$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_47, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Strongly_Connected_Components_Internal.$instance.f2S(
				$dictvarCal_Core_Prelude_Eq_47, 
				graph, 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue newEdges$22$def_Lazy(RTValue $dictvarCal_Core_Prelude_Eq_47, RTValue graph, RTValue oldEdges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._L(
				Fold_Left_Strict.$instance, 
				Flatten_Components__flatten_Component__2.$instance, 
				oldEdges.getValue(), 
				Flatten_Components.components$21$def_Lazy(
					$dictvarCal_Core_Prelude_Eq_47, 
					graph, 
					$ec));
	}

	private static final RTValue newEdges$22$def_Strict(RTValue $dictvarCal_Core_Prelude_Eq_47, RTValue graph, RTValue oldEdges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Fold_Left_Strict.$instance.f3S(
				Flatten_Components__flatten_Component__2.$instance, 
				oldEdges.getValue(), 
				Flatten_Components.components$21$def_Strict(
					$dictvarCal_Core_Prelude_Eq_47, 
					graph, 
					$ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_47 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_47, 
					$dictvarCal_Core_Prelude_Eq_47 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_47, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_47, 
					$dictvarCal_Core_Prelude_Eq_47 = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Utilities.DirectedGraph.flattenComponents
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_47, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTCons $case1 = ((RTCons)(java.lang.Object)graph.evaluate($ec));

		// Cal.Utilities.DirectedGraph.DirectedGraph
		// Decompose data type to access members.
		TYPE_Directed_Graph.CAL_Directed_Graph $dcCaseVar1 = 
			((TYPE_Directed_Graph.CAL_Directed_Graph)(java.lang.Object)$case1);

		int nextVertexNum$U = $dcCaseVar1.get_nextVertexNum_As_Int();
		RTValue vertexMap = $dcCaseVar1.get_vertexMap();
		RTValue oldEdges = $dcCaseVar1.get_edges();

		return 
			new TYPE_Directed_Graph.CAL_Directed_Graph(
				nextVertexNum$U, 
				vertexMap, 
				Flatten_Components.newEdges$22$def_Strict(
					$dictvarCal_Core_Prelude_Eq_47, 
					graph, 
					oldEdges, 
					$ec));
	}

}
