package org.openquark.cal.samples.directedgraph;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.StandaloneJarGeneratedCodeInfo;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ExecutionContext;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Add_Edge;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Add_Edges;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Add_Vertex;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Contains_Edge;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Contains_Vertex;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Edgeless_Graph;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Empty_Graph;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Equals_Directed_Graph_Ignore_Insertion_Order;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Equals_Directed_Graph_With_Insertion_Order;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Exists_Cycle;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Exists_Path;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Exists_Reachable_Cycle;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Filter;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Find_Cycle;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Find_Path;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Find_Reachable_Cycle;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Flatten_Components;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Fold_In_Depth_First_Search_Order;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Fold_Reachable_In_Depth_First_Search_Order;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Get_Neighbours;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Get_Vertices;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Get_Vertices_In_Insertion_Order;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Make_Edge;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Make_Graph;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Make_Pair;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Make_Predicate_Graph;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Map;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Merge_Vertices;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Partition;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Remove_Edge;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Remove_Vertex;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Reverse;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Show_Directed_Graph;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Source_Vertex;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Stable_Topological_Sort;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Strongly_Connected_Components;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Target_Vertex;
import org.openquark.cal_Cal_Samples_DirectedGraphLibrary.Topological_Sort;
import org.openquark.cal_Cal_Utilities_DirectedGraph.Get_Edge_Count;
import org.openquark.cal_Cal_Utilities_DirectedGraph.Get_Vertex_Count;
import org.openquark.cal_Cal_Utilities_DirectedGraph.Is_Empty;
import org.openquark.util.Pair;

/**
 * This module exposes the functionality of <code>Cal.Utilities.DirectedGraph</code>
 * in a way that can be exported via a standalone library JAR.
 * <p>
 * The main utility provided by this module is the marshalling of algebraic
 * types to and from appropriate foreign types for easy consumption by Java
 * clients. A secondary purpose is to host the API documentation of the library
 * in the form of CALDoc comments, which will be transformed into Javadoc
 * comments in source files produced by the Standalone JAR Tool.
 * 
 * @author Andrew Casey
 * @author Joseph Wong
 */
public final class DirectedGraphLibrary {
	private DirectedGraphLibrary() {
	}

	/**
	 * Adds a new edge to a graph.  If the specified edge is already in the graph,
	 * then the resulting graph will be the same as the original.
	 * <p>
	 * <strong>Note</strong>: If the one or both vertices are not already in the graph, then
	 * they will be added - the first before the second.
	 * 
	 * @param oldGraph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to which the edge will be added.
	 * @param newEdge (CAL type: {@code Edge})
	 *          the edge to be added.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the same vertices and edges as the original, with
	 * the possible addition of the specified edge and its endpoints.
	 */
	public static CalValue addEdge(final CalValue oldGraph, final Pair newEdge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Add_Edge.$instance.apply(
				((RTValue)(java.lang.Object)oldGraph), 
				RTData.CAL_Opaque.make(newEdge)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Adds a new edge to a graph.  If the specified edge is already in the graph,
	 * then the resulting graph will be the same as the original.
	 * <p>
	 * <strong>Note</strong>: If the one or both vertices are not already in the graph, then
	 * they will be added - the first before the second.
	 * 
	 * @param oldGraph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to which the edge will be added.
	 * @param newEdge (CAL type: {@code Edge})
	 *          the edge to be added.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the same vertices and edges as the original, with
	 * the possible addition of the specified edge and its endpoints.
	 */
	public static CalValue addEdge(final CalValue oldGraph, final CalValue newEdge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Add_Edge.$instance.apply(
				((RTValue)(java.lang.Object)oldGraph), 
				((RTValue)(java.lang.Object)newEdge)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * For each pair of vertices <code>v1</code> and <code>v2</code>, add an edge <code>(v1, v2)</code>
	 * to the graph if and only if <code>existsEdgeFn v1 v2</code> returns <code>True</code>.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to which edges will be added
	 * @param existsEdgeFn (CAL type: {@code Predicate})
	 *          a predicate function indicating, for each ordered-pair of
	 * vertices in the graph, whether an edge should be added from one to the other.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a new graph containing all of the vertices and edges in the original
	 * graph, plus the edges induced by the specified predicate function.
	 */
	public static CalValue addEdges(final CalValue graph, final Predicate existsEdgeFn, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Add_Edges.$instance.apply(
				((RTValue)(java.lang.Object)graph), 
				RTData.CAL_Opaque.make(existsEdgeFn)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * For each pair of vertices <code>v1</code> and <code>v2</code>, add an edge <code>(v1, v2)</code>
	 * to the graph if and only if <code>existsEdgeFn v1 v2</code> returns <code>True</code>.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to which edges will be added
	 * @param existsEdgeFn (CAL type: {@code Predicate})
	 *          a predicate function indicating, for each ordered-pair of
	 * vertices in the graph, whether an edge should be added from one to the other.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a new graph containing all of the vertices and edges in the original
	 * graph, plus the edges induced by the specified predicate function.
	 */
	public static CalValue addEdges(final CalValue graph, final CalValue existsEdgeFn, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Add_Edges.$instance.apply(
				((RTValue)(java.lang.Object)graph), 
				((RTValue)(java.lang.Object)existsEdgeFn)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Adds a new vertex to a graph.  If the specified vertex is already in the graph,
	 * then the resulting graph will be the same as the original (including the
	 * insertion order of the vertices).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to which the vertex will be added.
	 * @param vertex (CAL type: {@code Vertex})
	 *          the vertex to be added.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the same vertices and edges as the original, with
	 * the possible addition of the specified vertex.
	 */
	public static CalValue addVertex(final CalValue graph, final java.lang.Object vertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Add_Vertex.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				RTData.CAL_Opaque.make(vertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Adds a new vertex to a graph.  If the specified vertex is already in the graph,
	 * then the resulting graph will be the same as the original (including the
	 * insertion order of the vertices).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to which the vertex will be added.
	 * @param vertex (CAL type: {@code Vertex})
	 *          the vertex to be added.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the same vertices and edges as the original, with
	 * the possible addition of the specified vertex.
	 */
	public static CalValue addVertex(final CalValue graph, final CalValue vertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Add_Vertex.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				((RTValue)(java.lang.Object)vertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * <code>containsEdge graph (vertex1, vertex2)</code> returns <code>True</code> if 
	 * <code>vertex1</code> and <code>vertex2</code> are vertices of <code>graph</code> and
	 * <code>(vertex1, vertex2)</code> is an edge of <code>graph</code>.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to be checked.
	 * @param edge (CAL type: {@code Edge})
	 *          the value to be tested for membership in the graph.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if <code>edge</code> is an edge of <code>graph</code>;
	 * <code>False</code> otherwise.
	 */
	public static boolean containsEdge(final CalValue graph, final Pair edge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Contains_Edge.$instance.apply(
				((RTValue)(java.lang.Object)graph), 
				RTData.CAL_Opaque.make(edge)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * <code>containsEdge graph (vertex1, vertex2)</code> returns <code>True</code> if 
	 * <code>vertex1</code> and <code>vertex2</code> are vertices of <code>graph</code> and
	 * <code>(vertex1, vertex2)</code> is an edge of <code>graph</code>.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to be checked.
	 * @param edge (CAL type: {@code Edge})
	 *          the value to be tested for membership in the graph.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if <code>edge</code> is an edge of <code>graph</code>;
	 * <code>False</code> otherwise.
	 */
	public static boolean containsEdge(final CalValue graph, final CalValue edge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Contains_Edge.$instance.apply(
				((RTValue)(java.lang.Object)graph), 
				((RTValue)(java.lang.Object)edge)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * <code>containsVertex graph vertex</code> returns <code>True</code> if <code>vertex</code>
	 * is a vertex of <code>graph</code>.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to be checked.
	 * @param vertex (CAL type: {@code Vertex})
	 *          the value to be tested for membership in the graph.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if <code>vertex</code> is a vertex of <code>graph</code>;
	 * <code>False</code> otherwise.
	 */
	public static boolean containsVertex(final CalValue graph, final java.lang.Object vertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Contains_Vertex.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				RTData.CAL_Opaque.make(vertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * <code>containsVertex graph vertex</code> returns <code>True</code> if <code>vertex</code>
	 * is a vertex of <code>graph</code>.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to be checked.
	 * @param vertex (CAL type: {@code Vertex})
	 *          the value to be tested for membership in the graph.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if <code>vertex</code> is a vertex of <code>graph</code>;
	 * <code>False</code> otherwise.
	 */
	public static boolean containsVertex(final CalValue graph, final CalValue vertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Contains_Vertex.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				((RTValue)(java.lang.Object)vertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Constructs a graph containing the specified vertices and no edges.
	 * <p>
	 * <strong>Note</strong>: The order of the vertices is preserved.
	 * 
	 * @param vertices (CAL type: {@code JList})
	 *          the vertices of the graph to be constructed.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the specified vertices and no edges.
	 */
	public static CalValue edgelessGraph(final List vertices, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Edgeless_Graph.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				RTData.CAL_Opaque.make(vertices)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Constructs a graph containing the specified vertices and no edges.
	 * <p>
	 * <strong>Note</strong>: The order of the vertices is preserved.
	 * 
	 * @param vertices (CAL type: {@code JList})
	 *          the vertices of the graph to be constructed.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the specified vertices and no edges.
	 */
	public static CalValue edgelessGraph(final CalValue vertices, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Edgeless_Graph.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)vertices)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Constructs an empty graph.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          an empty graph.
	 */
	public static CalValue emptyGraph(final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Empty_Graph.make(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Determines whether or not two graphs have the same vertices and whether each
	 * vertex has the same neighbours in both graphs.
	 * @param graph1 (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the first graph.
	 * @param graph2 (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the second graph.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if the graphs have the same vertices with the same
	 * neighbours; <code>False</code> otherwise.
	 */
	public static boolean equalsDirectedGraphIgnoreInsertionOrder(final CalValue graph1, final CalValue graph2, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Equals_Directed_Graph_Ignore_Insertion_Order.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph1), 
				((RTValue)(java.lang.Object)graph2)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Determines whether or not two graphs have the same vertices, whether each vertex
	 * has the same neighbours in both graphs, and whether both graphs have the same
	 * vertex insertion order.
	 * @param graph1 (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the first graph.
	 * @param graph2 (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the second graph.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if the graphs have the same vertices with the same
	 * neighbours and inserted in the same order; <code>False</code> otherwise.
	 */
	public static boolean equalsDirectedGraphWithInsertionOrder(final CalValue graph1, final CalValue graph2, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Equals_Directed_Graph_With_Insertion_Order.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph1), 
				((RTValue)(java.lang.Object)graph2)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Determines whether or not the specified graph contains a cycle.
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #findCycle findCycle}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a cycle.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if the graph contains a cycle; <code>False</code> otherwise.
	 */
	public static boolean existsCycle(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Exists_Cycle.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Determines whether the graph contains a path from path from <code>startVertex</code>
	 * to <code>endVertex</code>.
	 * <p>
	 * <strong>Note</strong>: each vertex is considered to have a trivial path from itself to itself.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #findPath findPath}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a path.
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex from which to search.
	 * @param endVertex (CAL type: {@code Vertex})
	 *          the vertex to seek.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if the graph contains a path from <code>startVertex</code>
	 * to <code>endVertex</code>; <code>False</code> otherwise.
	 */
	public static boolean existsPath(final CalValue graph, final java.lang.Object startVertex, final java.lang.Object endVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Exists_Path.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				RTData.CAL_Opaque.make(startVertex), 
				RTData.CAL_Opaque.make(endVertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Determines whether the graph contains a path from path from <code>startVertex</code>
	 * to <code>endVertex</code>.
	 * <p>
	 * <strong>Note</strong>: each vertex is considered to have a trivial path from itself to itself.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #findPath findPath}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a path.
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex from which to search.
	 * @param endVertex (CAL type: {@code Vertex})
	 *          the vertex to seek.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if the graph contains a path from <code>startVertex</code>
	 * to <code>endVertex</code>; <code>False</code> otherwise.
	 */
	public static boolean existsPath(final CalValue graph, final CalValue startVertex, final CalValue endVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Exists_Path.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				((RTValue)(java.lang.Object)startVertex), 
				((RTValue)(java.lang.Object)endVertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Determines whether or not the specified graph contains a cycle reachable from
	 * the specified vertex.
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #findReachableCycle findReachableCycle}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a cycle.
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex from which to seek a cycle.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if the graph contains a reachable cycle; <code>False</code> otherwise.
	 */
	public static boolean existsReachableCycle(final CalValue graph, final java.lang.Object startVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Exists_Reachable_Cycle.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				RTData.CAL_Opaque.make(startVertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Determines whether or not the specified graph contains a cycle reachable from
	 * the specified vertex.
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #findReachableCycle findReachableCycle}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a cycle.
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex from which to seek a cycle.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if the graph contains a reachable cycle; <code>False</code> otherwise.
	 */
	public static boolean existsReachableCycle(final CalValue graph, final CalValue startVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Exists_Reachable_Cycle.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				((RTValue)(java.lang.Object)startVertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Eliminates from the graph all elements for which <code>filterFn</code> returns
	 * <code>False</code>.
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #partition partition}
	 * </dl>
	 * 
	 * @param filterFn (CAL type: {@code Predicate})
	 *          a function which returns <code>True</code> if a vertex belongs
	 * in the subgraph and <code>False</code> otherwise.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to filter.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          the subgraph induced by the filter function.
	 */
	public static CalValue filter(final Predicate filterFn, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Filter.$instance.apply(
				RTData.CAL_Opaque.make(filterFn), 
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Eliminates from the graph all elements for which <code>filterFn</code> returns
	 * <code>False</code>.
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #partition partition}
	 * </dl>
	 * 
	 * @param filterFn (CAL type: {@code Predicate})
	 *          a function which returns <code>True</code> if a vertex belongs
	 * in the subgraph and <code>False</code> otherwise.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to filter.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          the subgraph induced by the filter function.
	 */
	public static CalValue filter(final CalValue filterFn, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Filter.$instance.apply(
				((RTValue)(java.lang.Object)filterFn), 
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Returns a list of vertices forming a cycle (first list element is duplicated
	 * in the last position), if one exists.
	 * <p>
	 * <strong>Note</strong>: if the graph contains multiple cycles, then any one may be returned.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #findReachableCycle findReachableCycle}, {@link #existsCycle existsCycle}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a cycle.
	 * @return (CAL type: {@code JList}) 
	 *          the cycle if one exists, or <code>null</code> otherwise.
	 */
	public static List findCycle(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Find_Cycle.$instance.apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns a list of vertices forming a path from <code>startVertex</code> to 
	 * <code>endVertex</code> (inclusive), if one exists.
	 * <p>
	 * <strong>Note</strong>: if the graph contains multiple such paths, then any one may be returned.
	 * <strong>Note</strong>: each vertex is considered to have a trivial path from itself to itself.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #existsPath existsPath}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a path.
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex from which to search.
	 * @param endVertex (CAL type: {@code Vertex})
	 *          the vertex to seek.
	 * @return (CAL type: {@code JList}) 
	 *          the path if one exists, or <code>null</code> otherwise.
	 */
	public static List findPath(final CalValue graph, final java.lang.Object startVertex, final java.lang.Object endVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Find_Path.$instance.apply(
					((RTValue)(java.lang.Object)graph), 
					RTData.CAL_Opaque.make(startVertex), 
					RTData.CAL_Opaque.make(endVertex)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns a list of vertices forming a path from <code>startVertex</code> to 
	 * <code>endVertex</code> (inclusive), if one exists.
	 * <p>
	 * <strong>Note</strong>: if the graph contains multiple such paths, then any one may be returned.
	 * <strong>Note</strong>: each vertex is considered to have a trivial path from itself to itself.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #existsPath existsPath}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a path.
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex from which to search.
	 * @param endVertex (CAL type: {@code Vertex})
	 *          the vertex to seek.
	 * @return (CAL type: {@code JList}) 
	 *          the path if one exists, or <code>null</code> otherwise.
	 */
	public static List findPath(final CalValue graph, final CalValue startVertex, final CalValue endVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Find_Path.$instance.apply(
					((RTValue)(java.lang.Object)graph), 
					((RTValue)(java.lang.Object)startVertex), 
					((RTValue)(java.lang.Object)endVertex)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns a list of vertices forming a cycle reachable from the specified
	 * vertex (first list element is duplicated in the last position), if one exists.
	 * <p>
	 * <strong>Note</strong>: if the reachable subgraph contains multiple cycles, then any one
	 * may be returned.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #findCycle findCycle}, {@link #existsReachableCycle existsReachableCycle}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a cycle.
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex from which to seek a cycle.
	 * @return (CAL type: {@code JList}) 
	 *          the cycle if one exists, or <code>null</code> otherwise.
	 */
	public static List findReachableCycle(final CalValue graph, final java.lang.Object startVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Find_Reachable_Cycle.$instance.apply(
					((RTValue)(java.lang.Object)graph), 
					RTData.CAL_Opaque.make(startVertex)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns a list of vertices forming a cycle reachable from the specified
	 * vertex (first list element is duplicated in the last position), if one exists.
	 * <p>
	 * <strong>Note</strong>: if the reachable subgraph contains multiple cycles, then any one
	 * may be returned.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #findCycle findCycle}, {@link #existsReachableCycle existsReachableCycle}
	 * </dl>
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to seek a cycle.
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex from which to seek a cycle.
	 * @return (CAL type: {@code JList}) 
	 *          the cycle if one exists, or <code>null</code> otherwise.
	 */
	public static List findReachableCycle(final CalValue graph, final CalValue startVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Find_Reachable_Cycle.$instance.apply(
					((RTValue)(java.lang.Object)graph), 
					((RTValue)(java.lang.Object)startVertex)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns a copy of the graph that contains no cycles - within each strongly-
	 * connected component, all edges are removed and replaced with new edges
	 * enforcing the insertion order.
	 * <p>
	 * e.g. <code>cycle{B, A} -&gt; F -&gt; cycle{C, E, D}</code> becomes 
	 * <code>A -&gt; B -&gt; F -&gt; C -&gt; D -&gt; E</code> (assuming the vertices were created in 
	 * alphabetical order).
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to flatten cycles.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a copy of the specified graph with all cycles flattened.
	 */
	public static CalValue flattenComponents(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Flatten_Components.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Fold across the entire graph in depth-first search order.
	 * <p>
	 * <strong>Note</strong>: this is simply an alias for {@link #foldInDepthFirstSearchOrder foldInDepthFirstSearchOrder}.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #foldInDepthFirstSearchOrder foldInDepthFirstSearchOrder}, {@link #foldReachableDFS foldReachableDFS}, {@link #foldReachableInDepthFirstSearchOrder foldReachableInDepthFirstSearchOrder}
	 * </dl>
	 * 
	 * @param startVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is visited for the first time.
	 * Guaranteed to be called exactly once per vertex.
	 * @param finishVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is finished (all children are finished).
	 * Guaranteed to be called exactly once per vertex.
	 * @param init (CAL type: {@code Accumulator})
	 *          the initial accumulator value (returned directly if the graph is empty).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to fold across.
	 * @return (CAL type: {@code Accumulator}) 
	 *          The accumulated value after the final vertex is finished.
	 */
	public static java.lang.Object foldDFS(final BinaryFunction startVertexFn, final BinaryFunction finishVertexFn, final java.lang.Object init, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Fold_In_Depth_First_Search_Order.$instance.apply(
					RTData.CAL_Opaque.make(startVertexFn), 
					RTData.CAL_Opaque.make(finishVertexFn), 
					RTData.CAL_Opaque.make(init), 
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Fold across the entire graph in depth-first search order.
	 * <p>
	 * <strong>Note</strong>: this is simply an alias for {@link #foldInDepthFirstSearchOrder foldInDepthFirstSearchOrder}.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #foldInDepthFirstSearchOrder foldInDepthFirstSearchOrder}, {@link #foldReachableDFS foldReachableDFS}, {@link #foldReachableInDepthFirstSearchOrder foldReachableInDepthFirstSearchOrder}
	 * </dl>
	 * 
	 * @param startVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is visited for the first time.
	 * Guaranteed to be called exactly once per vertex.
	 * @param finishVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is finished (all children are finished).
	 * Guaranteed to be called exactly once per vertex.
	 * @param init (CAL type: {@code Accumulator})
	 *          the initial accumulator value (returned directly if the graph is empty).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to fold across.
	 * @return (CAL type: {@code Accumulator}) 
	 *          The accumulated value after the final vertex is finished.
	 */
	public static java.lang.Object foldDFS(final CalValue startVertexFn, final CalValue finishVertexFn, final CalValue init, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Fold_In_Depth_First_Search_Order.$instance.apply(
					((RTValue)(java.lang.Object)startVertexFn), 
					((RTValue)(java.lang.Object)finishVertexFn), 
					((RTValue)(java.lang.Object)init), 
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Fold across the entire graph in depth-first search order.
	 * <p>
	 * <strong>Note</strong>: for convenience, you may wish to call this function as {@link #foldDFS foldDFS}.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #foldDFS foldDFS}, {@link #foldReachableDFS foldReachableDFS}, {@link #foldReachableInDepthFirstSearchOrder foldReachableInDepthFirstSearchOrder}
	 * </dl>
	 * 
	 * @param startVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is visited for the first time.
	 * Guaranteed to be called exactly once per vertex.
	 * @param finishVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is finished (all children are finished).
	 * Guaranteed to be called exactly once per vertex.
	 * @param init (CAL type: {@code Accumulator})
	 *          the initial accumulator value (returned directly if the graph is empty).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to fold across.
	 * @return (CAL type: {@code Accumulator}) 
	 *          The accumulated value after the final vertex is finished.
	 */
	public static java.lang.Object foldInDepthFirstSearchOrder(final BinaryFunction startVertexFn, final BinaryFunction finishVertexFn, final java.lang.Object init, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Fold_In_Depth_First_Search_Order.$instance.apply(
					RTData.CAL_Opaque.make(startVertexFn), 
					RTData.CAL_Opaque.make(finishVertexFn), 
					RTData.CAL_Opaque.make(init), 
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Fold across the entire graph in depth-first search order.
	 * <p>
	 * <strong>Note</strong>: for convenience, you may wish to call this function as {@link #foldDFS foldDFS}.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #foldDFS foldDFS}, {@link #foldReachableDFS foldReachableDFS}, {@link #foldReachableInDepthFirstSearchOrder foldReachableInDepthFirstSearchOrder}
	 * </dl>
	 * 
	 * @param startVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is visited for the first time.
	 * Guaranteed to be called exactly once per vertex.
	 * @param finishVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is finished (all children are finished).
	 * Guaranteed to be called exactly once per vertex.
	 * @param init (CAL type: {@code Accumulator})
	 *          the initial accumulator value (returned directly if the graph is empty).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to fold across.
	 * @return (CAL type: {@code Accumulator}) 
	 *          The accumulated value after the final vertex is finished.
	 */
	public static java.lang.Object foldInDepthFirstSearchOrder(final CalValue startVertexFn, final CalValue finishVertexFn, final CalValue init, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Fold_In_Depth_First_Search_Order.$instance.apply(
					((RTValue)(java.lang.Object)startVertexFn), 
					((RTValue)(java.lang.Object)finishVertexFn), 
					((RTValue)(java.lang.Object)init), 
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Fold across graph vertices reachable from the specified root in depth-first
	 * search order.
	 * <p>
	 * <strong>Note</strong>: this is simply an alias for {@link #foldReachableInDepthFirstSearchOrder foldReachableInDepthFirstSearchOrder}.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #foldDFS foldDFS}, {@link #foldInDepthFirstSearchOrder foldInDepthFirstSearchOrder}, {@link #foldReachableInDepthFirstSearchOrder foldReachableInDepthFirstSearchOrder}
	 * </dl>
	 * 
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex at which to begin the traversal.
	 * @param startVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is visited for the first time.
	 * Guaranteed to be called exactly once for each reachable vertex.
	 * @param finishVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is finished (all children are finished).
	 * Guaranteed to be called exactly once for each reachable vertex.
	 * @param init (CAL type: {@code Accumulator})
	 *          the initial accumulator value (returned directly if the graph is empty).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to fold across.
	 * @return (CAL type: {@code Accumulator}) 
	 *          The accumulated value after the final vertex is finished.
	 */
	public static java.lang.Object foldReachableDFS(final java.lang.Object startVertex, final BinaryFunction startVertexFn, final BinaryFunction finishVertexFn, final java.lang.Object init, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Fold_Reachable_In_Depth_First_Search_Order.$instance.apply(
					RTData.CAL_Opaque.make(startVertex), 
					RTData.CAL_Opaque.make(startVertexFn), 
					RTData.CAL_Opaque.make(finishVertexFn), 
					RTData.CAL_Opaque.make(init)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Fold across graph vertices reachable from the specified root in depth-first
	 * search order.
	 * <p>
	 * <strong>Note</strong>: this is simply an alias for {@link #foldReachableInDepthFirstSearchOrder foldReachableInDepthFirstSearchOrder}.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #foldDFS foldDFS}, {@link #foldInDepthFirstSearchOrder foldInDepthFirstSearchOrder}, {@link #foldReachableInDepthFirstSearchOrder foldReachableInDepthFirstSearchOrder}
	 * </dl>
	 * 
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex at which to begin the traversal.
	 * @param startVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is visited for the first time.
	 * Guaranteed to be called exactly once for each reachable vertex.
	 * @param finishVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is finished (all children are finished).
	 * Guaranteed to be called exactly once for each reachable vertex.
	 * @param init (CAL type: {@code Accumulator})
	 *          the initial accumulator value (returned directly if the graph is empty).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to fold across.
	 * @return (CAL type: {@code Accumulator}) 
	 *          The accumulated value after the final vertex is finished.
	 */
	public static java.lang.Object foldReachableDFS(final CalValue startVertex, final CalValue startVertexFn, final CalValue finishVertexFn, final CalValue init, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Fold_Reachable_In_Depth_First_Search_Order.$instance.apply(
					((RTValue)(java.lang.Object)startVertex), 
					((RTValue)(java.lang.Object)startVertexFn), 
					((RTValue)(java.lang.Object)finishVertexFn), 
					((RTValue)(java.lang.Object)init)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Fold across graph vertices reachable from the specified root in depth-first
	 * search order.
	 * <p>
	 * <strong>Note</strong>: for convenience, you may wish to call this function as {@link #foldReachableDFS foldReachableDFS}.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #foldDFS foldDFS}, {@link #foldInDepthFirstSearchOrder foldInDepthFirstSearchOrder}, {@link #foldReachableDFS foldReachableDFS}
	 * </dl>
	 * 
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex at which to begin the traversal.
	 * @param startVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is visited for the first time.
	 * Guaranteed to be called exactly once for each reachable vertex.
	 * @param finishVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is finished (all children are finished).
	 * Guaranteed to be called exactly once for each reachable vertex.
	 * @param init (CAL type: {@code Accumulator})
	 *          the initial accumulator value (returned directly if the graph is empty).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to fold across.
	 * @return (CAL type: {@code Accumulator}) 
	 *          The accumulated value after the final vertex is finished.
	 */
	public static java.lang.Object foldReachableInDepthFirstSearchOrder(final java.lang.Object startVertex, final BinaryFunction startVertexFn, final BinaryFunction finishVertexFn, final java.lang.Object init, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Fold_Reachable_In_Depth_First_Search_Order.$instance.apply(
					RTData.CAL_Opaque.make(startVertex), 
					RTData.CAL_Opaque.make(startVertexFn), 
					RTData.CAL_Opaque.make(finishVertexFn), 
					RTData.CAL_Opaque.make(init)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Fold across graph vertices reachable from the specified root in depth-first
	 * search order.
	 * <p>
	 * <strong>Note</strong>: for convenience, you may wish to call this function as {@link #foldReachableDFS foldReachableDFS}.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #foldDFS foldDFS}, {@link #foldInDepthFirstSearchOrder foldInDepthFirstSearchOrder}, {@link #foldReachableDFS foldReachableDFS}
	 * </dl>
	 * 
	 * @param startVertex (CAL type: {@code Vertex})
	 *          the vertex at which to begin the traversal.
	 * @param startVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is visited for the first time.
	 * Guaranteed to be called exactly once for each reachable vertex.
	 * @param finishVertexFn (CAL type: {@code BinaryFunction})
	 *          called when a vertex is finished (all children are finished).
	 * Guaranteed to be called exactly once for each reachable vertex.
	 * @param init (CAL type: {@code Accumulator})
	 *          the initial accumulator value (returned directly if the graph is empty).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to fold across.
	 * @return (CAL type: {@code Accumulator}) 
	 *          The accumulated value after the final vertex is finished.
	 */
	public static java.lang.Object foldReachableInDepthFirstSearchOrder(final CalValue startVertex, final CalValue startVertexFn, final CalValue finishVertexFn, final CalValue init, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Fold_Reachable_In_Depth_First_Search_Order.$instance.apply(
					((RTValue)(java.lang.Object)startVertex), 
					((RTValue)(java.lang.Object)startVertexFn), 
					((RTValue)(java.lang.Object)finishVertexFn), 
					((RTValue)(java.lang.Object)init)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns the number of edges in the specified graph.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph whose edge count is to be returned.
	 * @return (CAL type: {@code Int}) 
	 *          the number of edges in the graph.
	 */
	public static int getEdgeCount(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Get_Edge_Count.$instance.apply(
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getIntValue();
	}

	/**
	 * Returns the list of out-neighbours of the specified vertex.  No particular
	 * order is guaranteed.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to find neighbours.
	 * @param vertex (CAL type: {@code Vertex})
	 *          the vertex whose neighbours are sought.
	 * @return (CAL type: {@code JList}) 
	 *          a list of out-neighbours of the specified vertex.
	 */
	public static List getNeighbours(final CalValue graph, final java.lang.Object vertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Get_Neighbours.$instance.apply(
					((RTValue)(java.lang.Object)graph), 
					RTData.CAL_Opaque.make(vertex)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns the list of out-neighbours of the specified vertex.  No particular
	 * order is guaranteed.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to find neighbours.
	 * @param vertex (CAL type: {@code Vertex})
	 *          the vertex whose neighbours are sought.
	 * @return (CAL type: {@code JList}) 
	 *          a list of out-neighbours of the specified vertex.
	 */
	public static List getNeighbours(final CalValue graph, final CalValue vertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Get_Neighbours.$instance.apply(
					((RTValue)(java.lang.Object)graph), 
					((RTValue)(java.lang.Object)vertex)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns the number of vertices in the specified graph.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph whose vertex count is to be returned.
	 * @return (CAL type: {@code Int}) 
	 *          the number of vertices in the graph.
	 */
	public static int getVertexCount(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Get_Vertex_Count.$instance.apply(
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getIntValue();
	}

	/**
	 * Returns a list of the vertices in the specified graph.  No particular order
	 * is guaranteed.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph whose vertices are to be returned.
	 * @return (CAL type: {@code JList}) 
	 *          a list of vertices in the graph.
	 */
	public static List getVertices(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Get_Vertices.make(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns a list of the vertices in the specified graph.  The vertices will
	 * be ordered by insertion time.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph whose vertices are to be returned.
	 * @return (CAL type: {@code JList}) 
	 *          a list of vertices in the graph.
	 */
	public static List getVerticesInInsertionOrder(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Get_Vertices_In_Insertion_Order.make(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns whether the specified graph is the empty graph (i.e. contains no
	 * vertices).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to check.
	 * @return (CAL type: {@code Boolean}) 
	 *          <code>True</code> if the graph is empty; <code>False</code> otherwise.
	 */
	public static boolean isEmpty(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Is_Empty.$instance.apply(
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getBooleanValue();
	}

	/**
	 * Constructs an edge.
	 * @param source (CAL type: {@code Vertex})
	 *          the source vertex.
	 * @param target (CAL type: {@code Vertex})
	 *          the target vertex.
	 * @return (CAL type: {@code Edge}) 
	 *          an edge.
	 */
	public static Pair makeEdge(final java.lang.Object source, final java.lang.Object target, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((Pair)(java.lang.Object)
				Make_Edge.$instance.apply(
					RTData.CAL_Opaque.make(source), 
					RTData.CAL_Opaque.make(target)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Constructs an edge.
	 * @param source (CAL type: {@code Vertex})
	 *          the source vertex.
	 * @param target (CAL type: {@code Vertex})
	 *          the target vertex.
	 * @return (CAL type: {@code Edge}) 
	 *          an edge.
	 */
	public static Pair makeEdge(final CalValue source, final CalValue target, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((Pair)(java.lang.Object)
				Make_Edge.$instance.apply(
					((RTValue)(java.lang.Object)source), 
					((RTValue)(java.lang.Object)target)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Constructs a graph containing the specified vertices and edges.
	 * <p>
	 * <strong>Note</strong>: If an edge <code>(v1, v2)</code> is specified and if either
	 * <code>v1</code> or <code>v2</code> is not in the list of vertices, then it will be
	 * added to the graph anyway.  
	 * <p>
	 * <strong>Note</strong>: The insertion order will be determined by the order in which
	 * such vertices are encountered while adding edges to the graph.  For example, 
	 * <code>getVerticesInInsertionOrder (makeGraph [v1, v2] [(v1, v3), (v4, v2)])</code>
	 * will return <code>[v1, v2, v3, v4]</code>.
	 * 
	 * @param vertices (CAL type: {@code JList})
	 *          the vertices of the graph to be constructed.
	 * @param edges (CAL type: {@code JList})
	 *          the edges of the graph to be constructed.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the specified vertices and edges.
	 */
	public static CalValue makeGraph(final List vertices, final List edges, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Make_Graph.$instance.apply(
				RTData.CAL_Opaque.make(vertices), 
				RTData.CAL_Opaque.make(edges)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Constructs a graph containing the specified vertices and edges.
	 * <p>
	 * <strong>Note</strong>: If an edge <code>(v1, v2)</code> is specified and if either
	 * <code>v1</code> or <code>v2</code> is not in the list of vertices, then it will be
	 * added to the graph anyway.  
	 * <p>
	 * <strong>Note</strong>: The insertion order will be determined by the order in which
	 * such vertices are encountered while adding edges to the graph.  For example, 
	 * <code>getVerticesInInsertionOrder (makeGraph [v1, v2] [(v1, v3), (v4, v2)])</code>
	 * will return <code>[v1, v2, v3, v4]</code>.
	 * 
	 * @param vertices (CAL type: {@code JList})
	 *          the vertices of the graph to be constructed.
	 * @param edges (CAL type: {@code JList})
	 *          the edges of the graph to be constructed.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the specified vertices and edges.
	 */
	public static CalValue makeGraph(final CalValue vertices, final CalValue edges, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Make_Graph.$instance.apply(
				((RTValue)(java.lang.Object)vertices), 
				((RTValue)(java.lang.Object)edges)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Constructs a pair.
	 * @param elem1 (CAL type: {@code JObject})
	 *          the first element.
	 * @param elem2 (CAL type: {@code JObject})
	 *          the second element.
	 * @return (CAL type: {@code Pair}) 
	 *          a pair.
	 */
	public static Pair makePair(final java.lang.Object elem1, final java.lang.Object elem2, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((Pair)(java.lang.Object)
				Make_Pair.$instance.apply(
					RTData.CAL_Opaque.make(elem1), 
					RTData.CAL_Opaque.make(elem2)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Constructs a pair.
	 * @param elem1 (CAL type: {@code JObject})
	 *          the first element.
	 * @param elem2 (CAL type: {@code JObject})
	 *          the second element.
	 * @return (CAL type: {@code Pair}) 
	 *          a pair.
	 */
	public static Pair makePair(final CalValue elem1, final CalValue elem2, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((Pair)(java.lang.Object)
				Make_Pair.$instance.apply(
					((RTValue)(java.lang.Object)elem1), 
					((RTValue)(java.lang.Object)elem2)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Constructs a graph containing the specified vertices.  For each pair of vertices
	 * <code>v1</code> and <code>v2</code>, the graph will contain contain an edge <code>(v1, v2)</code>
	 * if and only if <code>existsEdgeFn v1 v2</code> returns <code>True</code>.
	 * <p>
	 * <strong>Note</strong>: The order of the vertices is preserved.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #addEdges addEdges}
	 * </dl>
	 * 
	 * @param vertices (CAL type: {@code JList})
	 *          the vertices of the graph to be constructed.
	 * @param existsEdgeFn (CAL type: {@code Predicate})
	 *          a predicate function indicating, for each ordered-pair of
	 * vertices in the graph, whether an edge exists from one to the other.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the specified vertices and the edges induced by
	 * the specified predicate function.
	 */
	public static CalValue makePredicateGraph(final List vertices, final Predicate existsEdgeFn, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Make_Predicate_Graph.$instance.apply(
				RTData.CAL_Opaque.make(vertices), 
				RTData.CAL_Opaque.make(existsEdgeFn)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Constructs a graph containing the specified vertices.  For each pair of vertices
	 * <code>v1</code> and <code>v2</code>, the graph will contain contain an edge <code>(v1, v2)</code>
	 * if and only if <code>existsEdgeFn v1 v2</code> returns <code>True</code>.
	 * <p>
	 * <strong>Note</strong>: The order of the vertices is preserved.
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #addEdges addEdges}
	 * </dl>
	 * 
	 * @param vertices (CAL type: {@code JList})
	 *          the vertices of the graph to be constructed.
	 * @param existsEdgeFn (CAL type: {@code Predicate})
	 *          a predicate function indicating, for each ordered-pair of
	 * vertices in the graph, whether an edge exists from one to the other.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the specified vertices and the edges induced by
	 * the specified predicate function.
	 */
	public static CalValue makePredicateGraph(final CalValue vertices, final CalValue existsEdgeFn, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Make_Predicate_Graph.$instance.apply(
				((RTValue)(java.lang.Object)vertices), 
				((RTValue)(java.lang.Object)existsEdgeFn)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Applies the specified function to each vertex in the specified graph.
	 * <p>
	 * <strong>Note</strong>: If two vertices have the same image under the specified function,
	 * then they will be merged (retaining self-loops created during the merge).
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #mergeVertices mergeVertices}
	 * </dl>
	 * 
	 * @param mapFn (CAL type: {@code UnaryFunction})
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          the graph that results when the specified function is applied to each
	 * vertex in the specified graph.
	 */
	public static CalValue map(final UnaryFunction mapFn, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Map.$instance.apply(
				RTData.CAL_Opaque.make(mapFn), 
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Applies the specified function to each vertex in the specified graph.
	 * <p>
	 * <strong>Note</strong>: If two vertices have the same image under the specified function,
	 * then they will be merged (retaining self-loops created during the merge).
	 * 
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #mergeVertices mergeVertices}
	 * </dl>
	 * 
	 * @param mapFn (CAL type: {@code UnaryFunction})
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          the graph that results when the specified function is applied to each
	 * vertex in the specified graph.
	 */
	public static CalValue map(final CalValue mapFn, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Map.$instance.apply(
				((RTValue)(java.lang.Object)mapFn), 
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Merges two vertices of a graph.  
	 * <code>mergeVertices graph retainLoops vertex1 vertex2 mergedVertex</code>
	 * results in a graph satisfying:
	 * <ul>
	 *  <li>
	 *   <code>vertex1</code> is removed from the graph
	 *  </li>
	 *  <li>
	 *   <code>vertex2</code> is removed from the graph
	 *  </li>
	 *  <li>
	 *   <code>mergedVertex</code> is added to the graph
	 *  </li>
	 *  <li>
	 *   Edges are transformed (modulo <code>retainLoops</code>):
	 *   <ul>
	 *    <li>
	 *     <code>(A, ?)</code> -&gt; <code>(C, ?)</code>
	 *    </li>
	 *    <li>
	 *     <code>(?, A)</code> -&gt; <code>(?, C)</code>
	 *    </li>
	 *    <li>
	 *     <code>(B, ?)</code> -&gt; <code>(C, ?)</code>
	 *    </li>
	 *    <li>
	 *     <code>(?, B)</code> -&gt; <code>(?, C)</code>
	 *    </li>
	 *   </ul>
	 *  </li>
	 * </ul>
	 * <p>
	 *  
	 * <p>
	 * <strong>Side effect</strong>: If the merged vertex is already contained in the graph, then
	 * its insertion order will not change.  Otherwise, the merged vertex will
	 * acquire the insertion order of the first vertex argument (note: argument 1,
	 * not vertex with earlier insertion time).
	 * <p>
	 * <strong>Note</strong>: Throws an <code>error</code> if either <code>vertex1</code> or
	 * <code>vertex2</code> is not in the graph. 
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to merge the vertices.
	 * @param retainLoops (CAL type: {@code Boolean})
	 *          if vertices A and B are merged to C and the graph contains
	 * (A, B) or (B, A), then (C, C) will be added to the new graph if retainLoops
	 * is true.  Note that if the graph contains (A, A) or (B, B), then the new
	 * graph will contain (C, C) regardless of the value of retainLoops.
	 * @param vertex1 (CAL type: {@code Vertex})
	 *          the first vertex to be merged (error if invalid).
	 * @param vertex2 (CAL type: {@code Vertex})
	 *          the second vertex to be merged (error if invalid).
	 * @param mergedVertex (CAL type: {@code Vertex})
	 *          the resulting vertex.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a new graph with the two vertices merged.
	 */
	public static CalValue mergeVertices(final CalValue graph, final boolean retainLoops, final java.lang.Object vertex1, final java.lang.Object vertex2, final java.lang.Object mergedVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Merge_Vertices.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				RTData.CAL_Boolean.make(retainLoops), 
				RTData.CAL_Opaque.make(vertex1), 
				RTData.CAL_Opaque.make(vertex2)).apply(
				RTData.CAL_Opaque.make(mergedVertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Merges two vertices of a graph.  
	 * <code>mergeVertices graph retainLoops vertex1 vertex2 mergedVertex</code>
	 * results in a graph satisfying:
	 * <ul>
	 *  <li>
	 *   <code>vertex1</code> is removed from the graph
	 *  </li>
	 *  <li>
	 *   <code>vertex2</code> is removed from the graph
	 *  </li>
	 *  <li>
	 *   <code>mergedVertex</code> is added to the graph
	 *  </li>
	 *  <li>
	 *   Edges are transformed (modulo <code>retainLoops</code>):
	 *   <ul>
	 *    <li>
	 *     <code>(A, ?)</code> -&gt; <code>(C, ?)</code>
	 *    </li>
	 *    <li>
	 *     <code>(?, A)</code> -&gt; <code>(?, C)</code>
	 *    </li>
	 *    <li>
	 *     <code>(B, ?)</code> -&gt; <code>(C, ?)</code>
	 *    </li>
	 *    <li>
	 *     <code>(?, B)</code> -&gt; <code>(?, C)</code>
	 *    </li>
	 *   </ul>
	 *  </li>
	 * </ul>
	 * <p>
	 *  
	 * <p>
	 * <strong>Side effect</strong>: If the merged vertex is already contained in the graph, then
	 * its insertion order will not change.  Otherwise, the merged vertex will
	 * acquire the insertion order of the first vertex argument (note: argument 1,
	 * not vertex with earlier insertion time).
	 * <p>
	 * <strong>Note</strong>: Throws an <code>error</code> if either <code>vertex1</code> or
	 * <code>vertex2</code> is not in the graph. 
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph in which to merge the vertices.
	 * @param retainLoops (CAL type: {@code Boolean})
	 *          if vertices A and B are merged to C and the graph contains
	 * (A, B) or (B, A), then (C, C) will be added to the new graph if retainLoops
	 * is true.  Note that if the graph contains (A, A) or (B, B), then the new
	 * graph will contain (C, C) regardless of the value of retainLoops.
	 * @param vertex1 (CAL type: {@code Vertex})
	 *          the first vertex to be merged (error if invalid).
	 * @param vertex2 (CAL type: {@code Vertex})
	 *          the second vertex to be merged (error if invalid).
	 * @param mergedVertex (CAL type: {@code Vertex})
	 *          the resulting vertex.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a new graph with the two vertices merged.
	 */
	public static CalValue mergeVertices(final CalValue graph, final CalValue retainLoops, final CalValue vertex1, final CalValue vertex2, final CalValue mergedVertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Merge_Vertices.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph), 
				((RTValue)(java.lang.Object)retainLoops), 
				((RTValue)(java.lang.Object)vertex1), 
				((RTValue)(java.lang.Object)vertex2)).apply(
				((RTValue)(java.lang.Object)mergedVertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Partitions the vertices into two sets and then removes all edges from one set
	 * to the other.
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #filter filter}
	 * </dl>
	 * 
	 * @param partitionFn (CAL type: {@code Predicate})
	 *          a function which returns <code>True</code> if a vertex belongs
	 * in the first subgraph and <code>False</code> if a vertex belongs in the second
	 * subgraph.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to partition.
	 * @return (CAL type: {@code Pair}) 
	 *          the two subgraphs induced by the partition function.
	 */
	public static Pair partition(final Predicate partitionFn, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((Pair)(java.lang.Object)
				Partition.$instance.apply(
					RTData.CAL_Opaque.make(partitionFn), 
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Partitions the vertices into two sets and then removes all edges from one set
	 * to the other.
	 * 
	 * <dl><dt><b>See Also:</b>
	 * <dd><b>Functions and Class Methods:</b> {@link #filter filter}
	 * </dl>
	 * 
	 * @param partitionFn (CAL type: {@code Predicate})
	 *          a function which returns <code>True</code> if a vertex belongs
	 * in the first subgraph and <code>False</code> if a vertex belongs in the second
	 * subgraph.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to partition.
	 * @return (CAL type: {@code Pair}) 
	 *          the two subgraphs induced by the partition function.
	 */
	public static Pair partition(final CalValue partitionFn, final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((Pair)(java.lang.Object)
				Partition.$instance.apply(
					((RTValue)(java.lang.Object)partitionFn), 
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Removes an edge from a graph.  If the specified edge is already absent from
	 * the graph (perhaps because one of the endpoints is absent from the graph),
	 * then the resulting graph will be the same as the original.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph from which the edge will be removed.
	 * @param edge (CAL type: {@code Edge})
	 *          the edge to be removed.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the same vertices and edges as the original, with
	 * the possible exception of the specified edge.
	 */
	public static CalValue removeEdge(final CalValue graph, final Pair edge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Remove_Edge.$instance.apply(
				((RTValue)(java.lang.Object)graph), 
				RTData.CAL_Opaque.make(edge)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Removes an edge from a graph.  If the specified edge is already absent from
	 * the graph (perhaps because one of the endpoints is absent from the graph),
	 * then the resulting graph will be the same as the original.
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph from which the edge will be removed.
	 * @param edge (CAL type: {@code Edge})
	 *          the edge to be removed.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the same vertices and edges as the original, with
	 * the possible exception of the specified edge.
	 */
	public static CalValue removeEdge(final CalValue graph, final CalValue edge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Remove_Edge.$instance.apply(
				((RTValue)(java.lang.Object)graph), 
				((RTValue)(java.lang.Object)edge)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Removes a new vertex from a graph.  If the specified vertex is already absent
	 * from the graph, then the resulting graph will be the same as the original.
	 * @param oldGraph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph from which the vertex will be removed.
	 * @param vertex (CAL type: {@code Vertex})
	 *          the vertex to be removed.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the same vertices and edges as the original, with
	 * the possible exception of the specified vertex.
	 */
	public static CalValue removeVertex(final CalValue oldGraph, final java.lang.Object vertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Remove_Vertex.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)oldGraph), 
				RTData.CAL_Opaque.make(vertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Removes a new vertex from a graph.  If the specified vertex is already absent
	 * from the graph, then the resulting graph will be the same as the original.
	 * @param oldGraph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph from which the vertex will be removed.
	 * @param vertex (CAL type: {@code Vertex})
	 *          the vertex to be removed.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          a graph containing the same vertices and edges as the original, with
	 * the possible exception of the specified vertex.
	 */
	public static CalValue removeVertex(final CalValue oldGraph, final CalValue vertex, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Remove_Vertex.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)oldGraph), 
				((RTValue)(java.lang.Object)vertex)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Reverses all of the edges in a graph (sometimes referred to as the transpose
	 * graph).
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to reverse.
	 * @return (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex}) 
	 *          the graph with all edges reversed.
	 */
	public static CalValue reverse(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Reverse.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)executionContext));
	}

	/**
	 * Returns a string representation of the graph.  The graph is traversed in depth-first
	 * order and each vertex is displayed with a list of its children.  Any vertex
	 * that has previously been encountered will be shown in angle brackets and
	 * not expanded (i.e. its children will not be shown).  For example:
	 * <p>
	 * 
	 * <pre> vertex1 {
	 *    child_1 {
	 *      grandchild_1_1 {
	 *      }
	 *      grandchild_1_2 {
	 *      }
	 *    child_2 {
	 *      grandchild_2_1 {
	 *      }
	 *      &lt;grandchild_1_1&gt;        &lt;-- Details omitted since repeated
	 *    }
	 *  }
	 *  vertex2 {
	 *    ...
	 *  }
	 * </pre>
	 * 
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to be displayed.
	 * @return (CAL type: {@code String}) 
	 *          a string representation of the graph.
	 */
	public static java.lang.String showDirectedGraph(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			Show_Directed_Graph.make(
				((RTExecutionContext)(java.lang.Object)executionContext)).apply(
				((RTValue)(java.lang.Object)graph)).evaluate(
				((RTExecutionContext)(java.lang.Object)
					executionContext)).getStringValue();
	}

	/**
	 * Returns the source vertex of the given edge.
	 * @param edge (CAL type: {@code Edge})
	 *          the edge.
	 * @return (CAL type: {@code Vertex}) 
	 *          the source vertex of the given edge.
	 */
	public static java.lang.Object sourceVertex(final Pair edge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Source_Vertex.$instance.apply(
					RTData.CAL_Opaque.make(edge)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns the source vertex of the given edge.
	 * @param edge (CAL type: {@code Edge})
	 *          the edge.
	 * @return (CAL type: {@code Vertex}) 
	 *          the source vertex of the given edge.
	 */
	public static java.lang.Object sourceVertex(final CalValue edge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Source_Vertex.$instance.apply(
					((RTValue)(java.lang.Object)edge)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns the vertices in topological order if the graph is acyclic and in an
	 * unspecified order otherwise.  If the relative order of two vertices is not
	 * specified by the graph, then their insertion order will be used.
	 * <p>
	 * If the graph contains cycles, then calling {@link #flattenComponents flattenComponents} before
	 * {@link #stableTopologicalSort stableTopologicalSort} will produce the desired stable order.
	 * <p>
	 * <strong>Note</strong>: this may be quite a bit slower than a normal topological sort.
	 * <p>
	 * Algorithm adapted from Exercise 22.4-5 on p. 552 of 
	 * "Introduction to Algorithms 2E"
	 * by Cormen, Leiserson, Rivest, and Stein (2002).
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to be sorted.
	 * @return (CAL type: {@code JList}) 
	 *          an ordered list of vertices.
	 */
	public static List stableTopologicalSort(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Stable_Topological_Sort.make(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns a topologically sorted list of strongly-connected components of a
	 * specified graph (i.e. if A and B are SCCs and A precedes B in the returned
	 * list, then the graph contains no edges from vertices in A to vertices in B).
	 * <p>
	 * Algorithm based on STRONGLY-CONNECTED-COMPONENTS on p. 554 of 
	 * "Introduction to Algorithms 2E"
	 * by Cormen, Leiserson, Rivest, and Stein (2002).
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to be broken into components.
	 * @return (CAL type: {@code JList}) 
	 *          a topologically sorted list of strongly-connected components of the
	 * specified graph.
	 */
	public static List stronglyConnectedComponents(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Strongly_Connected_Components.make(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns the target vertex of the given edge.
	 * @param edge (CAL type: {@code Edge})
	 *          the edge.
	 * @return (CAL type: {@code Vertex}) 
	 *          the target vertex of the given edge.
	 */
	public static java.lang.Object targetVertex(final Pair edge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Target_Vertex.$instance.apply(
					RTData.CAL_Opaque.make(edge)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns the target vertex of the given edge.
	 * @param edge (CAL type: {@code Edge})
	 *          the edge.
	 * @return (CAL type: {@code Vertex}) 
	 *          the target vertex of the given edge.
	 */
	public static java.lang.Object targetVertex(final CalValue edge, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((java.lang.Object)(java.lang.Object)
				Target_Vertex.$instance.apply(
					((RTValue)(java.lang.Object)edge)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	/**
	 * Returns the vertices of a graph in topological order if the graph is acyclic
	 * and in an unspecified order otherwise.
	 * <p>
	 * Algorithm based on TOPOLOGICAL-SORT on p. 550 of 
	 * "Introduction to Algorithms 2E"
	 * by Cormen, Leiserson, Rivest, and Stein (2002).
	 * 
	 * @param graph (CAL type: {@code Cal.Utilities.DirectedGraph.DirectedGraph Vertex})
	 *          the graph to be sorted.
	 * @return (CAL type: {@code JList}) 
	 *          an ordered list of vertices.
	 */
	public static List topologicalSort(final CalValue graph, final ExecutionContext executionContext) throws CALExecutorException {
		return 
			((List)(java.lang.Object)
				Topological_Sort.make(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).apply(
					((RTValue)(java.lang.Object)graph)).evaluate(
					((RTExecutionContext)(java.lang.Object)
						executionContext)).getOpaqueValue());
	}

	private static boolean __checkConfig() {
		final StandaloneJarGeneratedCodeInfo generatedCodeInfo = 
			new StandaloneJarGeneratedCodeInfo(
				1612, 
				false, 
				false, 
				false, 
				true, 
				false, 
				false);

		if (!generatedCodeInfo.isCompatibleWithCurrentConfiguration()) {
			throw 
				new java.lang.IllegalStateException(
					generatedCodeInfo.getConfigurationHints());
		} else {
			return true;
		}
	}

	private static final boolean isCompatibleWithCurrentConfiguration = 
		DirectedGraphLibrary.__checkConfig();

}
