package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Find $instance = new Find();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_find_467_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "find", 467, 5);

	private static final ErrorInfo Cal_Collections_IntMap_find_468_16 = 
		new ErrorInfo("Cal.Collections.IntMap", "find", 468, 16);

	private Find() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "find";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.find";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.find
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue m = $rootNode.getArgValue();
		RTValue k$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(m.evaluate($ec), m = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.find
	 */
	public final RTValue f2L(RTValue k$L, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(m.evaluate($ec), m = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.find
	 */
	public final RTValue f2S(int k, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)Lookup.$instance.f2S(k, m.getValue(), $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return 
					RTError.$instance.f2S(
						RTData.CAL_Opaque.make(
							Find.Cal_Collections_IntMap_find_468_16), 
						"Key is not an element of the map", 
						$ec);
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue x = $case1.get_value();

				return x;
			}

			default: {
				return badSwitchIndex(Find.Cal_Collections_IntMap_find_467_5);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Find function;

		private int find$k$1;

		private RTValue find$m$2;

		public RTAppS(Find $function, int $find$k$1, RTValue $find$m$2) {
			assert (($function != null) && ($find$m$2 != null)) : (badConsArgMsg());
			function = $function;
			find$k$1 = $find$k$1;
			find$m$2 = $find$m$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						find$k$1, 
						RTValue.lastRef(find$m$2, find$m$2 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			find$m$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(find$k$1);
				}

				case 1: {
					return find$m$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
