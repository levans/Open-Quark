package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Mask extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Mask $instance = new Mask();

	private Mask() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mask";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.mask";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.mask
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue m$L = $rootNode.getArgValue();
		RTValue i$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				i$L.evaluate($ec).getOrdinalValue(), 
				m$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.mask
	 */
	public final RTValue f2L(RTValue i$L, RTValue m$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				i$L.evaluate($ec).getOrdinalValue(), 
				m$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.mask
	 */
	public final RTValue f2S(int i, int m, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Int.make(i & ((~(m - 1)) ^ m));
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Collections.IntMap.mask
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed2S(int i, int m, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return i & ((~(m - 1)) ^ m);
	}

	public static final class RTAppS extends RTFullApp {
		private final Mask function;

		private int mask$i$1;

		private int mask$m$2;

		public RTAppS(Mask $function, int $mask$i$1, int $mask$m$2) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			mask$i$1 = $mask$i$1;
			mask$m$2 = $mask$m$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f2S(mask$i$1, mask$m$2, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(mask$i$1);
				}

				case 1: {
					return RTData.CAL_Int.make(mask$m$2);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
