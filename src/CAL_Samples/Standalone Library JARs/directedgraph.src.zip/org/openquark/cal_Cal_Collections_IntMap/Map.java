package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Map extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Map $instance = new Map();

	private Map() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "map";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.map";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.map
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue m = $rootNode.getArgValue();
		RTValue f = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(m.evaluate($ec), m = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.map
	 */
	public final RTValue f2L(RTValue f, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(m.evaluate($ec), m = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.map
	 */
	public final RTValue f2S(RTValue f, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Map_With_Key.$instance.f2S(
				new RTPartialApp._3._1(_lambda__map__1.$instance, f), 
				m.getValue(), 
				$ec);
	}

}
