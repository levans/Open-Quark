package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Nomatch extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Nomatch $instance = new Nomatch();

	private Nomatch() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "nomatch";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.nomatch";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.nomatch
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue m$L = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue p$L = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue i$L = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				i$L.evaluate($ec).getOrdinalValue(), 
				p$L.evaluate($ec).getOrdinalValue(), 
				m$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.nomatch
	 */
	public final RTValue f3L(RTValue i$L, RTValue p$L, RTValue m$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				i$L.evaluate($ec).getOrdinalValue(), 
				p$L.evaluate($ec).getOrdinalValue(), 
				m$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.nomatch
	 */
	public final RTValue f3S(int i, int p, int m, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(Mask.$instance.fUnboxed2S(i, m, $ec) != p);
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Collections.IntMap.nomatch
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(int i, int p, int m, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return Mask.$instance.fUnboxed2S(i, m, $ec) != p;
	}

	public static final class RTAppS extends RTFullApp {
		private final Nomatch function;

		private int nomatch$i$1;

		private int nomatch$p$2;

		private int nomatch$m$3;

		public RTAppS(Nomatch $function, int $nomatch$i$1, int $nomatch$p$2, int $nomatch$m$3) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			nomatch$i$1 = $nomatch$i$1;
			nomatch$p$2 = $nomatch$p$2;
			nomatch$m$3 = $nomatch$m$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(nomatch$i$1, nomatch$p$2, nomatch$m$3, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(nomatch$i$1);
				}

				case 1: {
					return RTData.CAL_Int.make(nomatch$p$2);
				}

				case 2: {
					return RTData.CAL_Int.make(nomatch$m$3);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
