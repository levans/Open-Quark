package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Insert_With extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Insert_With $instance = new Insert_With();

	private Insert_With() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "insertWith";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.insertWith";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.insertWith
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue k$L = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue f = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(f, f = null), 
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.insertWith
	 */
	public final RTValue f4L(RTValue f, RTValue k$L, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(f, f = null), 
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.insertWith
	 */
	public final RTValue f4S(RTValue f, int k, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Insert_With_Key.$instance.f4S(
				new RTPartialApp._4._1(_lambda__insert_With__1.$instance, f), 
				k, 
				x, 
				t.getValue(), 
				$ec);
	}

	public static final class RTAppS extends RTFullApp {
		private final Insert_With function;

		private RTValue insertWith$f$1;

		private int insertWith$k$2;

		private RTValue insertWith$x$3;

		private RTValue insertWith$t$4;

		public RTAppS(Insert_With $function, RTValue $insertWith$f$1, int $insertWith$k$2, RTValue $insertWith$x$3, RTValue $insertWith$t$4) {
			assert (
				((($function != null) && ($insertWith$f$1 != null)) && 
				($insertWith$x$3 != null)) && 
				($insertWith$t$4 != null)) : (badConsArgMsg());
			function = $function;
			insertWith$f$1 = $insertWith$f$1;
			insertWith$k$2 = $insertWith$k$2;
			insertWith$x$3 = $insertWith$x$3;
			insertWith$t$4 = $insertWith$t$4;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f4S(
						RTValue.lastRef(insertWith$f$1, insertWith$f$1 = null), 
						insertWith$k$2, 
						RTValue.lastRef(insertWith$x$3, insertWith$x$3 = null), 
						RTValue.lastRef(insertWith$t$4, insertWith$t$4 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			insertWith$f$1 = null;
			insertWith$x$3 = null;
			insertWith$t$4 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 4;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return insertWith$f$1;
				}

				case 1: {
					return RTData.CAL_Int.make(insertWith$k$2);
				}

				case 2: {
					return insertWith$x$3;
				}

				case 3: {
					return insertWith$t$4;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 4)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
