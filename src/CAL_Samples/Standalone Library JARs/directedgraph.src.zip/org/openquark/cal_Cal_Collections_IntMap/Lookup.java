package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Lookup extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Lookup $instance = new Lookup();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_lookup_431_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "lookup", 431, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Lookup() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "lookup";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.lookup";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.lookup
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue k$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.lookup
	 */
	public final RTValue f2L(RTValue k$L, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.lookup
	 */
	public final RTValue f2S(int k, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_Int_Map $case1;

			switch (($case1 = (((TYPE_Int_Map)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Collections.IntMap.Nil
					return Lookup.i_Nothing;
				}

				case 1: {
					// Cal.Collections.IntMap.Tip
					// Decompose data type to access members.
					int key$U = $case1.get_key_As_Int();
					RTValue value = $case1.get_value();

					if (k == key$U) {
						return new TYPE_Maybe.CAL_Just(value);
					} else {
						return Lookup.i_Nothing;
					}
				}

				case 2: {
					// Cal.Collections.IntMap.Bin
					// Decompose data type to access members.
					int prefix$U = $case1.get_prefix_As_Int();
					int mask$U = $case1.get_mask_As_Int();
					RTValue leftMap = $case1.get_leftMap();
					RTValue rightMap = $case1.get_rightMap();

					if (Nomatch.$instance.fUnboxed3S(k, prefix$U, mask$U, $ec)) {
						return Lookup.i_Nothing;
					} else {
						if (Zero.$instance.fUnboxed2S(k, mask$U, $ec)) {
							t = leftMap;
							continue TRLoop;
						} else {
							t = rightMap;
							continue TRLoop;
						}
					}
				}

				default: {
					return 
						badSwitchIndex(
							Lookup.Cal_Collections_IntMap_lookup_431_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Lookup function;

		private int lookup$k$1;

		private RTValue lookup$t$2;

		public RTAppS(Lookup $function, int $lookup$k$1, RTValue $lookup$t$2) {
			assert (($function != null) && ($lookup$t$2 != null)) : (badConsArgMsg());
			function = $function;
			lookup$k$1 = $lookup$k$1;
			lookup$t$2 = $lookup$t$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						lookup$k$1, 
						RTValue.lastRef(lookup$t$2, lookup$t$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			lookup$t$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(lookup$k$1);
				}

				case 1: {
					return lookup$t$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
