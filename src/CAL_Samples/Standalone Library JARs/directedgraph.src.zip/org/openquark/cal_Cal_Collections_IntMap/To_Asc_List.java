package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Span;
import org.openquark.cal_Cal_Core_Prelude.Append_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class To_Asc_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final To_Asc_List $instance = new To_Asc_List();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private To_Asc_List() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "toAscList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.toAscList";
	}

	private static final RTValue neg$3$def_Lazy(RTValue pattern_pos_neg, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_pos_neg, 2);
	}

	private static final RTValue neg$3$def_Strict(RTValue pattern_pos_neg, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_pos_neg.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue pos$2$def_Lazy(RTValue pattern_pos_neg, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_pos_neg, 1);
	}

	private static final RTValue pos$2$def_Strict(RTValue pattern_pos_neg, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_pos_neg.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_pos_neg$4$def_Lazy(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Span.$instance, 
				_lambda__to_Asc_List__1.$instance, 
				new Fold_R.RTAppS(
					Fold_R.$instance, 
					_lambda__to_Asc_List__2.$instance, 
					To_Asc_List.i_Nil, 
					t.getValue()));
	}

	private static final RTValue $pattern_pos_neg$4$def_Strict(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Span.$instance.f2S(
				_lambda__to_Asc_List__1.$instance, 
				Fold_R.$instance.f3S(
					_lambda__to_Asc_List__2.$instance, 
					To_Asc_List.i_Nil, 
					t.getValue(), 
					$ec).evaluate(
					$ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.toAscList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.toAscList
	 */
	public final RTValue f1L(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.toAscList
	 */
	public final RTValue f1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_pattern_pos_neg = 
			To_Asc_List.$pattern_pos_neg$4$def_Lazy(t.getValue(), $ec);

		// Top level supercombinator logic
		return 
			Append_List.$instance.f2S(
				To_Asc_List.neg$3$def_Strict(letVar_pattern_pos_neg, $ec), 
				To_Asc_List.pos$2$def_Lazy(letVar_pattern_pos_neg, $ec), 
				$ec);
	}

}
