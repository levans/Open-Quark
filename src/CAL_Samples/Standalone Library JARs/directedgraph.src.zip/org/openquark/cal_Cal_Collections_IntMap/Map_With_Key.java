package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Map_With_Key extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Map_With_Key $instance = new Map_With_Key();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_mapWithKey_1788_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "mapWithKey", 1788, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Int_Map.CAL_Nil i_Nil = 
		TYPE_Int_Map.CAL_Nil.make();

	private Map_With_Key() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mapWithKey";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.mapWithKey";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.mapWithKey
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue f = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.mapWithKey
	 */
	public final RTValue f2L(RTValue f, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.mapWithKey
	 */
	public final RTValue f2S(RTValue f, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Int_Map $case1;

		switch (($case1 = (((TYPE_Int_Map)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.IntMap.Nil
				return Map_With_Key.i_Nil;
			}

			case 1: {
				// Cal.Collections.IntMap.Tip
				// Decompose data type to access members.
				int k$U = $case1.get_key_As_Int();
				RTValue x = $case1.get_value();

				return 
					new TYPE_Int_Map.CAL_Tip(
						k$U, 
						f.apply(RTData.CAL_Int.make(k$U), x));
			}

			case 2: {
				// Cal.Collections.IntMap.Bin
				// Decompose data type to access members.
				int p$U = $case1.get_prefix_As_Int();
				int m$U = $case1.get_mask_As_Int();
				RTValue l = $case1.get_leftMap();
				RTValue r = $case1.get_rightMap();

				return 
					new TYPE_Int_Map.CAL_Bin(
						p$U, 
						m$U, 
						Map_With_Key.$instance.f2S(f, l, $ec).evaluate($ec), 
						Map_With_Key.$instance.f2S(f, r, $ec).evaluate($ec));
			}

			default: {
				return 
					badSwitchIndex(
						Map_With_Key.Cal_Collections_IntMap_mapWithKey_1788_5);
			}
		}
	}

}
