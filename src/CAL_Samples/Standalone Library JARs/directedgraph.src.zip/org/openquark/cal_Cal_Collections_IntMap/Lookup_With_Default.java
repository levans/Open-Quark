package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Lookup_With_Default extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Lookup_With_Default $instance = 
		new Lookup_With_Default();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_lookupWithDefault_494_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "lookupWithDefault", 494, 5);

	private Lookup_With_Default() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "lookupWithDefault";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.lookupWithDefault";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.lookupWithDefault
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue defaultValue = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue map = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue key$L = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				key$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(map.evaluate($ec), map = null), 
				RTValue.lastRef(defaultValue, defaultValue = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.lookupWithDefault
	 */
	public final RTValue f3L(RTValue key$L, RTValue map, RTValue defaultValue, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				key$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(map.evaluate($ec), map = null), 
				RTValue.lastRef(defaultValue, defaultValue = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.lookupWithDefault
	 */
	public final RTValue f3S(int key, RTValue map, RTValue defaultValue, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)Lookup.$instance.f2S(key, map.getValue(), $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return defaultValue;
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue x = $case1.get_value();

				return x;
			}

			default: {
				return 
					badSwitchIndex(
						Lookup_With_Default.Cal_Collections_IntMap_lookupWithDefault_494_5);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Lookup_With_Default function;

		private int lookupWithDefault$key$1;

		private RTValue lookupWithDefault$map$2;

		private RTValue lookupWithDefault$defaultValue$3;

		public RTAppS(Lookup_With_Default $function, int $lookupWithDefault$key$1, RTValue $lookupWithDefault$map$2, RTValue $lookupWithDefault$defaultValue$3) {
			assert (
				(($function != null) && ($lookupWithDefault$map$2 != null)) && 
				($lookupWithDefault$defaultValue$3 != null)) : (badConsArgMsg());
			function = $function;
			lookupWithDefault$key$1 = $lookupWithDefault$key$1;
			lookupWithDefault$map$2 = $lookupWithDefault$map$2;
			lookupWithDefault$defaultValue$3 = $lookupWithDefault$defaultValue$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						lookupWithDefault$key$1, 
						RTValue.lastRef(
							lookupWithDefault$map$2, 
							lookupWithDefault$map$2 = null), 
						RTValue.lastRef(
							lookupWithDefault$defaultValue$3, 
							lookupWithDefault$defaultValue$3 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			lookupWithDefault$map$2 = null;
			lookupWithDefault$defaultValue$3 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(lookupWithDefault$key$1);
				}

				case 1: {
					return lookupWithDefault$map$2;
				}

				case 2: {
					return lookupWithDefault$defaultValue$3;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
