package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Is_Empty extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Is_Empty $instance = new Is_Empty();

	private Is_Empty() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "isEmpty";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.isEmpty";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.isEmpty
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.isEmpty
	 */
	public final RTValue f1L(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.isEmpty
	 */
	public final RTValue f1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Boolean.make(t.getValue().getOrdinalValue() == 0);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Collections.IntMap.isEmpty
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return t.getValue().getOrdinalValue() == 0;
	}

}
