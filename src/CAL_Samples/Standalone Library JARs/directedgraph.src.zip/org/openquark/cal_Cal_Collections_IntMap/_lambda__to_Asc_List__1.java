package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class _lambda__to_Asc_List__1 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__to_Asc_List__1 $instance = 
		new _lambda__to_Asc_List__1();

	private _lambda__to_Asc_List__1() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$toAscList$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.$lambda$toAscList$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$toAscList$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue k = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(k, k = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$toAscList$1
	 */
	public final RTValue f1L(RTValue k, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(k, k = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$toAscList$1
	 */
	public final RTValue f1S(RTValue k, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(
				(((RTRecordValue)(java.lang.Object)
					k.evaluate($ec))).getOrdinalFieldValue(
					1).evaluate(
					$ec).getOrdinalValue() >= 
				0);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Collections.IntMap.$lambda$toAscList$1
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed1S(RTValue k, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(((RTRecordValue)(java.lang.Object)
				k.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec).getOrdinalValue() >= 
			0;
	}

}
