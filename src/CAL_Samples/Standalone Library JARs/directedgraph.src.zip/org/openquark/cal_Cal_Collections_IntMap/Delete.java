package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Delete extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Delete $instance = new Delete();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_delete_734_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "delete", 734, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Int_Map.CAL_Nil i_Nil = 
		TYPE_Int_Map.CAL_Nil.make();

	private Delete() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "delete";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.delete";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.delete
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue k$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.delete
	 */
	public final RTValue f2L(RTValue k$L, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.delete
	 */
	public final RTValue f2S(int k, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Int_Map $case1;

		switch (($case1 = (((TYPE_Int_Map)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.IntMap.Nil
				return Delete.i_Nil;
			}

			case 1: {
				// Cal.Collections.IntMap.Tip
				// Decompose data type to access members.
				int ky$U = $case1.get_key_As_Int();

				if (k == ky$U) {
					return Delete.i_Nil;
				} else {
					return t.getValue();
				}
			}

			case 2: {
				// Cal.Collections.IntMap.Bin
				// Decompose data type to access members.
				int p$U = $case1.get_prefix_As_Int();
				int m$U = $case1.get_mask_As_Int();
				RTValue l = $case1.get_leftMap();
				RTValue r = $case1.get_rightMap();

				if (Nomatch.$instance.fUnboxed3S(k, p$U, m$U, $ec)) {
					return t.getValue();
				} else {
					if (Zero.$instance.fUnboxed2S(k, m$U, $ec)) {
						return 
							new RTFullApp.General._4._L(
								Bin.$instance, 
								RTData.CAL_Int.make(p$U), 
								RTData.CAL_Int.make(m$U), 
								new RTAppS(Delete.$instance, k, l), 
								r);
					} else {
						return 
							new RTFullApp.General._4._L(
								Bin.$instance, 
								RTData.CAL_Int.make(p$U), 
								RTData.CAL_Int.make(m$U), 
								l, 
								new RTAppS(Delete.$instance, k, r));
					}
				}
			}

			default: {
				return 
					badSwitchIndex(Delete.Cal_Collections_IntMap_delete_734_5);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Delete function;

		private int delete$k$1;

		private RTValue delete$t$2;

		public RTAppS(Delete $function, int $delete$k$1, RTValue $delete$t$2) {
			assert (($function != null) && ($delete$t$2 != null)) : (badConsArgMsg());
			function = $function;
			delete$k$1 = $delete$k$1;
			delete$t$2 = $delete$t$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						delete$k$1, 
						RTValue.lastRef(delete$t$2, delete$t$2 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			delete$t$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(delete$k$1);
				}

				case 1: {
					return delete$t$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
