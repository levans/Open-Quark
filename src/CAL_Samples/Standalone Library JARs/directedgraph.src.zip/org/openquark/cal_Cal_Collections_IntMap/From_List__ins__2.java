package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class From_List__ins__2 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final From_List__ins__2 $instance = new From_List__ins__2();

	private From_List__ins__2() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "fromList$ins$2";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.fromList$ins$2";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.fromList$ins$2
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue p = $rootNode.getArgValue();
		RTValue t = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(t, t = null), 
				RTValue.lastRef(p.evaluate($ec), p = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.fromList$ins$2
	 */
	public final RTValue f2L(RTValue t, RTValue p, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(t, t = null), 
				RTValue.lastRef(p.evaluate($ec), p = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.fromList$ins$2
	 */
	public final RTValue f2S(RTValue t, RTValue p, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)p.getValue());
		RTValue k = $recordCase1.getOrdinalFieldValue(1);
		RTValue x = $recordCase1.getOrdinalFieldValue(2);

		return 
			Insert.$instance.f3S(
				k.evaluate($ec).getOrdinalValue(), 
				x, 
				t.evaluate($ec), 
				$ec);
	}

}
