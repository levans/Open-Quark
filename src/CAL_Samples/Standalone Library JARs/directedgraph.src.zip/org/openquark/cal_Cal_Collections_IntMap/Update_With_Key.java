package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Update_With_Key extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Update_With_Key $instance = new Update_With_Key();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_updateWithKey_850_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "updateWithKey", 850, 5);

	private static final ErrorInfo Cal_Collections_IntMap_updateWithKey_860_13 = 
		new ErrorInfo("Cal.Collections.IntMap", "updateWithKey", 860, 13);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Int_Map.CAL_Nil i_Nil = 
		TYPE_Int_Map.CAL_Nil.make();

	private Update_With_Key() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "updateWithKey";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.updateWithKey";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.updateWithKey
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue k$L = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue f = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(f, f = null), 
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.updateWithKey
	 */
	public final RTValue f3L(RTValue f, RTValue k$L, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(f, f = null), 
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.updateWithKey
	 */
	public final RTValue f3S(RTValue f, int k, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Int_Map $case1;

		switch (($case1 = (((TYPE_Int_Map)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.IntMap.Nil
				return Update_With_Key.i_Nil;
			}

			case 1: {
				// Cal.Collections.IntMap.Tip
				// Decompose data type to access members.
				int ky$U = $case1.get_key_As_Int();
				RTValue y = $case1.get_value();

				if (k == ky$U) {
					TYPE_Maybe $case5;

					switch (($case5 = (((TYPE_Maybe)(java.lang.Object)f.f2L(RTData.CAL_Int.make(k), y, $ec).evaluate($ec)))).getOrdinalValue()) {

						case 0: {
							// Cal.Core.Prelude.Nothing
							return Update_With_Key.i_Nil;
						}

						case 1: {
							// Cal.Core.Prelude.Just
							// Decompose data type to access members.
							RTValue yNew = $case5.get_value();

							return new TYPE_Int_Map.CAL_Tip(ky$U, yNew);
						}

						default: {
							return 
								badSwitchIndex(
									Update_With_Key.Cal_Collections_IntMap_updateWithKey_860_13);
						}
					}
				} else {
					return t.getValue();
				}
			}

			case 2: {
				// Cal.Collections.IntMap.Bin
				// Decompose data type to access members.
				int p$U = $case1.get_prefix_As_Int();
				int m$U = $case1.get_mask_As_Int();
				RTValue l = $case1.get_leftMap();
				RTValue r = $case1.get_rightMap();

				if (Nomatch.$instance.fUnboxed3S(k, p$U, m$U, $ec)) {
					return t.getValue();
				} else {
					if (Zero.$instance.fUnboxed2S(k, m$U, $ec)) {
						return 
							new RTFullApp.General._4._L(
								Bin.$instance, 
								RTData.CAL_Int.make(p$U), 
								RTData.CAL_Int.make(m$U), 
								new RTAppS(Update_With_Key.$instance, f, k, l), 
								r);
					} else {
						return 
							new RTFullApp.General._4._L(
								Bin.$instance, 
								RTData.CAL_Int.make(p$U), 
								RTData.CAL_Int.make(m$U), 
								l, 
								new RTAppS(Update_With_Key.$instance, f, k, r));
					}
				}
			}

			default: {
				return 
					badSwitchIndex(
						Update_With_Key.Cal_Collections_IntMap_updateWithKey_850_5);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Update_With_Key function;

		private RTValue updateWithKey$f$1;

		private int updateWithKey$k$2;

		private RTValue updateWithKey$t$3;

		public RTAppS(Update_With_Key $function, RTValue $updateWithKey$f$1, int $updateWithKey$k$2, RTValue $updateWithKey$t$3) {
			assert (
				(($function != null) && ($updateWithKey$f$1 != null)) && 
				($updateWithKey$t$3 != null)) : (badConsArgMsg());
			function = $function;
			updateWithKey$f$1 = $updateWithKey$f$1;
			updateWithKey$k$2 = $updateWithKey$k$2;
			updateWithKey$t$3 = $updateWithKey$t$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							updateWithKey$f$1, 
							updateWithKey$f$1 = null), 
						updateWithKey$k$2, 
						RTValue.lastRef(
							updateWithKey$t$3, 
							updateWithKey$t$3 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			updateWithKey$f$1 = null;
			updateWithKey$t$3 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return updateWithKey$f$1;
				}

				case 1: {
					return RTData.CAL_Int.make(updateWithKey$k$2);
				}

				case 2: {
					return updateWithKey$t$3;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
