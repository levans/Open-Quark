package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;

public final class From_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final From_List $instance = new From_List();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Int_Map.CAL_Nil i_Nil = 
		TYPE_Int_Map.CAL_Nil.make();

	private From_List() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "fromList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.fromList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.fromList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue xs = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(xs.evaluate($ec), xs = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.fromList
	 */
	public final RTValue f1L(RTValue xs, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(xs.evaluate($ec), xs = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.fromList
	 */
	public final RTValue f1S(RTValue xs, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Fold_Left_Strict.RTAppS(
				Fold_Left_Strict.$instance, 
				From_List__ins__2.$instance, 
				From_List.i_Nil, 
				xs.getValue());
	}

}
