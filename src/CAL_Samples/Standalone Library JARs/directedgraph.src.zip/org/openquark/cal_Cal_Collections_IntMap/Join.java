package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Join extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Join $instance = new Join();

	private Join() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "join";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.join";
	}

	private static final RTValue p$6$def_Lazy(int p1, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Mask.$instance, 
				RTData.CAL_Int.make(p1), 
				m);
	}

	private static final RTValue p$6$def_Strict(int p1, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Mask.$instance.f2S(
				p1, 
				m.evaluate($ec).getOrdinalValue(), 
				$ec).evaluate(
				$ec);
	}

	private static final int p$6$def_Unboxed(int p1, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Mask.$instance.fUnboxed2S(
				p1, 
				m.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	private static final RTValue m$5$def_Lazy(int p1, int p2, RTExecutionContext $ec) throws CALExecutorException {
		return new Branch_Mask.RTAppS(Branch_Mask.$instance, p1, p2);
	}

	private static final RTValue m$5$def_Strict(int p1, int p2, RTExecutionContext $ec) throws CALExecutorException {
		return Branch_Mask.$instance.f2S(p1, p2, $ec).evaluate($ec);
	}

	private static final int m$5$def_Unboxed(int p1, int p2, RTExecutionContext $ec) throws CALExecutorException {
		return Branch_Mask.$instance.fUnboxed2S(p1, p2, $ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.join
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue p2$L = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue t1 = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue p1$L = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				p1$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t1, t1 = null), 
				p2$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t2, t2 = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.join
	 */
	public final RTValue f4L(RTValue p1$L, RTValue t1, RTValue p2$L, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				p1$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t1, t1 = null), 
				p2$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(t2, t2 = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.join
	 */
	public final RTValue f4S(int p1, RTValue t1, int p2, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_m = Join.m$5$def_Lazy(p1, p2, $ec);

		// Top level supercombinator logic
		if (Zero.$instance.fUnboxed2S(
			p1, 
			letVar_m.evaluate($ec).getOrdinalValue(), 
			$ec)) {
			return 
				new TYPE_Int_Map.CAL_Bin(
					Join.p$6$def_Unboxed(p1, letVar_m, $ec), 
					letVar_m.evaluate($ec).getOrdinalValue(), 
					t1.evaluate($ec), 
					t2.evaluate($ec));
		} else {
			return 
				new TYPE_Int_Map.CAL_Bin(
					Join.p$6$def_Unboxed(p1, letVar_m, $ec), 
					letVar_m.evaluate($ec).getOrdinalValue(), 
					t2.evaluate($ec), 
					t1.evaluate($ec));
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Join function;

		private int join$p1$1;

		private RTValue join$t1$2;

		private int join$p2$3;

		private RTValue join$t2$4;

		public RTAppS(Join $function, int $join$p1$1, RTValue $join$t1$2, int $join$p2$3, RTValue $join$t2$4) {
			assert (
				(($function != null) && ($join$t1$2 != null)) && 
				($join$t2$4 != null)) : (badConsArgMsg());
			function = $function;
			join$p1$1 = $join$p1$1;
			join$t1$2 = $join$t1$2;
			join$p2$3 = $join$p2$3;
			join$t2$4 = $join$t2$4;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f4S(
						join$p1$1, 
						RTValue.lastRef(join$t1$2, join$t1$2 = null), 
						join$p2$3, 
						RTValue.lastRef(join$t2$4, join$t2$4 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			join$t1$2 = null;
			join$t2$4 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 4;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(join$p1$1);
				}

				case 1: {
					return join$t1$2;
				}

				case 2: {
					return RTData.CAL_Int.make(join$p2$3);
				}

				case 3: {
					return join$t2$4;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 4)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
