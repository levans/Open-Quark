package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class _lambda__to_List__1 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__to_List__1 $instance = 
		new _lambda__to_List__1();

	private _lambda__to_List__1() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$toList$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.$lambda$toList$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$toList$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue xs = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue k = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(k, k = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(xs, xs = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$toList$1
	 */
	public final RTValue f3L(RTValue k, RTValue x, RTValue xs, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(k, k = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(xs, xs = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$toList$1
	 */
	public final RTValue f3S(RTValue k, RTValue x, RTValue xs, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new TYPE_List.CAL_Cons(
				RTRecordValue.makeTupleRecord(new RTValue[] {k, x}), 
				xs);
	}

}
