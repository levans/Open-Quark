package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class _lambda__update__1 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _lambda__update__1 $instance = new _lambda__update__1();

	private _lambda__update__1() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$lambda$update$1";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.$lambda$update$1";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$update$1
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue x = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue k = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue f = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(k, k = null), 
				RTValue.lastRef(x, x = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$update$1
	 */
	public final RTValue f3L(RTValue f, RTValue k, RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(k, k = null), 
				RTValue.lastRef(x, x = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.$lambda$update$1
	 */
	public final RTValue f3S(RTValue f, RTValue k, RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return f.apply(x);
	}

}
