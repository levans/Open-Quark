package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Update extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Update $instance = new Update();

	private Update() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "update";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.update";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.update
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue m = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue k$L = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue f = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(f, f = null), 
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(m.evaluate($ec), m = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.update
	 */
	public final RTValue f3L(RTValue f, RTValue k$L, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(f, f = null), 
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(m.evaluate($ec), m = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.update
	 */
	public final RTValue f3S(RTValue f, int k, RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Update_With_Key.$instance.f3S(
				new RTPartialApp._3._1(_lambda__update__1.$instance, f), 
				k, 
				m.getValue(), 
				$ec);
	}

	public static final class RTAppS extends RTFullApp {
		private final Update function;

		private RTValue update$f$1;

		private int update$k$2;

		private RTValue update$m$3;

		public RTAppS(Update $function, RTValue $update$f$1, int $update$k$2, RTValue $update$m$3) {
			assert (
				(($function != null) && ($update$f$1 != null)) && 
				($update$m$3 != null)) : (badConsArgMsg());
			function = $function;
			update$f$1 = $update$f$1;
			update$k$2 = $update$k$2;
			update$m$3 = $update$m$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(update$f$1, update$f$1 = null), 
						update$k$2, 
						RTValue.lastRef(update$m$3, update$m$3 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			update$f$1 = null;
			update$m$3 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return update$f$1;
				}

				case 1: {
					return RTData.CAL_Int.make(update$k$2);
				}

				case 2: {
					return update$m$3;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
