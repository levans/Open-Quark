package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Insert extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Insert $instance = new Insert();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_insert_570_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "insert", 570, 5);

	private Insert() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "insert";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.insert";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.insert
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue k$L = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.insert
	 */
	public final RTValue f3L(RTValue k$L, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				k$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.insert
	 */
	public final RTValue f3S(int k, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Int_Map $case1;

		switch (($case1 = (((TYPE_Int_Map)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.IntMap.Nil
				return new TYPE_Int_Map.CAL_Tip(k, x);
			}

			case 1: {
				// Cal.Collections.IntMap.Tip
				// Decompose data type to access members.
				int ky$U = $case1.get_key_As_Int();

				if (k == ky$U) {
					return new TYPE_Int_Map.CAL_Tip(k, x);
				} else {
					return 
						Join.$instance.f4S(
							k, 
							new TYPE_Int_Map.CAL_Tip(k, x), 
							ky$U, 
							t.getValue(), 
							$ec);
				}
			}

			case 2: {
				// Cal.Collections.IntMap.Bin
				// Decompose data type to access members.
				int p$U = $case1.get_prefix_As_Int();
				int m$U = $case1.get_mask_As_Int();
				RTValue l = $case1.get_leftMap();
				RTValue r = $case1.get_rightMap();

				if (Nomatch.$instance.fUnboxed3S(k, p$U, m$U, $ec)) {
					return 
						Join.$instance.f4S(
							k, 
							new TYPE_Int_Map.CAL_Tip(k, x), 
							p$U, 
							t.getValue(), 
							$ec);
				} else {
					if (Zero.$instance.fUnboxed2S(k, m$U, $ec)) {
						return 
							new TYPE_Int_Map.CAL_Bin(
								p$U, 
								m$U, 
								Insert.$instance.f3S(k, x, l, $ec).evaluate(
									$ec), 
								r);
					} else {
						return 
							new TYPE_Int_Map.CAL_Bin(
								p$U, 
								m$U, 
								l, 
								Insert.$instance.f3S(k, x, r, $ec).evaluate(
									$ec));
					}
				}
			}

			default: {
				return 
					badSwitchIndex(Insert.Cal_Collections_IntMap_insert_570_5);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Insert function;

		private int insert$k$1;

		private RTValue insert$x$2;

		private RTValue insert$t$3;

		public RTAppS(Insert $function, int $insert$k$1, RTValue $insert$x$2, RTValue $insert$t$3) {
			assert (
				(($function != null) && ($insert$x$2 != null)) && 
				($insert$t$3 != null)) : (badConsArgMsg());
			function = $function;
			insert$k$1 = $insert$k$1;
			insert$x$2 = $insert$x$2;
			insert$t$3 = $insert$t$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						insert$k$1, 
						RTValue.lastRef(insert$x$2, insert$x$2 = null), 
						RTValue.lastRef(insert$t$3, insert$t$3 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			insert$x$2 = null;
			insert$t$3 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(insert$k$1);
				}

				case 1: {
					return insert$x$2;
				}

				case 2: {
					return insert$t$3;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
