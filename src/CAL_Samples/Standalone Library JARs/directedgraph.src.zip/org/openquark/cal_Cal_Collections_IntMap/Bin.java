package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Bin extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Bin $instance = new Bin();

	private Bin() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "bin";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.bin";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.bin
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue l = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue m = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue p = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(p, p = null), 
				RTValue.lastRef(m, m = null), 
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.bin
	 */
	public final RTValue f4L(RTValue p, RTValue m, RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(p, p = null), 
				RTValue.lastRef(m, m = null), 
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.bin
	 */
	public final RTValue f4S(RTValue p, RTValue m, RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		switch (r.getValue().getOrdinalValue()) {

			case 0: {
				// Cal.Collections.IntMap.Nil
				return l.getValue();
			}

			default: {
				switch (l.getValue().getOrdinalValue()) {

					case 0: {
						// Cal.Collections.IntMap.Nil
						return r.getValue();
					}

					default: {
						return 
							new TYPE_Int_Map.CAL_Bin(
								p.evaluate($ec).getOrdinalValue(), 
								m.evaluate($ec).getOrdinalValue(), 
								l.getValue(), 
								r.getValue());
					}
				}
			}
		}
	}

}
