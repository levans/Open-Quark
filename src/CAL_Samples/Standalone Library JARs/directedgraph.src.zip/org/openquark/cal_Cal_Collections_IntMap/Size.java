package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Size extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_1 = RTData.CAL_Int.make(1);

	private static final RTData.CAL_Int $L2_Int_0 = RTData.CAL_Int.make(0);

	/**
	 * Singleton instance of this class.
	 */
	public static final Size $instance = new Size();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_size_375_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "size", 375, 5);

	private Size() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "size";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.size";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.size
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.size
	 */
	public final RTValue f1L(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.size
	 */
	public final RTValue f1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Int_Map $case1;

		switch (($case1 = (((TYPE_Int_Map)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.IntMap.Nil
				return Size.$L2_Int_0;
			}

			case 1: {
				// Cal.Collections.IntMap.Tip
				return Size.$L1_Int_1;
			}

			case 2: {
				// Cal.Collections.IntMap.Bin
				// Decompose data type to access members.
				RTValue leftMap = $case1.get_leftMap();
				RTValue rightMap = $case1.get_rightMap();

				return 
					RTData.CAL_Int.make(
						Size.$instance.fUnboxed1S(leftMap, $ec) + 
						Size.$instance.fUnboxed1S(rightMap, $ec));
			}

			default: {
				return badSwitchIndex(Size.Cal_Collections_IntMap_size_375_5);
			}
		}
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Collections.IntMap.size
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Int_Map $case1;

		switch (($case1 = (((TYPE_Int_Map)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.IntMap.Nil
				return 0;
			}

			case 1: {
				// Cal.Collections.IntMap.Tip
				return 1;
			}

			case 2: {
				// Cal.Collections.IntMap.Bin
				// Decompose data type to access members.
				RTValue leftMap = $case1.get_leftMap();
				RTValue rightMap = $case1.get_rightMap();

				return 
					Size.$instance.fUnboxed1S(leftMap, $ec) + 
					Size.$instance.fUnboxed1S(rightMap, $ec);
			}

			default: {
				return 
					badSwitchIndex_int(Size.Cal_Collections_IntMap_size_375_5);
			}
		}
	}

}
