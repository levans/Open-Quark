package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Fold_R extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Fold_R $instance = new Fold_R();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_IntMap_foldR_2213_5 = 
		new ErrorInfo("Cal.Collections.IntMap", "foldR", 2213, 5);

	private Fold_R() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "foldR";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.foldR";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.foldR
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue z = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue f = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(z, z = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.foldR
	 */
	public final RTValue f3L(RTValue f, RTValue z, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(z, z = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.foldR
	 */
	public final RTValue f3S(RTValue f, RTValue z, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_Int_Map $case1;

			switch (($case1 = (((TYPE_Int_Map)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Collections.IntMap.Nil
					return z;
				}

				case 1: {
					// Cal.Collections.IntMap.Tip
					// Decompose data type to access members.
					int key$U = $case1.get_key_As_Int();
					RTValue value = $case1.get_value();

					return f.apply(RTData.CAL_Int.make(key$U), value, z);
				}

				case 2: {
					// Cal.Collections.IntMap.Bin
					// Decompose data type to access members.
					RTValue leftMap = $case1.get_leftMap();
					RTValue rightMap = $case1.get_rightMap();

					z = (new RTAppS(Fold_R.$instance, f, z, rightMap));
					t = leftMap;
					continue TRLoop;
				}

				default: {
					return 
						badSwitchIndex(
							Fold_R.Cal_Collections_IntMap_foldR_2213_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Fold_R function;

		private RTValue foldR$f$1;

		private RTValue foldR$z$2;

		private RTValue foldR$t$3;

		public RTAppS(Fold_R $function, RTValue $foldR$f$1, RTValue $foldR$z$2, RTValue $foldR$t$3) {
			assert (
				((($function != null) && ($foldR$f$1 != null)) && 
				($foldR$z$2 != null)) && 
				($foldR$t$3 != null)) : (badConsArgMsg());
			function = $function;
			foldR$f$1 = $foldR$f$1;
			foldR$z$2 = $foldR$z$2;
			foldR$t$3 = $foldR$t$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(foldR$f$1, foldR$f$1 = null), 
						RTValue.lastRef(foldR$z$2, foldR$z$2 = null), 
						RTValue.lastRef(foldR$t$3, foldR$t$3 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			foldR$f$1 = null;
			foldR$z$2 = null;
			foldR$t$3 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return foldR$f$1;
				}

				case 1: {
					return foldR$z$2;
				}

				case 2: {
					return foldR$t$3;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
