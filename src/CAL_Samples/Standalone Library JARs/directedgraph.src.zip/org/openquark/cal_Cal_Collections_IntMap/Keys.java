package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Keys extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Keys $instance = new Keys();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Keys() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "keys";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.keys";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.keys
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue m = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(m.evaluate($ec), m = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.keys
	 */
	public final RTValue f1L(RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(m.evaluate($ec), m = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.keys
	 */
	public final RTValue f1S(RTValue m, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Fold_R.RTAppS(
				Fold_R.$instance, 
				_lambda__keys__1.$instance, 
				Keys.i_Nil, 
				m.getValue());
	}

}
