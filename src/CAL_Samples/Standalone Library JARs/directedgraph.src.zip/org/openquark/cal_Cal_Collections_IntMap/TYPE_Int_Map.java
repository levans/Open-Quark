package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTDataConsFieldSelection;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public abstract class TYPE_Int_Map extends RTCons {
	protected TYPE_Int_Map() {
	}

	public RTValue get_key() {
		return badFieldAccessor("_key");
	}

	public RTValue get_value() {
		return badFieldAccessor("_value");
	}

	public RTValue get_prefix() {
		return badFieldAccessor("_prefix");
	}

	public RTValue get_mask() {
		return badFieldAccessor("_mask");
	}

	public RTValue get_leftMap() {
		return badFieldAccessor("_leftMap");
	}

	public RTValue get_rightMap() {
		return badFieldAccessor("_rightMap");
	}

	public int get_key_As_Int() throws CALExecutorException {
		return badFieldAccessor_Int("_key");
	}

	public int get_prefix_As_Int() throws CALExecutorException {
		return badFieldAccessor_Int("_prefix");
	}

	public int get_mask_As_Int() throws CALExecutorException {
		return badFieldAccessor_Int("_mask");
	}

	protected final java.lang.String getDCNameByOrdinal(int dcOrdinal) {
		switch (dcOrdinal) {

			case 0: {
				return "Nil";
			}

			case 1: {
				return "Tip";
			}

			case 2: {
				return "Bin";
			}

		}
		return 
			((java.lang.String)(java.lang.Object)
				RTValue.badValue_Object(
					null, 
					"Invalid DC ordinal in getDCNameByOrdinal() for org.openquark.cal_Cal_Collections_IntMap.TYPE_Int_Map"));
	}

	public static final class CAL_Nil extends TYPE_Int_Map {
		public static final CAL_Nil $instance = new CAL_Nil();

		private CAL_Nil() {
		}

		public final int getArity() {
			return 0;
		}

		public int getOrdinalValue() {
			return 0;
		}

		public static final CAL_Nil make() {
			return CAL_Nil.$instance;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Collections.IntMap";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Nil";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Collections.IntMap.Nil";
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Collections.IntMap.Nil";
			}

		}
	}
	public static final class CAL_Tip extends TYPE_Int_Map {
		private final int _key;

		private RTValue _value;

		public static final CAL_Tip $instance = new CAL_Tip();

		private CAL_Tip() {
			_key = (-1);
		}

		public CAL_Tip(int member0, RTValue member1) {
			assert (member1 != null) : (
					"Invalid constructor argument for Cal.Collections.IntMap.Tip");
			_key = member0;
			_value = member1;
		}

		public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
			// Arguments
			final RTValue $arg1 = $rootNode.getArgValue();
			RTValue $arg0 = $rootNode.prevArg().getArgValue();

			return new CAL_Tip($arg0.evaluate($ec).getOrdinalValue(), $arg1);
		}

		public final RTValue f2L(RTValue member0, RTValue member1, RTExecutionContext $ec) throws CALExecutorException {
			return new CAL_Tip(member0.evaluate($ec).getOrdinalValue(), member1);
		}

		public final int getArity() {
			return 2;
		}

		public int getOrdinalValue() {
			return 1;
		}

		public static final CAL_Tip make() {
			return CAL_Tip.$instance;
		}

		public final RTValue get_key() {
			return RTData.CAL_Int.make(_key);
		}

		public final int get_key_As_Int() throws CALExecutorException {
			return _key;
		}

		public final RTValue get_value() {
			RTValue _value$;

			if (((java.lang.Object)
				(_value$ = _value))
				 instanceof RTResultFunction) {
				return _value = _value$.getValue();
			}
			return _value$;
		}

		public final RTValue buildDeepSeq(RTSupercombinator deepSeq, RTValue rhs) throws CALExecutorException {
			return deepSeq.apply(get_value(), rhs);
		}

		public final RTValue getFieldByIndex(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return RTData.CAL_Int.make(_key);
				}

				case 1: {
					return get_value();
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return null;
		}

		public final int getFieldByIndex_As_Int(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return _key;
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return -1;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Collections.IntMap";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Tip";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Collections.IntMap.Tip";
		}

		public final boolean isFunctionSingleton() {
			return this == CAL_Tip.$instance;
		}

		public final CalValue debug_getChild(int childN) {
			if (isFunctionSingleton()) {
				throw new java.lang.IndexOutOfBoundsException();
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(_key);
				}

				case 1: {
					return _value;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

					case 0: {
						return "key";
					}

					case 1: {
						return "value";
					}

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Collections.IntMap.Tip";
			}

		}
	}
	public static final class CAL_Bin extends TYPE_Int_Map {
		private final int _prefix;

		private final int _mask;

		private final RTValue _leftMap;

		private final RTValue _rightMap;

		public static final CAL_Bin $instance = new CAL_Bin();

		private CAL_Bin() {
			_prefix = (-1);
			_mask = (-1);
			_leftMap = null;
			_rightMap = null;
		}

		public CAL_Bin(int member0, int member1, RTValue member2, RTValue member3) {
			assert ((member2 != null) && (member3 != null)) : (
					"Invalid constructor argument for Cal.Collections.IntMap.Bin");
			_prefix = member0;
			_mask = member1;
			_leftMap = member2;
			_rightMap = member3;
		}

		public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
			// Arguments
			RTValue $arg3 = $rootNode.getArgValue();
			RTValue $currentRootNode;
			RTValue $arg2 = 
				($currentRootNode = $rootNode.prevArg()).getArgValue();
			RTValue $arg1 = 
				($currentRootNode = $currentRootNode.prevArg()).getArgValue();
			RTValue $arg0 = $currentRootNode.prevArg().getArgValue();

			return 
				new CAL_Bin(
					$arg0.evaluate($ec).getOrdinalValue(), 
					$arg1.evaluate($ec).getOrdinalValue(), 
					$arg2.evaluate($ec), 
					$arg3.evaluate($ec));
		}

		public final RTValue f4L(RTValue member0, RTValue member1, RTValue member2, RTValue member3, RTExecutionContext $ec) throws CALExecutorException {
			return 
				new CAL_Bin(
					member0.evaluate($ec).getOrdinalValue(), 
					member1.evaluate($ec).getOrdinalValue(), 
					member2.evaluate($ec), 
					member3.evaluate($ec));
		}

		public final int getArity() {
			return 4;
		}

		public int getOrdinalValue() {
			return 2;
		}

		public static final CAL_Bin make() {
			return CAL_Bin.$instance;
		}

		public final RTValue get_prefix() {
			return RTData.CAL_Int.make(_prefix);
		}

		public final int get_prefix_As_Int() throws CALExecutorException {
			return _prefix;
		}

		public final RTValue get_mask() {
			return RTData.CAL_Int.make(_mask);
		}

		public final int get_mask_As_Int() throws CALExecutorException {
			return _mask;
		}

		public final RTValue get_leftMap() {
			return _leftMap;
		}

		public final RTValue get_rightMap() {
			return _rightMap;
		}

		public final RTValue buildDeepSeq(RTSupercombinator deepSeq, RTValue rhs) throws CALExecutorException {
			return deepSeq.apply(_leftMap, deepSeq.apply(_rightMap, rhs));
		}

		public final RTValue getFieldByIndex(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return RTData.CAL_Int.make(_prefix);
				}

				case 1: {
					return RTData.CAL_Int.make(_mask);
				}

				case 2: {
					return get_leftMap();
				}

				case 3: {
					return get_rightMap();
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return null;
		}

		public final int getFieldByIndex_As_Int(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return _prefix;
				}

				case 1: {
					return _mask;
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return -1;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Collections.IntMap";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Bin";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Collections.IntMap.Bin";
		}

		public final boolean isFunctionSingleton() {
			return this == CAL_Bin.$instance;
		}

		public final CalValue debug_getChild(int childN) {
			if (isFunctionSingleton()) {
				throw new java.lang.IndexOutOfBoundsException();
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(_prefix);
				}

				case 1: {
					return RTData.CAL_Int.make(_mask);
				}

				case 2: {
					return _leftMap;
				}

				case 3: {
					return _rightMap;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

					case 0: {
						return "prefix";
					}

					case 1: {
						return "mask";
					}

					case 2: {
						return "leftMap";
					}

					case 3: {
						return "rightMap";
					}

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Collections.IntMap.Bin";
			}

		}
	}
}
