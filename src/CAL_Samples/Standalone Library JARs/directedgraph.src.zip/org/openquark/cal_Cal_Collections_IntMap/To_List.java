package org.openquark.cal_Cal_Collections_IntMap;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class To_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final To_List $instance = new To_List();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private To_List() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.IntMap";
	}

	public final java.lang.String getUnqualifiedName() {
		return "toList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.IntMap.toList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.toList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.toList
	 */
	public final RTValue f1L(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.IntMap.toList
	 */
	public final RTValue f1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Fold_R.RTAppS(
				Fold_R.$instance, 
				_lambda__to_List__1.$instance, 
				To_List.i_Nil, 
				t.getValue());
	}

}
