package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Remove_Edge extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Remove_Edge $instance = new Remove_Edge();

	private Remove_Edge() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "removeEdge";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.removeEdge";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.removeEdge
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue edge = $rootNode.getArgValue();
		RTValue graph = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(edge, edge = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.removeEdge
	 */
	public final RTValue f2L(RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(edge, edge = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.removeEdge
	 */
	public final RTValue f2S(RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Remove_Edge.$instance.f3S(
				_dict___Eq___Vertex.$instance, 
				graph, 
				new RTFullApp.General._1._L(Edge_To_Pair.$instance, edge), 
				$ec);
	}

}
