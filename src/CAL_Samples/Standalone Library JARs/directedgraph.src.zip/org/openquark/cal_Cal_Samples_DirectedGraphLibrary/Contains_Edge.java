package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Contains_Edge extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Contains_Edge $instance = new Contains_Edge();

	private Contains_Edge() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "containsEdge";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.containsEdge";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.containsEdge
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue edge = $rootNode.getArgValue();
		RTValue graph = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(edge, edge = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.containsEdge
	 */
	public final RTValue f2L(RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(edge, edge = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.containsEdge
	 */
	public final RTValue f2S(RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Contains_Edge.$instance.f3S(
				_dict___Eq___Vertex.$instance, 
				graph, 
				new RTFullApp.General._1._L(Edge_To_Pair.$instance, edge), 
				$ec);
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.containsEdge
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed2S(RTValue graph, RTValue edge, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Contains_Edge.$instance.f3S(
				_dict___Eq___Vertex.$instance, 
				graph, 
				new RTFullApp.General._1._L(Edge_To_Pair.$instance, edge), 
				$ec).evaluate(
				$ec).getBooleanValue();
	}

}
