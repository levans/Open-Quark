package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Output_List;
import org.openquark.cal_Cal_Core_Prelude.Output_J_Object;

public final class Get_Neighbours extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Get_Neighbours $instance = new Get_Neighbours();

	private Get_Neighbours() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getNeighbours";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.getNeighbours";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.getNeighbours
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue vertex = $rootNode.getArgValue();
		RTValue graph = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.getNeighbours
	 */
	public final RTValue f2L(RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(vertex, vertex = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.getNeighbours
	 */
	public final RTValue f2S(RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Output_List.$instance.f1S(Output_J_Object.$instance, $ec).evaluate(
				$ec).apply(
				new RTFullApp.General._3._S(
					org.openquark.cal_Cal_Utilities_DirectedGraph.Get_Neighbours.$instance, 
					_dict___Eq___Vertex.$instance, 
					graph, 
					vertex));
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.getNeighbours
	 * This version of the logic returns an unboxed value.
	 */
	public final List fUnboxed2S(RTValue graph, RTValue vertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			((List)(java.lang.Object)
				Output_List.$instance.f1S(
					Output_J_Object.$instance, 
					$ec).evaluate(
					$ec).apply(
					new RTFullApp.General._3._S(
						org.openquark.cal_Cal_Utilities_DirectedGraph.Get_Neighbours.$instance, 
						_dict___Eq___Vertex.$instance, 
						graph, 
						vertex)).evaluate(
					$ec).getOpaqueValue());
	}

}
