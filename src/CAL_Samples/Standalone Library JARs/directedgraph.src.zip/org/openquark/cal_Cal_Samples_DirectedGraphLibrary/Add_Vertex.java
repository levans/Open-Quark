package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.Map;
import java.util.WeakHashMap;
import org.openquark.cal.internal.runtime.lecc.RTCAF;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTFunction;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Add_Vertex extends RTCAF {
	/**
	 * Singleton instance of this class.
	 */
	private static final Add_Vertex $instance = new Add_Vertex();

	/*
	 * Mappings of execution context to CAF instances.
	 */

	/**
	 * Execution context -> instance map for addVertex
	 */
	private static final Map $instancesMap = new WeakHashMap();

	private Add_Vertex() {
	}

	public static final synchronized RTFunction make(RTExecutionContext $ec) {
		RTFunction newInstance = 
			((RTFunction)(java.lang.Object)Add_Vertex.$instancesMap.get($ec));

		if (newInstance == null) {
			newInstance = (new RTFullApp.General._0(Add_Vertex.$instance));
			Add_Vertex.$instancesMap.put($ec, newInstance);
		}
		return newInstance;
	}

	public static final synchronized void resetCachedResults(RTExecutionContext $ec) {
		Add_Vertex.$instancesMap.remove($ec);
	}

	public final int getArity() {
		return 0;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addVertex";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.addVertex";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.addVertex
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		// Top level supercombinator logic
		return 
			new RTPartialApp._3._1(
				org.openquark.cal_Cal_Utilities_DirectedGraph.Add_Vertex.$instance, 
				_dict___Eq___Vertex.$instance);
	}

}
