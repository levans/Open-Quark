package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Add_Edges extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Edges $instance = new Add_Edges();

	private Add_Edges() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addEdges";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.addEdges";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.addEdges
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue existsEdgeFn = $rootNode.getArgValue();
		RTValue graph = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.addEdges
	 */
	public final RTValue f2L(RTValue graph, RTValue existsEdgeFn, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(existsEdgeFn, existsEdgeFn = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.addEdges
	 */
	public final RTValue f2S(RTValue graph, RTValue existsEdgeFn, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Add_Edges.$instance.f3S(
				_dict___Eq___Vertex.$instance, 
				graph, 
				new RTPartialApp._3._1(
					Apply_Edge_Predicate.$instance, 
					existsEdgeFn), 
				$ec);
	}

}
