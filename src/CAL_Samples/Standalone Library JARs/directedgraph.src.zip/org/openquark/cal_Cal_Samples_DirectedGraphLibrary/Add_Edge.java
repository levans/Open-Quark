package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Add_Edge extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Add_Edge $instance = new Add_Edge();

	private Add_Edge() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "addEdge";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.addEdge";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.addEdge
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue newEdge = $rootNode.getArgValue();
		RTValue oldGraph = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(newEdge, newEdge = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.addEdge
	 */
	public final RTValue f2L(RTValue oldGraph, RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(oldGraph, oldGraph = null), 
				RTValue.lastRef(newEdge, newEdge = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.addEdge
	 */
	public final RTValue f2S(RTValue oldGraph, RTValue newEdge, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Add_Edge.$instance.f3S(
				_dict___Eq___Vertex.$instance, 
				oldGraph, 
				new RTFullApp.General._1._L(Edge_To_Pair.$instance, newEdge), 
				$ec);
	}

}
