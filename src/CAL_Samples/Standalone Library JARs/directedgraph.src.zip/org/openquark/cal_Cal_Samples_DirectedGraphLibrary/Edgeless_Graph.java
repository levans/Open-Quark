package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.Map;
import java.util.WeakHashMap;
import org.openquark.cal.internal.runtime.lecc.RTCAF;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTFunction;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Input_List;
import org.openquark.cal_Cal_Core_Prelude.Compose;

public final class Edgeless_Graph extends RTCAF {
	/**
	 * Singleton instance of this class.
	 */
	private static final Edgeless_Graph $instance = new Edgeless_Graph();

	/*
	 * Mappings of execution context to CAF instances.
	 */

	/**
	 * Execution context -> instance map for edgelessGraph
	 */
	private static final Map $instancesMap = new WeakHashMap();

	private Edgeless_Graph() {
	}

	public static final synchronized RTFunction make(RTExecutionContext $ec) {
		RTFunction newInstance = 
			((RTFunction)(java.lang.Object)
				Edgeless_Graph.$instancesMap.get($ec));

		if (newInstance == null) {
			newInstance = (new RTFullApp.General._0(Edgeless_Graph.$instance));
			Edgeless_Graph.$instancesMap.put($ec, newInstance);
		}
		return newInstance;
	}

	public static final synchronized void resetCachedResults(RTExecutionContext $ec) {
		Edgeless_Graph.$instancesMap.remove($ec);
	}

	public final int getArity() {
		return 0;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "edgelessGraph";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.edgelessGraph";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.edgelessGraph
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		// Top level supercombinator logic
		return 
			new RTPartialApp._3._2(
				Compose.$instance, 
				new RTPartialApp._2._1(
					org.openquark.cal_Cal_Utilities_DirectedGraph.Edgeless_Graph.$instance, 
					_dict___Eq___Vertex.$instance), 
				new RTPartialApp._2._1(
					Input_List.$instance, 
					_input___Vertex.$instance));
	}

}
