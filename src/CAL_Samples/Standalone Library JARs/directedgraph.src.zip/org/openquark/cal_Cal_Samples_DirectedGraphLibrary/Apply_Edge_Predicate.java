package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.samples.directedgraph.Predicate;
import org.openquark.util.Pair;

public final class Apply_Edge_Predicate extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Apply_Edge_Predicate $instance = 
		new Apply_Edge_Predicate();

	private Apply_Edge_Predicate() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "applyEdgePredicate";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.applyEdgePredicate";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.applyEdgePredicate
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue target$L = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue source$L = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue predicate$L = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				((Predicate)(java.lang.Object)
					predicate$L.evaluate($ec).getOpaqueValue()), 
				source$L.evaluate($ec).getOpaqueValue(), 
				target$L.evaluate($ec).getOpaqueValue(), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.applyEdgePredicate
	 */
	public final RTValue f3L(RTValue predicate$L, RTValue source$L, RTValue target$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				((Predicate)(java.lang.Object)
					predicate$L.evaluate($ec).getOpaqueValue()), 
				source$L.evaluate($ec).getOpaqueValue(), 
				target$L.evaluate($ec).getOpaqueValue(), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.applyEdgePredicate
	 */
	public final RTValue f3S(Predicate predicate, java.lang.Object source, java.lang.Object target, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(predicate.apply(new Pair(source, target)));
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.applyEdgePredicate
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(Predicate predicate, java.lang.Object source, java.lang.Object target, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return predicate.apply(new Pair(source, target));
	}

	public static final class RTAppS extends RTFullApp {
		private final Apply_Edge_Predicate function;

		private Predicate applyEdgePredicate$predicate$1;

		private java.lang.Object applyEdgePredicate$source$2;

		private java.lang.Object applyEdgePredicate$target$3;

		public RTAppS(Apply_Edge_Predicate $function, Predicate $applyEdgePredicate$predicate$1, java.lang.Object $applyEdgePredicate$source$2, java.lang.Object $applyEdgePredicate$target$3) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			applyEdgePredicate$predicate$1 = $applyEdgePredicate$predicate$1;
			applyEdgePredicate$source$2 = $applyEdgePredicate$source$2;
			applyEdgePredicate$target$3 = $applyEdgePredicate$target$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						applyEdgePredicate$predicate$1, 
						applyEdgePredicate$source$2, 
						applyEdgePredicate$target$3, 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return 
						RTData.CAL_Opaque.make(applyEdgePredicate$predicate$1);
				}

				case 1: {
					return RTData.CAL_Opaque.make(applyEdgePredicate$source$2);
				}

				case 2: {
					return RTData.CAL_Opaque.make(applyEdgePredicate$target$3);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
