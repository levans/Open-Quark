package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Input_List;
import org.openquark.cal_Cal_Collections_List.Input_List_With;
import org.openquark.cal_Cal_Core_Prelude.Compose;

public final class Make_Graph extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Make_Graph $instance = new Make_Graph();

	private Make_Graph() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "makeGraph";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.makeGraph";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.makeGraph
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue edges = $rootNode.getArgValue();
		RTValue vertices = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(vertices, vertices = null), 
				RTValue.lastRef(edges, edges = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.makeGraph
	 */
	public final RTValue f2L(RTValue vertices, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(vertices, vertices = null), 
				RTValue.lastRef(edges, edges = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.makeGraph
	 */
	public final RTValue f2S(RTValue vertices, RTValue edges, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Make_Graph.$instance.f3S(
				_dict___Eq___Vertex.$instance, 
				new RTFullApp.General._2._L(
					Input_List.$instance, 
					_input___Vertex.$instance, 
					vertices), 
				new RTFullApp.General._2._L(
					Input_List_With.$instance, 
					edges, 
					new RTPartialApp._3._2(
						Compose.$instance, 
						Edge_To_Pair.$instance, 
						Jobject_To_Edge.$instance)), 
				$ec);
	}

}
