package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_List.Output_List;
import org.openquark.cal_Cal_Core_Prelude.Output_J_Object;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find_Reachable_Cycle extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Reachable_Cycle $instance = 
		new Find_Reachable_Cycle();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Samples_DirectedGraphLibrary_findReachableCycle_684_5 = 
		new ErrorInfo(
			"Cal.Samples.DirectedGraphLibrary", 
			"findReachableCycle", 
			684, 
			5);

	private Find_Reachable_Cycle() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findReachableCycle";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.findReachableCycle";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findReachableCycle
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue startVertex = $rootNode.getArgValue();
		RTValue graph = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findReachableCycle
	 */
	public final RTValue f2L(RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findReachableCycle
	 */
	public final RTValue f2S(RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)org.openquark.cal_Cal_Utilities_DirectedGraph.Find_Reachable_Cycle.$instance.f3S(_dict___Eq___Vertex.$instance, graph, startVertex, $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return RTData.CAL_Opaque.make(null);
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue cycle = $case1.get_value();

				return 
					Output_List.$instance.f1S(
						Output_J_Object.$instance, 
						$ec).evaluate(
						$ec).apply(
						cycle);
			}

			default: {
				return 
					badSwitchIndex(
						Find_Reachable_Cycle.Cal_Samples_DirectedGraphLibrary_findReachableCycle_684_5);
			}
		}
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.findReachableCycle
	 * This version of the logic returns an unboxed value.
	 */
	public final List fUnboxed2S(RTValue graph, RTValue startVertex, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = f2S(graph, startVertex, $ec);

		graph = null;
		startVertex = null;
		return ((List)(java.lang.Object)$result.evaluate($ec).getOpaqueValue());
	}

}
