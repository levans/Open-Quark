package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.Map;
import java.util.WeakHashMap;
import org.openquark.cal.internal.runtime.lecc.RTCAF;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTFunction;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Exists_Cycle extends RTCAF {
	/**
	 * Singleton instance of this class.
	 */
	private static final Exists_Cycle $instance = new Exists_Cycle();

	/*
	 * Mappings of execution context to CAF instances.
	 */

	/**
	 * Execution context -> instance map for existsCycle
	 */
	private static final Map $instancesMap = new WeakHashMap();

	private Exists_Cycle() {
	}

	public static final synchronized RTFunction make(RTExecutionContext $ec) {
		RTFunction newInstance = 
			((RTFunction)(java.lang.Object)Exists_Cycle.$instancesMap.get($ec));

		if (newInstance == null) {
			newInstance = (new RTFullApp.General._0(Exists_Cycle.$instance));
			Exists_Cycle.$instancesMap.put($ec, newInstance);
		}
		return newInstance;
	}

	public static final synchronized void resetCachedResults(RTExecutionContext $ec) {
		Exists_Cycle.$instancesMap.remove($ec);
	}

	public final int getArity() {
		return 0;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "existsCycle";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.existsCycle";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.existsCycle
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		// Top level supercombinator logic
		return 
			new RTPartialApp._2._1(
				org.openquark.cal_Cal_Utilities_DirectedGraph.Exists_Cycle.$instance, 
				_dict___Eq___Vertex.$instance);
	}

}
