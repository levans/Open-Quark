package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.util.Pair;

public final class Make_Edge extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Make_Edge $instance = new Make_Edge();

	private Make_Edge() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "makeEdge";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.makeEdge";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.makeEdge
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $x1$L = $rootNode.getArgValue();
		RTValue $x0$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				$x0$L.evaluate($ec).getOpaqueValue(), 
				$x1$L.evaluate($ec).getOpaqueValue(), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.makeEdge
	 */
	public final RTValue f2L(RTValue $x0$L, RTValue $x1$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				$x0$L.evaluate($ec).getOpaqueValue(), 
				$x1$L.evaluate($ec).getOpaqueValue(), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.makeEdge
	 */
	public final RTValue f2S(java.lang.Object $x0, java.lang.Object $x1, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Opaque.make(new Pair($x0, $x1));
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.makeEdge
	 * This version of the logic returns an unboxed value.
	 */
	public final Pair fUnboxed2S(java.lang.Object $x0, java.lang.Object $x1, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return ((Pair)(java.lang.Object)(new Pair($x0, $x1)));
	}

	public static final class RTAppS extends RTFullApp {
		private final Make_Edge function;

		private java.lang.Object $x0;

		private java.lang.Object $x1;

		public RTAppS(Make_Edge $function, java.lang.Object $$x0, java.lang.Object $$x1) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			$x0 = $$x0;
			$x1 = $$x1;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f2S($x0, $x1, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Opaque.make($x0);
				}

				case 1: {
					return RTData.CAL_Opaque.make($x1);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
