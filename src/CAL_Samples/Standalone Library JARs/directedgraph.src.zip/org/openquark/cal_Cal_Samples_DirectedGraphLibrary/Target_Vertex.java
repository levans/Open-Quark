package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.util.Pair;

public final class Target_Vertex extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Target_Vertex $instance = new Target_Vertex();

	private Target_Vertex() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "targetVertex";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.targetVertex";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.targetVertex
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $x0$L = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				((Pair)(java.lang.Object)$x0$L.evaluate($ec).getOpaqueValue()), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.targetVertex
	 */
	public final RTValue f1L(RTValue $x0$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				((Pair)(java.lang.Object)$x0$L.evaluate($ec).getOpaqueValue()), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.targetVertex
	 */
	public final RTValue f1S(Pair $x0, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Opaque.make($x0.snd());
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.targetVertex
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.Object fUnboxed1S(Pair $x0, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return $x0.snd();
	}

	public static final class RTAppS extends RTFullApp {
		private final Target_Vertex function;

		private Pair $x0;

		public RTAppS(Target_Vertex $function, Pair $$x0) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			$x0 = $$x0;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f1S($x0, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 1;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Opaque.make($x0);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 1)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
