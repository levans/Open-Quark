package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.samples.directedgraph.BinaryFunction;

public final class Apply_Accumulator_Function extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Apply_Accumulator_Function $instance = 
		new Apply_Accumulator_Function();

	private Apply_Accumulator_Function() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "applyAccumulatorFunction";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.applyAccumulatorFunction";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.applyAccumulatorFunction
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $x2$L = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue $x1$L = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $x0$L = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				((BinaryFunction)(java.lang.Object)
					$x0$L.evaluate($ec).getOpaqueValue()), 
				$x1$L.evaluate($ec).getOpaqueValue(), 
				$x2$L.evaluate($ec).getOpaqueValue(), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.applyAccumulatorFunction
	 */
	public final RTValue f3L(RTValue $x0$L, RTValue $x1$L, RTValue $x2$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				((BinaryFunction)(java.lang.Object)
					$x0$L.evaluate($ec).getOpaqueValue()), 
				$x1$L.evaluate($ec).getOpaqueValue(), 
				$x2$L.evaluate($ec).getOpaqueValue(), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.applyAccumulatorFunction
	 */
	public final RTValue f3S(BinaryFunction $x0, java.lang.Object $x1, java.lang.Object $x2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Opaque.make($x0.apply($x1, $x2));
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.applyAccumulatorFunction
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.Object fUnboxed3S(BinaryFunction $x0, java.lang.Object $x1, java.lang.Object $x2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return $x0.apply($x1, $x2);
	}

	public static final class RTAppS extends RTFullApp {
		private final Apply_Accumulator_Function function;

		private BinaryFunction $x0;

		private java.lang.Object $x1;

		private java.lang.Object $x2;

		public RTAppS(Apply_Accumulator_Function $function, BinaryFunction $$x0, java.lang.Object $$x1, java.lang.Object $$x2) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			$x0 = $$x0;
			$x1 = $$x1;
			$x2 = $$x2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f3S($x0, $x1, $x2, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Opaque.make($x0);
				}

				case 1: {
					return RTData.CAL_Opaque.make($x1);
				}

				case 2: {
					return RTData.CAL_Opaque.make($x2);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
