package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Filter extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Filter $instance = new Filter();

	private Filter() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "filter";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.filter";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.filter
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue filterFn = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(filterFn, filterFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.filter
	 */
	public final RTValue f2L(RTValue filterFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(filterFn, filterFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.filter
	 */
	public final RTValue f2S(RTValue filterFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Filter.$instance.f3S(
				_dict___Eq___Vertex.$instance, 
				new RTPartialApp._2._1(
					Apply_Vertex_Predicate.$instance, 
					filterFn), 
				graph, 
				$ec);
	}

}
