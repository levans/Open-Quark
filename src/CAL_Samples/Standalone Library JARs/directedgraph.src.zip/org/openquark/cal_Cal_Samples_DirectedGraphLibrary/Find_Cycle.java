package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_List.Output_List;
import org.openquark.cal_Cal_Core_Prelude.Output_J_Object;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find_Cycle extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Cycle $instance = new Find_Cycle();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Samples_DirectedGraphLibrary_findCycle_650_5 = 
		new ErrorInfo("Cal.Samples.DirectedGraphLibrary", "findCycle", 650, 5);

	private Find_Cycle() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findCycle";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.findCycle";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findCycle
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findCycle
	 */
	public final RTValue f1L(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(graph, graph = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findCycle
	 */
	public final RTValue f1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)org.openquark.cal_Cal_Utilities_DirectedGraph.Find_Cycle.$instance.f2S(_dict___Eq___Vertex.$instance, graph, $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return RTData.CAL_Opaque.make(null);
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue cycle = $case1.get_value();

				return 
					Output_List.$instance.f1S(
						Output_J_Object.$instance, 
						$ec).evaluate(
						$ec).apply(
						cycle);
			}

			default: {
				return 
					badSwitchIndex(
						Find_Cycle.Cal_Samples_DirectedGraphLibrary_findCycle_650_5);
			}
		}
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.findCycle
	 * This version of the logic returns an unboxed value.
	 */
	public final List fUnboxed1S(RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = f1S(graph, $ec);

		graph = null;
		return ((List)(java.lang.Object)$result.evaluate($ec).getOpaqueValue());
	}

}
