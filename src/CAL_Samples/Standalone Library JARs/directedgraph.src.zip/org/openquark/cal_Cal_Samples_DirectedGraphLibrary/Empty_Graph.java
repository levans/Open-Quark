package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.Map;
import java.util.WeakHashMap;
import org.openquark.cal.internal.runtime.lecc.RTCAF;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTFunction;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Empty_Graph extends RTCAF {
	/**
	 * Singleton instance of this class.
	 */
	private static final Empty_Graph $instance = new Empty_Graph();

	/*
	 * Mappings of execution context to CAF instances.
	 */

	/**
	 * Execution context -> instance map for emptyGraph
	 */
	private static final Map $instancesMap = new WeakHashMap();

	private Empty_Graph() {
	}

	public static final synchronized RTFunction make(RTExecutionContext $ec) {
		RTFunction newInstance = 
			((RTFunction)(java.lang.Object)Empty_Graph.$instancesMap.get($ec));

		if (newInstance == null) {
			newInstance = (new RTFullApp.General._0(Empty_Graph.$instance));
			Empty_Graph.$instancesMap.put($ec, newInstance);
		}
		return newInstance;
	}

	public static final synchronized void resetCachedResults(RTExecutionContext $ec) {
		Empty_Graph.$instancesMap.remove($ec);
	}

	public final int getArity() {
		return 0;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "emptyGraph";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.emptyGraph";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.emptyGraph
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Empty_Graph.$instance.f1S(
				_dict___Eq___Vertex.$instance, 
				$ec);
	}

}
