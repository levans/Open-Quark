package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_List.Output_List;
import org.openquark.cal_Cal_Core_Prelude.Output_J_Object;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find_Path extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Path $instance = new Find_Path();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Samples_DirectedGraphLibrary_findPath_720_5 = 
		new ErrorInfo("Cal.Samples.DirectedGraphLibrary", "findPath", 720, 5);

	private Find_Path() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findPath";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.findPath";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findPath
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue endVertex = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue startVertex = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue graph = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(endVertex, endVertex = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findPath
	 */
	public final RTValue f3L(RTValue graph, RTValue startVertex, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(graph, graph = null), 
				RTValue.lastRef(startVertex, startVertex = null), 
				RTValue.lastRef(endVertex, endVertex = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.findPath
	 */
	public final RTValue f3S(RTValue graph, RTValue startVertex, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)org.openquark.cal_Cal_Utilities_DirectedGraph.Find_Path.$instance.f4S(_dict___Eq___Vertex.$instance, graph, startVertex, endVertex, $ec).evaluate($ec)))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return RTData.CAL_Opaque.make(null);
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue path = $case1.get_value();

				return 
					Output_List.$instance.f1S(
						Output_J_Object.$instance, 
						$ec).evaluate(
						$ec).apply(
						path);
			}

			default: {
				return 
					badSwitchIndex(
						Find_Path.Cal_Samples_DirectedGraphLibrary_findPath_720_5);
			}
		}
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.findPath
	 * This version of the logic returns an unboxed value.
	 */
	public final List fUnboxed3S(RTValue graph, RTValue startVertex, RTValue endVertex, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = f3S(graph, startVertex, endVertex, $ec);

		graph = null;
		startVertex = null;
		endVertex = null;
		return ((List)(java.lang.Object)$result.evaluate($ec).getOpaqueValue());
	}

}
