package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import java.util.Map;
import java.util.WeakHashMap;
import org.openquark.cal.internal.runtime.lecc.RTCAF;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTFunction;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Collections_List.Output_List;
import org.openquark.cal_Cal_Core_Prelude.Compose;
import org.openquark.cal_Cal_Core_Prelude.Output_J_Object;

public final class Get_Vertices_In_Insertion_Order extends RTCAF {
	/**
	 * Singleton instance of this class.
	 */
	private static final Get_Vertices_In_Insertion_Order $instance = 
		new Get_Vertices_In_Insertion_Order();

	/*
	 * Mappings of execution context to CAF instances.
	 */

	/**
	 * Execution context -> instance map for getVerticesInInsertionOrder
	 */
	private static final Map $instancesMap = new WeakHashMap();

	private Get_Vertices_In_Insertion_Order() {
	}

	public static final synchronized RTFunction make(RTExecutionContext $ec) {
		RTFunction newInstance = 
			((RTFunction)(java.lang.Object)
				Get_Vertices_In_Insertion_Order.$instancesMap.get($ec));

		if (newInstance == null) {
				newInstance = 
				(new RTFullApp.General._0(
					Get_Vertices_In_Insertion_Order.$instance));
			Get_Vertices_In_Insertion_Order.$instancesMap.put($ec, newInstance);
		}
		return newInstance;
	}

	public static final synchronized void resetCachedResults(RTExecutionContext $ec) {
		Get_Vertices_In_Insertion_Order.$instancesMap.remove($ec);
	}

	public final int getArity() {
		return 0;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "getVerticesInInsertionOrder";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.getVerticesInInsertionOrder";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.getVerticesInInsertionOrder
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		// Top level supercombinator logic
		return 
			new RTPartialApp._3._2(
				Compose.$instance, 
				new RTFullApp.General._1._S(
					Output_List.$instance, 
					Output_J_Object.$instance), 
				org.openquark.cal_Cal_Utilities_DirectedGraph.Get_Vertices_In_Insertion_Order.$instance);
	}

}
