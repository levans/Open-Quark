package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Fold_In_Depth_First_Search_Order extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Fold_In_Depth_First_Search_Order $instance = 
		new Fold_In_Depth_First_Search_Order();

	private Fold_In_Depth_First_Search_Order() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "foldInDepthFirstSearchOrder";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.foldInDepthFirstSearchOrder";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.foldInDepthFirstSearchOrder
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue init = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue finishVertexFn = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue startVertexFn = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(init, init = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.foldInDepthFirstSearchOrder
	 */
	public final RTValue f4L(RTValue startVertexFn, RTValue finishVertexFn, RTValue init, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(startVertexFn, startVertexFn = null), 
				RTValue.lastRef(finishVertexFn, finishVertexFn = null), 
				RTValue.lastRef(init, init = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.foldInDepthFirstSearchOrder
	 */
	public final RTValue f4S(RTValue startVertexFn, RTValue finishVertexFn, RTValue init, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Fold_In_Depth_First_Search_Order.$instance.f5S(
				_dict___Eq___Vertex.$instance, 
				new RTPartialApp._3._1(
					Apply_Accumulator_Function.$instance, 
					startVertexFn), 
				new RTPartialApp._3._1(
					Apply_Accumulator_Function.$instance, 
					finishVertexFn), 
				init, 
				graph, 
				$ec);
	}

	/**
	 * fUnboxed4S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.foldInDepthFirstSearchOrder
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.Object fUnboxed4S(RTValue startVertexFn, RTValue finishVertexFn, RTValue init, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			org.openquark.cal_Cal_Utilities_DirectedGraph.Fold_In_Depth_First_Search_Order.$instance.f5S(
				_dict___Eq___Vertex.$instance, 
				new RTPartialApp._3._1(
					Apply_Accumulator_Function.$instance, 
					startVertexFn), 
				new RTPartialApp._3._1(
					Apply_Accumulator_Function.$instance, 
					finishVertexFn), 
				init, 
				graph, 
				$ec).evaluate(
				$ec).getOpaqueValue();
	}

}
