package org.openquark.cal_Cal_Samples_DirectedGraphLibrary;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Cal_Value_To_Object;
import org.openquark.util.Pair;

public final class Partition extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Partition $instance = new Partition();

	private Partition() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Samples.DirectedGraphLibrary";
	}

	public final java.lang.String getUnqualifiedName() {
		return "partition";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Samples.DirectedGraphLibrary.partition";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.partition
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue graph = $rootNode.getArgValue();
		RTValue partitionFn = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(partitionFn, partitionFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.partition
	 */
	public final RTValue f2L(RTValue partitionFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(partitionFn, partitionFn = null), 
				RTValue.lastRef(graph, graph = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Samples.DirectedGraphLibrary.partition
	 */
	public final RTValue f2S(RTValue partitionFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)
				org.openquark.cal_Cal_Utilities_DirectedGraph.Partition.$instance.f3S(
					_dict___Eq___Vertex.$instance, 
					new RTPartialApp._2._1(
						Apply_Vertex_Predicate.$instance, 
						partitionFn), 
					graph, 
					$ec).evaluate(
					$ec));
		RTValue graph1 = $recordCase1.getOrdinalFieldValue(1);
		RTValue graph2 = $recordCase1.getOrdinalFieldValue(2);

		return 
			RTData.CAL_Opaque.make(
				new Pair(
					Cal_Value_To_Object.$instance.fUnboxed1S(graph1, $ec), 
					Cal_Value_To_Object.$instance.fUnboxed1S(graph2, $ec)));
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Samples.DirectedGraphLibrary.partition
	 * This version of the logic returns an unboxed value.
	 */
	public final Pair fUnboxed2S(RTValue partitionFn, RTValue graph, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic

		RTRecordValue $recordCase1 = 
			((RTRecordValue)(java.lang.Object)
				org.openquark.cal_Cal_Utilities_DirectedGraph.Partition.$instance.f3S(
					_dict___Eq___Vertex.$instance, 
					new RTPartialApp._2._1(
						Apply_Vertex_Predicate.$instance, 
						partitionFn), 
					graph, 
					$ec).evaluate(
					$ec));
		RTValue graph1 = $recordCase1.getOrdinalFieldValue(1);
		RTValue graph2 = $recordCase1.getOrdinalFieldValue(2);

		return 
			((Pair)(java.lang.Object)
				(new Pair(
					Cal_Value_To_Object.$instance.fUnboxed1S(graph1, $ec), 
					Cal_Value_To_Object.$instance.fUnboxed1S(graph2, $ec))));
	}

}
