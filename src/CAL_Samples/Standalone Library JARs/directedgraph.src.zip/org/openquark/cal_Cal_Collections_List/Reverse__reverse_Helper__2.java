package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Reverse__reverse_Helper__2 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Reverse__reverse_Helper__2 $instance = 
		new Reverse__reverse_Helper__2();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_reverse_814_13 = 
		new ErrorInfo("Cal.Collections.List", "reverse", 814, 13);

	private Reverse__reverse_Helper__2() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "reverse$reverseHelper$2";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.reverse$reverseHelper$2";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.reverse$reverseHelper$2
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue resultList = $rootNode.getArgValue();
		RTValue sourceList = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(sourceList.evaluate($ec), sourceList = null), 
				RTValue.lastRef(resultList, resultList = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.reverse$reverseHelper$2
	 */
	public final RTValue f2L(RTValue sourceList, RTValue resultList, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(sourceList.evaluate($ec), sourceList = null), 
				RTValue.lastRef(resultList, resultList = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.reverse$reverseHelper$2
	 */
	public final RTValue f2S(RTValue sourceList, RTValue resultList, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)sourceList.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return resultList;
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue headSourceList = $case1.get_head();
					RTValue tailSourceList = $case1.get_tail();

					sourceList = tailSourceList.evaluate($ec);
						resultList = 
						(new TYPE_List.CAL_Cons(headSourceList, resultList));
					continue TRLoop;
				}

				default: {
					return 
						badSwitchIndex(
							Reverse__reverse_Helper__2.Cal_Collections_List_reverse_814_13);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Reverse__reverse_Helper__2 function;

		private RTValue reverse$sourceList$3;

		private RTValue reverse$resultList$4;

		public RTAppS(Reverse__reverse_Helper__2 $function, RTValue $reverse$sourceList$3, RTValue $reverse$resultList$4) {
			assert (
				(($function != null) && ($reverse$sourceList$3 != null)) && 
				($reverse$resultList$4 != null)) : (badConsArgMsg());
			function = $function;
			reverse$sourceList$3 = $reverse$sourceList$3;
			reverse$resultList$4 = $reverse$resultList$4;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(
							reverse$sourceList$3, 
							reverse$sourceList$3 = null), 
						RTValue.lastRef(
							reverse$resultList$4, 
							reverse$resultList$4 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			reverse$sourceList$3 = null;
			reverse$resultList$4 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return reverse$sourceList$3;
				}

				case 1: {
					return reverse$resultList$4;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
