package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTOApp2;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;

public final class Sum extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_3 = RTData.CAL_Int.make(3);

	private static final RTData.CAL_Int $L2_Int_12 = RTData.CAL_Int.make(12);

	private static final RTData.CAL_Int $L3_Int_0 = RTData.CAL_Int.make(0);

	/**
	 * Singleton instance of this class.
	 */
	public static final Sum $instance = new Sum();

	private Sum() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "sum";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.sum";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.sum
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $dictvarCal_Core_Prelude_Num_24 = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Num_24, 
					$dictvarCal_Core_Prelude_Num_24 = null), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.List.sum
	 */
	public final RTValue f1L(RTValue $dictvarCal_Core_Prelude_Num_24, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Num_24, 
					$dictvarCal_Core_Prelude_Num_24 = null), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.List.sum
	 */
	public final RTValue f1S(RTValue $dictvarCal_Core_Prelude_Num_24, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Fold_Left_Strict.$instance.apply(
				$dictvarCal_Core_Prelude_Num_24.apply(Sum.$L1_Int_3), 
				new RTOApp2(
					$dictvarCal_Core_Prelude_Num_24, 
					Sum.$L2_Int_12, 
					Sum.$L3_Int_0));
	}

}
