package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Reverse extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Reverse $instance = new Reverse();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Reverse() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "reverse";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.reverse";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.reverse
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.List.reverse
	 */
	public final RTValue f1L(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.List.reverse
	 */
	public final RTValue f1S(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Reverse__reverse_Helper__2.RTAppS(
				Reverse__reverse_Helper__2.$instance, 
				list.getValue(), 
				Reverse.i_Nil);
	}

}
