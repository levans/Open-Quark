package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Head extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Head $instance = new Head();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_head_67_5 = 
		new ErrorInfo("Cal.Collections.List", "head", 67, 5);

	private static final ErrorInfo Cal_Collections_List_head_71_9 = 
		new ErrorInfo("Cal.Collections.List", "head", 71, 9);

	private Head() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "head";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.head";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.head
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.List.head
	 */
	public final RTValue f1L(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.List.head
	 */
	public final RTValue f1S(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return 
					RTError.$instance.f2S(
						RTData.CAL_Opaque.make(
							Head.Cal_Collections_List_head_71_9), 
						"Empty list.", 
						$ec);
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue listHead = $case1.get_head();

				return listHead;
			}

			default: {
				return badSwitchIndex(Head.Cal_Collections_List_head_67_5);
			}
		}
	}

}
