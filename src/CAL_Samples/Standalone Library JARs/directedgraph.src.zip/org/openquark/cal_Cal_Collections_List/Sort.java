package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Sort extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_5 = RTData.CAL_Int.make(5);

	/**
	 * Singleton instance of this class.
	 */
	public static final Sort $instance = new Sort();

	private Sort() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "sort";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.sort";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.sort
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $dictvarCal_Core_Prelude_Ord_15 = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_15, 
					$dictvarCal_Core_Prelude_Ord_15 = null), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.List.sort
	 */
	public final RTValue f1L(RTValue $dictvarCal_Core_Prelude_Ord_15, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_15, 
					$dictvarCal_Core_Prelude_Ord_15 = null), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.List.sort
	 */
	public final RTValue f1S(RTValue $dictvarCal_Core_Prelude_Ord_15, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new RTPartialApp._2._1(
				Sort_By.$instance, 
				$dictvarCal_Core_Prelude_Ord_15.apply(Sort.$L1_Int_5));
	}

}
