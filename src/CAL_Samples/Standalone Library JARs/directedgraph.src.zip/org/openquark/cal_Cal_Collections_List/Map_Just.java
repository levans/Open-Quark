package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Map_Just extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Map_Just $instance = new Map_Just();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_mapJust_2660_5 = 
		new ErrorInfo("Cal.Collections.List", "mapJust", 2660, 5);

	private static final ErrorInfo Cal_Collections_List_mapJust_2663_9 = 
		new ErrorInfo("Cal.Collections.List", "mapJust", 2663, 9);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Map_Just() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mapJust";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.mapJust";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.mapJust
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue mapFunction = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(mapFunction, mapFunction = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.mapJust
	 */
	public final RTValue f2L(RTValue mapFunction, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(mapFunction, mapFunction = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.mapJust
	 */
	public final RTValue f2S(RTValue mapFunction, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return Map_Just.i_Nil;
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listHead = $case1.get_head();
					RTValue listTail = $case1.get_tail();

					TYPE_Maybe $case2;

					switch (($case2 = (((TYPE_Maybe)(java.lang.Object)mapFunction.f1L(listHead, $ec).evaluate($ec)))).getOrdinalValue()) {

						case 0: {
							// Cal.Core.Prelude.Nothing
							list = listTail.evaluate($ec);
							continue TRLoop;
						}

						case 1: {
							// Cal.Core.Prelude.Just
							// Decompose data type to access members.
							RTValue value = $case2.get_value();

							return 
								new TYPE_List.CAL_Cons(
									value, 
									new RTFullApp.General._2._L(
										Map_Just.$instance, 
										mapFunction, 
										listTail));
						}

						default: {
							return 
								badSwitchIndex(
									Map_Just.Cal_Collections_List_mapJust_2663_9);
						}
					}
				}

				default: {
					return 
						badSwitchIndex(
							Map_Just.Cal_Collections_List_mapJust_2660_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Map_Just function;

		private RTValue mapJust$mapFunction$1;

		private RTValue mapJust$list$2;

		public RTAppS(Map_Just $function, RTValue $mapJust$mapFunction$1, RTValue $mapJust$list$2) {
			assert (
				(($function != null) && ($mapJust$mapFunction$1 != null)) && 
				($mapJust$list$2 != null)) : (badConsArgMsg());
			function = $function;
			mapJust$mapFunction$1 = $mapJust$mapFunction$1;
			mapJust$list$2 = $mapJust$list$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(
							mapJust$mapFunction$1, 
							mapJust$mapFunction$1 = null), 
						RTValue.lastRef(mapJust$list$2, mapJust$list$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			mapJust$mapFunction$1 = null;
			mapJust$list$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return mapJust$mapFunction$1;
				}

				case 1: {
					return mapJust$list$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
