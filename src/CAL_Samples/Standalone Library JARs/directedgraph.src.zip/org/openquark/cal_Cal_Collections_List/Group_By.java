package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Group_By extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Group_By $instance = new Group_By();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_groupBy_2094_5 = 
		new ErrorInfo("Cal.Collections.List", "groupBy", 2094, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Group_By() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "groupBy";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.groupBy";
	}

	private static final RTValue pr$5$def_Lazy(RTValue equalityFunction, RTValue listHead, RTValue listTail, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Span.$instance, 
				equalityFunction.apply(listHead), 
				listTail);
	}

	private static final RTValue pr$5$def_Strict(RTValue equalityFunction, RTValue listHead, RTValue listTail, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Span.$instance.f2S(
				equalityFunction.apply(listHead), 
				listTail.evaluate($ec), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.groupBy
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue equalityFunction = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(equalityFunction, equalityFunction = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.groupBy
	 */
	public final RTValue f2L(RTValue equalityFunction, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(equalityFunction, equalityFunction = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.groupBy
	 */
	public final RTValue f2S(RTValue equalityFunction, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return Group_By.i_Nil;
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue listHead = $case1.get_head();
				RTValue listTail = $case1.get_tail();
				RTValue letVar_pr = 
					Group_By.pr$5$def_Lazy(
						equalityFunction, 
						listHead, 
						listTail, 
						$ec);

				return 
					new TYPE_List.CAL_Cons(
						new TYPE_List.CAL_Cons(
							listHead, 
							new RTRecordSelection.Ordinal(letVar_pr, 1)), 
						new RTFullApp.General._2._L(
							Group_By.$instance, 
							equalityFunction, 
							new RTRecordSelection.Ordinal(letVar_pr, 2)));
			}

			default: {
				return 
					badSwitchIndex(Group_By.Cal_Collections_List_groupBy_2094_5);
			}
		}
	}

}
