package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Unzip extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Unzip $instance = new Unzip();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_unzip_1476_5 = 
		new ErrorInfo("Cal.Collections.List", "unzip", 1476, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Unzip() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "unzip";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.unzip";
	}

	private static final RTValue tail2$5$def_Lazy(RTValue pattern_tail1_tail2, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_tail1_tail2, 2);
	}

	private static final RTValue tail2$5$def_Strict(RTValue pattern_tail1_tail2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_tail1_tail2.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue tail1$4$def_Lazy(RTValue pattern_tail1_tail2, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_tail1_tail2, 1);
	}

	private static final RTValue tail1$4$def_Strict(RTValue pattern_tail1_tail2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_tail1_tail2.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_tail1_tail2$6$def_Lazy(RTValue xs, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._1._L(Unzip.$instance, xs);
	}

	private static final RTValue $pattern_tail1_tail2$6$def_Strict(RTValue xs, RTExecutionContext $ec) throws CALExecutorException {
		return Unzip.$instance.f1S(xs.evaluate($ec), $ec).evaluate($ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.unzip
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.List.unzip
	 */
	public final RTValue f1L(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.List.unzip
	 */
	public final RTValue f1S(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {Unzip.i_Nil, Unzip.i_Nil});
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue x = $case1.get_head();
				RTValue xs = $case1.get_tail();
				RTValue letVar_pattern_tail1_tail2 = 
					Unzip.$pattern_tail1_tail2$6$def_Lazy(xs, $ec);


				RTRecordValue $recordCase2 = 
					((RTRecordValue)(java.lang.Object)x.evaluate($ec));
				RTValue x1 = $recordCase2.getOrdinalFieldValue(1);
				RTValue x2 = $recordCase2.getOrdinalFieldValue(2);

				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {new TYPE_List.CAL_Cons(x1, Unzip.tail1$4$def_Lazy(letVar_pattern_tail1_tail2, $ec)), new TYPE_List.CAL_Cons(x2, Unzip.tail2$5$def_Lazy(letVar_pattern_tail1_tail2, $ec))});
			}

			default: {
				return badSwitchIndex(Unzip.Cal_Collections_List_unzip_1476_5);
			}
		}
	}

}
