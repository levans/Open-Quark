package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Sort_By__merge_Pairs__4 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Sort_By__merge_Pairs__4 $instance = 
		new Sort_By__merge_Pairs__4();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_sortBy_2415_13 = 
		new ErrorInfo("Cal.Collections.List", "sortBy", 2415, 13);

	private static final ErrorInfo Cal_Collections_List_sortBy_2418_17 = 
		new ErrorInfo("Cal.Collections.List", "sortBy", 2418, 17);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Sort_By__merge_Pairs__4() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "sortBy$mergePairs$4";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.sortBy$mergePairs$4";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy$mergePairs$4
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue xss = $rootNode.getArgValue();
		RTValue cmp = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(cmp, cmp = null), 
				RTValue.lastRef(xss.evaluate($ec), xss = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy$mergePairs$4
	 */
	public final RTValue f2L(RTValue cmp, RTValue xss, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(cmp, cmp = null), 
				RTValue.lastRef(xss.evaluate($ec), xss = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy$mergePairs$4
	 */
	public final RTValue f2S(RTValue cmp, RTValue xss, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)xss.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return Sort_By__merge_Pairs__4.i_Nil;
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue xs1 = $case1.get_head();
				RTValue xssTail = $case1.get_tail();

				TYPE_List $case2;

				switch (($case2 = (((TYPE_List)(java.lang.Object)xssTail.evaluate($ec)))).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.Nil
						return xss.getValue();
					}

					case 1: {
						// Cal.Core.Prelude.Cons
						// Decompose data type to access members.
						RTValue xs2 = $case2.get_head();
						RTValue xssTailTail = $case2.get_tail();

						return 
							new TYPE_List.CAL_Cons(
								new RTFullApp.General._3._L(
									Merge_By.$instance, 
									cmp, 
									xs1, 
									xs2), 
								new RTFullApp.General._2._L(
									Sort_By__merge_Pairs__4.$instance, 
									cmp, 
									xssTailTail));
					}

					default: {
						return 
							badSwitchIndex(
								Sort_By__merge_Pairs__4.Cal_Collections_List_sortBy_2418_17);
					}
				}
			}

			default: {
				return 
					badSwitchIndex(
						Sort_By__merge_Pairs__4.Cal_Collections_List_sortBy_2415_13);
			}
		}
	}

}
