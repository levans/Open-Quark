package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Sort_By__sort_Helper__3 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Sort_By__sort_Helper__3 $instance = 
		new Sort_By__sort_Helper__3();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_sortBy_2403_13 = 
		new ErrorInfo("Cal.Collections.List", "sortBy", 2403, 13);

	private static final ErrorInfo Cal_Collections_List_sortBy_2406_17 = 
		new ErrorInfo("Cal.Collections.List", "sortBy", 2406, 17);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Sort_By__sort_Helper__3() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "sortBy$sortHelper$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.sortBy$sortHelper$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy$sortHelper$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue xss = $rootNode.getArgValue();
		RTValue cmp = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(cmp, cmp = null), 
				RTValue.lastRef(xss.evaluate($ec), xss = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy$sortHelper$3
	 */
	public final RTValue f2L(RTValue cmp, RTValue xss, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(cmp, cmp = null), 
				RTValue.lastRef(xss.evaluate($ec), xss = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy$sortHelper$3
	 */
	public final RTValue f2S(RTValue cmp, RTValue xss, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)xss.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return Sort_By__sort_Helper__3.i_Nil;
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue xs1 = $case1.get_head();
					RTValue xssTail = $case1.get_tail();

					switch (xssTail.evaluate($ec).getOrdinalValue()) {

						case 0: {
							// Cal.Core.Prelude.Nil
							return xs1;
						}

						case 1: {
							// Cal.Core.Prelude.Cons
								xss = 
								Sort_By__merge_Pairs__4.$instance.f2S(
									cmp, 
									xss.getValue(), 
									$ec).evaluate(
									$ec);
							continue TRLoop;
						}

						default: {
							return 
								badSwitchIndex(
									Sort_By__sort_Helper__3.Cal_Collections_List_sortBy_2406_17);
						}
					}
				}

				default: {
					return 
						badSwitchIndex(
							Sort_By__sort_Helper__3.Cal_Collections_List_sortBy_2403_13);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Sort_By__sort_Helper__3 function;

		private RTValue sortBy$cmp$5;

		private RTValue sortBy$xss$6;

		public RTAppS(Sort_By__sort_Helper__3 $function, RTValue $sortBy$cmp$5, RTValue $sortBy$xss$6) {
			assert (
				(($function != null) && ($sortBy$cmp$5 != null)) && 
				($sortBy$xss$6 != null)) : (badConsArgMsg());
			function = $function;
			sortBy$cmp$5 = $sortBy$cmp$5;
			sortBy$xss$6 = $sortBy$xss$6;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(sortBy$cmp$5, sortBy$cmp$5 = null), 
						RTValue.lastRef(sortBy$xss$6, sortBy$xss$6 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			sortBy$cmp$5 = null;
			sortBy$xss$6 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return sortBy$cmp$5;
				}

				case 1: {
					return sortBy$xss$6;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
