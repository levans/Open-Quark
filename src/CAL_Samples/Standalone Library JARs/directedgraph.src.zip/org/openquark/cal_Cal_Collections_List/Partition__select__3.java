package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Partition__select__3 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Partition__select__3 $instance = 
		new Partition__select__3();

	private Partition__select__3() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "partition$select$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.partition$select$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.partition$select$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue tfs = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue predicate = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(predicate.evaluate($ec), predicate = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(tfs, tfs = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.List.partition$select$3
	 */
	public final RTValue f3L(RTValue predicate, RTValue x, RTValue tfs, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(predicate.evaluate($ec), predicate = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(tfs, tfs = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.List.partition$select$3
	 */
	public final RTValue f3S(RTValue predicate, RTValue x, RTValue tfs, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (predicate.getValue().f1L(x, $ec).evaluate($ec).getBooleanValue()) {
			return 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {new TYPE_List.CAL_Cons(x, new RTRecordSelection.Ordinal(tfs, 1)), new RTRecordSelection.Ordinal(tfs, 2)});
		} else {
			return 
				RTRecordValue.makeTupleRecord(
					new RTValue[] {new RTRecordSelection.Ordinal(tfs, 1), new TYPE_List.CAL_Cons(x, new RTRecordSelection.Ordinal(tfs, 2))});
		}
	}

}
