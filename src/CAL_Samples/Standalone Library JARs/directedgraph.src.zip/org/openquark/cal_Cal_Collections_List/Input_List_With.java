package org.openquark.cal_Cal_Collections_List;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal_Cal_Core_Prelude.List_From_J_Collection_With;

public final class Input_List_With extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Input_List_With $instance = new Input_List_With();

	private Input_List_With() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "inputListWith";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.inputListWith";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.inputListWith
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue elementMappingFunction = $rootNode.getArgValue();
		RTValue javaList$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				((List)(java.lang.Object)
					javaList$L.evaluate($ec).getOpaqueValue()), 
				RTValue.lastRef(
					elementMappingFunction, 
					elementMappingFunction = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.inputListWith
	 */
	public final RTValue f2L(RTValue javaList$L, RTValue elementMappingFunction, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				((List)(java.lang.Object)
					javaList$L.evaluate($ec).getOpaqueValue()), 
				RTValue.lastRef(
					elementMappingFunction, 
					elementMappingFunction = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.inputListWith
	 */
	public final RTValue f2S(List javaList, RTValue elementMappingFunction, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			List_From_J_Collection_With.$instance.f2S(
				javaList, 
				elementMappingFunction, 
				$ec);
	}

	public static final class RTAppS extends RTFullApp {
		private final Input_List_With function;

		private List inputListWith$javaList$1;

		private RTValue inputListWith$elementMappingFunction$2;

		public RTAppS(Input_List_With $function, List $inputListWith$javaList$1, RTValue $inputListWith$elementMappingFunction$2) {
			assert (
				($function != null) && 
				($inputListWith$elementMappingFunction$2 != null)) : (badConsArgMsg());
			function = $function;
			inputListWith$javaList$1 = $inputListWith$javaList$1;
				inputListWith$elementMappingFunction$2 = 
				$inputListWith$elementMappingFunction$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						inputListWith$javaList$1, 
						RTValue.lastRef(
							inputListWith$elementMappingFunction$2, 
							inputListWith$elementMappingFunction$2 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			inputListWith$elementMappingFunction$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Opaque.make(inputListWith$javaList$1);
				}

				case 1: {
					return inputListWith$elementMappingFunction$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
