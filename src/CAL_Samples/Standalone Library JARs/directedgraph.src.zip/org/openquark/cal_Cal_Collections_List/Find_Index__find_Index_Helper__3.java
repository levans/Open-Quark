package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find_Index__find_Index_Helper__3 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Index__find_Index_Helper__3 $instance = 
		new Find_Index__find_Index_Helper__3();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_findIndex_1667_13 = 
		new ErrorInfo("Cal.Collections.List", "findIndex", 1667, 13);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Find_Index__find_Index_Helper__3() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findIndex$findIndexHelper$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.findIndex$findIndexHelper$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.findIndex$findIndexHelper$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue currentIndex$L = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue predicate = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(predicate, predicate = null), 
				currentIndex$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.List.findIndex$findIndexHelper$3
	 */
	public final RTValue f3L(RTValue predicate, RTValue currentIndex$L, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(predicate, predicate = null), 
				currentIndex$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.List.findIndex$findIndexHelper$3
	 */
	public final RTValue f3S(RTValue predicate, int currentIndex, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return Find_Index__find_Index_Helper__3.i_Nothing;
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listHead = $case1.get_head();
					RTValue listTail = $case1.get_tail();

					if (predicate.f1L(listHead, $ec).evaluate(
						$ec).getBooleanValue()) {
						return 
							new TYPE_Maybe.CAL_Just(
								RTData.CAL_Int.make(currentIndex));
					} else {
						currentIndex = (currentIndex + 1);
						list = listTail.evaluate($ec);
						continue TRLoop;
					}
				}

				default: {
					return 
						badSwitchIndex(
							Find_Index__find_Index_Helper__3.Cal_Collections_List_findIndex_1667_13);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Find_Index__find_Index_Helper__3 function;

		private RTValue findIndex$predicate$4;

		private int findIndex$currentIndex$5;

		private RTValue findIndex$list$6;

		public RTAppS(Find_Index__find_Index_Helper__3 $function, RTValue $findIndex$predicate$4, int $findIndex$currentIndex$5, RTValue $findIndex$list$6) {
			assert (
				(($function != null) && ($findIndex$predicate$4 != null)) && 
				($findIndex$list$6 != null)) : (badConsArgMsg());
			function = $function;
			findIndex$predicate$4 = $findIndex$predicate$4;
			findIndex$currentIndex$5 = $findIndex$currentIndex$5;
			findIndex$list$6 = $findIndex$list$6;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							findIndex$predicate$4, 
							findIndex$predicate$4 = null), 
						findIndex$currentIndex$5, 
						RTValue.lastRef(
							findIndex$list$6, 
							findIndex$list$6 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			findIndex$predicate$4 = null;
			findIndex$list$6 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return findIndex$predicate$4;
				}

				case 1: {
					return RTData.CAL_Int.make(findIndex$currentIndex$5);
				}

				case 2: {
					return findIndex$list$6;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
