package org.openquark.cal_Cal_Collections_List;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Input_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Input_List $instance = new Input_List();

	private Input_List() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "inputList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.inputList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.inputList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list$L = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Inputable_8 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Inputable_8, 
					$dictvarCal_Core_Prelude_Inputable_8 = null), 
				((List)(java.lang.Object)
					list$L.evaluate($ec).getOpaqueValue()), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.inputList
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Inputable_8, RTValue list$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Inputable_8, 
					$dictvarCal_Core_Prelude_Inputable_8 = null), 
				((List)(java.lang.Object)
					list$L.evaluate($ec).getOpaqueValue()), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.inputList
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Inputable_8, List list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			From_J_Collection.$instance.f1S(
				$dictvarCal_Core_Prelude_Inputable_8, 
				$ec).evaluate(
				$ec).apply(
				new J_List_To_J_Collection.RTAppS(
					J_List_To_J_Collection.$instance, 
					list));
	}

	public static final class RTAppS extends RTFullApp {
		private final Input_List function;

		private RTValue $dictvarCal_Core_Prelude_Inputable_8;

		private List inputList$list$1;

		public RTAppS(Input_List $function, RTValue $$dictvarCal_Core_Prelude_Inputable_8, List $inputList$list$1) {
			assert (
				($function != null) && 
				($$dictvarCal_Core_Prelude_Inputable_8 != null)) : (badConsArgMsg());
			function = $function;
				$dictvarCal_Core_Prelude_Inputable_8 = 
				$$dictvarCal_Core_Prelude_Inputable_8;
			inputList$list$1 = $inputList$list$1;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(
							$dictvarCal_Core_Prelude_Inputable_8, 
							$dictvarCal_Core_Prelude_Inputable_8 = null), 
						inputList$list$1, 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			$dictvarCal_Core_Prelude_Inputable_8 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return $dictvarCal_Core_Prelude_Inputable_8;
				}

				case 1: {
					return RTData.CAL_Opaque.make(inputList$list$1);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
