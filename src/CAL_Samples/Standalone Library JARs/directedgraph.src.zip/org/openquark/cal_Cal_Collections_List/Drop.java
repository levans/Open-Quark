package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Drop extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Drop $instance = new Drop();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_drop_663_9 = 
		new ErrorInfo("Cal.Collections.List", "drop", 663, 9);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Drop() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "drop";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.drop";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.drop
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue nElements$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				nElements$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.drop
	 */
	public final RTValue f2L(RTValue nElements$L, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				nElements$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.drop
	 */
	public final RTValue f2S(int nElements, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			if (nElements <= 0) {
				return list.getValue();
			} else {
				TYPE_List $case2;

				switch (($case2 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.Nil
						return Drop.i_Nil;
					}

					case 1: {
						// Cal.Core.Prelude.Cons
						// Decompose data type to access members.
						RTValue listTail = $case2.get_tail();

						nElements = (nElements - 1);
						list = listTail.evaluate($ec);
						continue TRLoop;
					}

					default: {
						return 
							badSwitchIndex(Drop.Cal_Collections_List_drop_663_9);
					}
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Drop function;

		private int drop$nElements$1;

		private RTValue drop$list$2;

		public RTAppS(Drop $function, int $drop$nElements$1, RTValue $drop$list$2) {
			assert (($function != null) && ($drop$list$2 != null)) : (badConsArgMsg());
			function = $function;
			drop$nElements$1 = $drop$nElements$1;
			drop$list$2 = $drop$list$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						drop$nElements$1, 
						RTValue.lastRef(drop$list$2, drop$list$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			drop$list$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(drop$nElements$1);
				}

				case 1: {
					return drop$list$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
