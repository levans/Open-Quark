package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Merge_By extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Merge_By $instance = new Merge_By();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_mergeBy_2339_5 = 
		new ErrorInfo("Cal.Collections.List", "mergeBy", 2339, 5);

	private static final ErrorInfo Cal_Collections_List_mergeBy_2342_9 = 
		new ErrorInfo("Cal.Collections.List", "mergeBy", 2342, 9);

	private Merge_By() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mergeBy";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.mergeBy";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.mergeBy
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue list1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue comparator = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(comparator, comparator = null), 
				RTValue.lastRef(list1.evaluate($ec), list1 = null), 
				RTValue.lastRef(list2.evaluate($ec), list2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.List.mergeBy
	 */
	public final RTValue f3L(RTValue comparator, RTValue list1, RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(comparator, comparator = null), 
				RTValue.lastRef(list1.evaluate($ec), list1 = null), 
				RTValue.lastRef(list2.evaluate($ec), list2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.List.mergeBy
	 */
	public final RTValue f3S(RTValue comparator, RTValue list1, RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list2.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return list1.getValue();
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue list2Head = $case1.get_head();
				RTValue list2Tail = $case1.get_tail();

				TYPE_List $case2;

				switch (($case2 = (((TYPE_List)(java.lang.Object)list1.getValue()))).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.Nil
						return list2.getValue();
					}

					case 1: {
						// Cal.Core.Prelude.Cons
						// Decompose data type to access members.
						RTValue list1Head = $case2.get_head();
						RTValue list1Tail = $case2.get_tail();

						switch (comparator.f2L(list1Head, list2Head, $ec).evaluate($ec).getOrdinalValue()) {

							case 2: {
								// Cal.Core.Prelude.GT
								return 
									new TYPE_List.CAL_Cons(
										list2Head, 
										new RTFullApp.General._3._L(
											Merge_By.$instance, 
											comparator, 
											list1.getValue(), 
											list2Tail));
							}

							default: {
								return 
									new TYPE_List.CAL_Cons(
										list1Head, 
										new RTFullApp.General._3._L(
											Merge_By.$instance, 
											comparator, 
											list1Tail, 
											list2.getValue()));
							}
						}
					}

					default: {
						return 
							badSwitchIndex(
								Merge_By.Cal_Collections_List_mergeBy_2342_9);
					}
				}
			}

			default: {
				return 
					badSwitchIndex(Merge_By.Cal_Collections_List_mergeBy_2339_5);
			}
		}
	}

}
