package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Tail extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Tail $instance = new Tail();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_tail_82_5 = 
		new ErrorInfo("Cal.Collections.List", "tail", 82, 5);

	private static final ErrorInfo Cal_Collections_List_tail_86_9 = 
		new ErrorInfo("Cal.Collections.List", "tail", 86, 9);

	private Tail() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "tail";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.tail";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.tail
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.List.tail
	 */
	public final RTValue f1L(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.List.tail
	 */
	public final RTValue f1S(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return 
					RTError.$instance.f2S(
						RTData.CAL_Opaque.make(
							Tail.Cal_Collections_List_tail_86_9), 
						"Empty list.", 
						$ec);
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue listTail = $case1.get_tail();

				return listTail;
			}

			default: {
				return badSwitchIndex(Tail.Cal_Collections_List_tail_82_5);
			}
		}
	}

}
