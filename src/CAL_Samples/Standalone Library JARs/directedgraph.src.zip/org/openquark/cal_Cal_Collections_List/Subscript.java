package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Subscript extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Subscript $instance = new Subscript();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_subscript_300_5 = 
		new ErrorInfo("Cal.Collections.List", "subscript", 300, 5);

	private static final ErrorInfo Cal_Collections_List_subscript_307_13 = 
		new ErrorInfo("Cal.Collections.List", "subscript", 307, 13);

	private static final ErrorInfo Cal_Collections_List_subscript_309_11 = 
		new ErrorInfo("Cal.Collections.List", "subscript", 309, 11);

	private Subscript() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "subscript";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.subscript";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.subscript
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue index$L = $rootNode.getArgValue();
		RTValue list = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(list.evaluate($ec), list = null), 
				index$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.subscript
	 */
	public final RTValue f2L(RTValue list, RTValue index$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(list.evaluate($ec), list = null), 
				index$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.subscript
	 */
	public final RTValue f2S(RTValue list, int index, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return 
						RTError.$instance.f2S(
							RTData.CAL_Opaque.make(
								Subscript.Cal_Collections_List_subscript_309_11), 
							"Index out of bounds.", 
							$ec);
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listHead = $case1.get_head();
					RTValue listTail = $case1.get_tail();

					if (index == 0) {
						return listHead;
					} else {
						if (index > 0) {
							list = listTail.evaluate($ec);
							index = (index - 1);
							continue TRLoop;
						} else {
							return 
								RTError.$instance.f2S(
									RTData.CAL_Opaque.make(
										Subscript.Cal_Collections_List_subscript_307_13), 
									"Negative index.", 
									$ec);
						}
					}
				}

				default: {
					return 
						badSwitchIndex(
							Subscript.Cal_Collections_List_subscript_300_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Subscript function;

		private RTValue subscript$list$1;

		private int subscript$index$2;

		public RTAppS(Subscript $function, RTValue $subscript$list$1, int $subscript$index$2) {
			assert (($function != null) && ($subscript$list$1 != null)) : (badConsArgMsg());
			function = $function;
			subscript$list$1 = $subscript$list$1;
			subscript$index$2 = $subscript$index$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(
							subscript$list$1, 
							subscript$list$1 = null), 
						subscript$index$2, 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			subscript$list$1 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return subscript$list$1;
				}

				case 1: {
					return RTData.CAL_Int.make(subscript$index$2);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
