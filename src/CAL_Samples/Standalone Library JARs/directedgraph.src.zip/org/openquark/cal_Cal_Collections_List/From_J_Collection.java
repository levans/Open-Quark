package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.List_From_J_Collection;

public final class From_J_Collection extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final From_J_Collection $instance = new From_J_Collection();

	private From_J_Collection() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "fromJCollection";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.fromJCollection";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.fromJCollection
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $dictvarCal_Core_Prelude_Inputable_7 = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Inputable_7, 
					$dictvarCal_Core_Prelude_Inputable_7 = null), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.List.fromJCollection
	 */
	public final RTValue f1L(RTValue $dictvarCal_Core_Prelude_Inputable_7, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Inputable_7, 
					$dictvarCal_Core_Prelude_Inputable_7 = null), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.List.fromJCollection
	 */
	public final RTValue f1S(RTValue $dictvarCal_Core_Prelude_Inputable_7, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new RTPartialApp._2._1(
				List_From_J_Collection.$instance, 
				$dictvarCal_Core_Prelude_Inputable_7);
	}

}
