package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Map_Indexed__map_Indexed_Helper__3 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Map_Indexed__map_Indexed_Helper__3 $instance = 
		new Map_Indexed__map_Indexed_Helper__3();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_mapIndexed_164_13 = 
		new ErrorInfo("Cal.Collections.List", "mapIndexed", 164, 13);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Map_Indexed__map_Indexed_Helper__3() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "mapIndexed$mapIndexedHelper$3";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.mapIndexed$mapIndexedHelper$3";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.mapIndexed$mapIndexedHelper$3
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue index$L = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue mapFunction = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(mapFunction, mapFunction = null), 
				index$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.List.mapIndexed$mapIndexedHelper$3
	 */
	public final RTValue f3L(RTValue mapFunction, RTValue index$L, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(mapFunction, mapFunction = null), 
				index$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.List.mapIndexed$mapIndexedHelper$3
	 */
	public final RTValue f3S(RTValue mapFunction, int index, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return Map_Indexed__map_Indexed_Helper__3.i_Nil;
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue listHead = $case1.get_head();
				RTValue listTail = $case1.get_tail();

				return 
					new TYPE_List.CAL_Cons(
						mapFunction.apply(
							listHead, 
							RTData.CAL_Int.make(index)), 
						new RTFullApp.General._3._L(
							Map_Indexed__map_Indexed_Helper__3.$instance, 
							mapFunction, 
							RTData.CAL_Int.make(index + 1), 
							listTail));
			}

			default: {
				return 
					badSwitchIndex(
						Map_Indexed__map_Indexed_Helper__3.Cal_Collections_List_mapIndexed_164_13);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Map_Indexed__map_Indexed_Helper__3 function;

		private RTValue mapIndexed$mapFunction$1;

		private int mapIndexed$index$4;

		private RTValue mapIndexed$list$5;

		public RTAppS(Map_Indexed__map_Indexed_Helper__3 $function, RTValue $mapIndexed$mapFunction$1, int $mapIndexed$index$4, RTValue $mapIndexed$list$5) {
			assert (
				(($function != null) && ($mapIndexed$mapFunction$1 != null)) && 
				($mapIndexed$list$5 != null)) : (badConsArgMsg());
			function = $function;
			mapIndexed$mapFunction$1 = $mapIndexed$mapFunction$1;
			mapIndexed$index$4 = $mapIndexed$index$4;
			mapIndexed$list$5 = $mapIndexed$list$5;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							mapIndexed$mapFunction$1, 
							mapIndexed$mapFunction$1 = null), 
						mapIndexed$index$4, 
						RTValue.lastRef(
							mapIndexed$list$5, 
							mapIndexed$list$5 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			mapIndexed$mapFunction$1 = null;
			mapIndexed$list$5 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return mapIndexed$mapFunction$1;
				}

				case 1: {
					return RTData.CAL_Int.make(mapIndexed$index$4);
				}

				case 2: {
					return mapIndexed$list$5;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
