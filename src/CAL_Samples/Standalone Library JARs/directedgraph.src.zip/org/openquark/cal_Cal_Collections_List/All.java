package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class All extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Boolean $L1_Boolean_false = 
		RTData.CAL_Boolean.make(false);

	/**
	 * Singleton instance of this class.
	 */
	public static final All $instance = new All();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_all_942_5 = 
		new ErrorInfo("Cal.Collections.List", "all", 942, 5);

	private All() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "all";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.all";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.all
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue predicate = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(predicate, predicate = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.all
	 */
	public final RTValue f2L(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(predicate, predicate = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.all
	 */
	public final RTValue f2S(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return RTData.CAL_Boolean.make(true);
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listHead = $case1.get_head();
					RTValue listTail = $case1.get_tail();

					if (predicate.f1L(listHead, $ec).evaluate(
						$ec).getBooleanValue()) {
						list = listTail.evaluate($ec);
						continue TRLoop;
					} else {
						return All.$L1_Boolean_false;
					}
				}

				default: {
					return badSwitchIndex(All.Cal_Collections_List_all_942_5);
				}
			}
		}
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Collections.List.all
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed2S(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return true;
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listHead = $case1.get_head();
					RTValue listTail = $case1.get_tail();

					if (predicate.f1L(listHead, $ec).evaluate(
						$ec).getBooleanValue()) {
						list = listTail.evaluate($ec);
						continue TRLoop;
					} else {
						return false;
					}
				}

				default: {
					return 
						badSwitchIndex_boolean(
							All.Cal_Collections_List_all_942_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final All function;

		private RTValue all$predicate$1;

		private RTValue all$list$2;

		public RTAppS(All $function, RTValue $all$predicate$1, RTValue $all$list$2) {
			assert (
				(($function != null) && ($all$predicate$1 != null)) && 
				($all$list$2 != null)) : (badConsArgMsg());
			function = $function;
			all$predicate$1 = $all$predicate$1;
			all$list$2 = $all$list$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(
							all$predicate$1, 
							all$predicate$1 = null), 
						RTValue.lastRef(all$list$2, all$list$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			all$predicate$1 = null;
			all$list$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return all$predicate$1;
				}

				case 1: {
					return all$list$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
