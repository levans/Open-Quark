package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Span extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Span $instance = new Span();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_span_734_5 = 
		new ErrorInfo("Cal.Collections.List", "span", 734, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Span() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "span";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.span";
	}

	private static final RTValue spanListTail$5$def_Lazy(RTValue predicate, RTValue listTail, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._2._L(Span.$instance, predicate, listTail);
	}

	private static final RTValue spanListTail$5$def_Strict(RTValue predicate, RTValue listTail, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Span.$instance.f2S(predicate, listTail.evaluate($ec), $ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.span
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue predicate = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(predicate, predicate = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.span
	 */
	public final RTValue f2L(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(predicate, predicate = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.span
	 */
	public final RTValue f2S(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {Span.i_Nil, Span.i_Nil});
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue listHead = $case1.get_head();
				RTValue listTail = $case1.get_tail();

				if (predicate.f1L(listHead, $ec).evaluate($ec).getBooleanValue()) {
					RTValue letVar_spanListTail = 
						Span.spanListTail$5$def_Lazy(predicate, listTail, $ec);

					return 
						RTRecordValue.makeTupleRecord(
							new RTValue[] {new TYPE_List.CAL_Cons(listHead, new RTRecordSelection.Ordinal(letVar_spanListTail, 1)), new RTRecordSelection.Ordinal(letVar_spanListTail, 2)});
				} else {
					return 
						RTRecordValue.makeTupleRecord(
							new RTValue[] {Span.i_Nil, list.getValue()});
				}
			}

			default: {
				return badSwitchIndex(Span.Cal_Collections_List_span_734_5);
			}
		}
	}

}
