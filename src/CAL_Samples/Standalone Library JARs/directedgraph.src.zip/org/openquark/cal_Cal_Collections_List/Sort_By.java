package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Map;

public final class Sort_By extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Sort_By $instance = new Sort_By();

	private Sort_By() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "sortBy";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.sortBy";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue comparisonFunction = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(comparisonFunction, comparisonFunction = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy
	 */
	public final RTValue f2L(RTValue comparisonFunction, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(comparisonFunction, comparisonFunction = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.sortBy
	 */
	public final RTValue f2S(RTValue comparisonFunction, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Sort_By__sort_Helper__3.RTAppS(
				Sort_By__sort_Helper__3.$instance, 
				comparisonFunction, 
				Map.$instance.f2S(
					List1.$instance, 
					list.getValue(), 
					$ec).evaluate(
					$ec));
	}

}
