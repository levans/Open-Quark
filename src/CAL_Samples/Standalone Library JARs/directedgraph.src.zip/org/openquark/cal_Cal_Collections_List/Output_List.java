package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Output_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Output_List $instance = new Output_List();

	private Output_List() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "outputList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.outputList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.outputList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $dictvarCal_Core_Prelude_Outputable_14 = 
			$rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Outputable_14, 
					$dictvarCal_Core_Prelude_Outputable_14 = null), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.List.outputList
	 */
	public final RTValue f1L(RTValue $dictvarCal_Core_Prelude_Outputable_14, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Outputable_14, 
					$dictvarCal_Core_Prelude_Outputable_14 = null), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.List.outputList
	 */
	public final RTValue f1S(RTValue $dictvarCal_Core_Prelude_Outputable_14, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new RTPartialApp._2._1(
				org.openquark.cal_Cal_Core_Prelude.Output_List.$instance, 
				$dictvarCal_Core_Prelude_Outputable_14);
	}

}
