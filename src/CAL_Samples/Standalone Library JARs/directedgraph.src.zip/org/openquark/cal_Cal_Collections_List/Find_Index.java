package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Find_Index extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Find_Index $instance = new Find_Index();

	private Find_Index() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "findIndex";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.findIndex";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.findIndex
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue predicate = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(predicate, predicate = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.findIndex
	 */
	public final RTValue f2L(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(predicate, predicate = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.findIndex
	 */
	public final RTValue f2S(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Find_Index__find_Index_Helper__3.RTAppS(
				Find_Index__find_Index_Helper__3.$instance, 
				predicate, 
				0, 
				list.getValue());
	}

}
