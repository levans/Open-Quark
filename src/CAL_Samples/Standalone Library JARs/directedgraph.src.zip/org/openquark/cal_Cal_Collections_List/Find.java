package org.openquark.cal_Cal_Collections_List;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;
import org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe;

public final class Find extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Find $instance = new Find();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_List_find_1634_5 = 
		new ErrorInfo("Cal.Collections.List", "find", 1634, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Maybe.CAL_Nothing i_Nothing = 
		TYPE_Maybe.CAL_Nothing.make();

	private Find() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.List";
	}

	public final java.lang.String getUnqualifiedName() {
		return "find";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.List.find";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.List.find
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue predicate = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(predicate, predicate = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.List.find
	 */
	public final RTValue f2L(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(predicate, predicate = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.List.find
	 */
	public final RTValue f2S(RTValue predicate, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return Find.i_Nothing;
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listHead = $case1.get_head();
					RTValue listTail = $case1.get_tail();

					if (predicate.f1L(listHead, $ec).evaluate(
						$ec).getBooleanValue()) {
						return new TYPE_Maybe.CAL_Just(listHead);
					} else {
						list = listTail.evaluate($ec);
						continue TRLoop;
					}
				}

				default: {
					return badSwitchIndex(Find.Cal_Collections_List_find_1634_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Find function;

		private RTValue find$predicate$1;

		private RTValue find$list$2;

		public RTAppS(Find $function, RTValue $find$predicate$1, RTValue $find$list$2) {
			assert (
				(($function != null) && ($find$predicate$1 != null)) && 
				($find$list$2 != null)) : (badConsArgMsg());
			function = $function;
			find$predicate$1 = $find$predicate$1;
			find$list$2 = $find$list$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(
							find$predicate$1, 
							find$predicate$1 = null), 
						RTValue.lastRef(find$list$2, find$list$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			find$predicate$1 = null;
			find$list$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return find$predicate$1;
				}

				case 1: {
					return find$list$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
