package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class _dict___Num___Int extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _dict___Num___Int $instance = new _dict___Num___Int();

	private _dict___Num___Int() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$dictCal.Core.Prelude.Num#Cal.Core.Prelude.Int";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.$dictCal.Core.Prelude.Num#Cal.Core.Prelude.Int";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Num#Cal.Core.Prelude.Int
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $i$L = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S($i$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Num#Cal.Core.Prelude.Int
	 */
	public final RTValue f1L(RTValue $i$L, RTExecutionContext $ec) throws CALExecutorException {
		return f1S($i$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Num#Cal.Core.Prelude.Int
	 */
	public final RTValue f1S(int $i, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		switch ($i) {

			case 0: {
				return _dict___Eq___Int.$instance;
			}

			case 1: {
				return _dict___Ord___Int.$instance;
			}

			case 2: {
				return Negate_Int.$instance;
			}

			case 3: {
				return Add_Int.$instance;
			}

			case 4: {
				return Subtract_Int.$instance;
			}

			case 5: {
				return Multiply_Int.$instance;
			}

			case 6: {
				return Divide_Int.$instance;
			}

			case 7: {
				return Remainder_Int.$instance;
			}

			case 8: {
				return Abs_Int.$instance;
			}

			case 9: {
				return Signum_Int.$instance;
			}

			case 10: {
				return Byte_To_Int.$instance;
			}

			case 11: {
				return Short_To_Int.$instance;
			}

			case 12: {
				return Int_To_Int.$instance;
			}

			case 13: {
				return Long_To_Int.$instance;
			}

			case 14: {
				return Float_To_Int.$instance;
			}

			case 15: {
				return Double_To_Int.$instance;
			}

			case 16: {
				return Integer_To_Int.$instance;
			}

			case 17: {
				return Decimal_To_Int.$instance;
			}

			case 18: {
				return Int_To_Byte.$instance;
			}

			case 19: {
				return Int_To_Short.$instance;
			}

			case 20: {
				return Int_To_Int.$instance;
			}

			case 21: {
				return Int_To_Long.$instance;
			}

			case 22: {
				return Int_To_Float.$instance;
			}

			case 23: {
				return Int_To_Double.$instance;
			}

			case 24: {
				return Int_To_Integer.$instance;
			}

			case 25: {
				return Int_To_Decimal.$instance;
			}

			default: {
				return unhandledSwitchIndexForIntPattern(null);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final _dict___Num___Int function;

		private int $i;

		public RTAppS(_dict___Num___Int $function, int $$i) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			$i = $$i;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f1S($i, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 1;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make($i);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 1)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
