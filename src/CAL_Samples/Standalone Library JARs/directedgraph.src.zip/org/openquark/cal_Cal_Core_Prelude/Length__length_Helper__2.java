package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Length__length_Helper__2 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Length__length_Helper__2 $instance = 
		new Length__length_Helper__2();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_length_3222_13 = 
		new ErrorInfo("Cal.Core.Prelude", "length", 3222, 13);

	private Length__length_Helper__2() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "length$lengthHelper$2";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.length$lengthHelper$2";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.length$lengthHelper$2
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue acc$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				acc$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.length$lengthHelper$2
	 */
	public final RTValue f2L(RTValue acc$L, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				acc$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.length$lengthHelper$2
	 */
	public final RTValue f2S(int acc, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return RTData.CAL_Int.make(acc);
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listTail = $case1.get_tail();

					acc = (acc + 1);
					list = listTail.evaluate($ec);
					continue TRLoop;
				}

				default: {
					return 
						badSwitchIndex(
							Length__length_Helper__2.Cal_Core_Prelude_length_3222_13);
				}
			}
		}
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.length$lengthHelper$2
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed2S(int acc, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return acc;
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listTail = $case1.get_tail();

					acc = (acc + 1);
					list = listTail.evaluate($ec);
					continue TRLoop;
				}

				default: {
					return 
						badSwitchIndex_int(
							Length__length_Helper__2.Cal_Core_Prelude_length_3222_13);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Length__length_Helper__2 function;

		private int length$acc$3;

		private RTValue length$list$4;

		public RTAppS(Length__length_Helper__2 $function, int $length$acc$3, RTValue $length$list$4) {
			assert (($function != null) && ($length$list$4 != null)) : (badConsArgMsg());
			function = $function;
			length$acc$3 = $length$acc$3;
			length$list$4 = $length$list$4;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						length$acc$3, 
						RTValue.lastRef(length$list$4, length$list$4 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			length$list$4 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(length$acc$3);
				}

				case 1: {
					return length$list$4;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
