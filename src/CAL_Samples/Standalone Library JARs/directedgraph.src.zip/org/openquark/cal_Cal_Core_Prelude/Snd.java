package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Snd extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Snd $instance = new Snd();

	private Snd() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "snd";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.snd";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.snd
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue pair = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(pair.evaluate($ec), pair = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.snd
	 */
	public final RTValue f1L(RTValue pair, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(pair.evaluate($ec), pair = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.snd
	 */
	public final RTValue f1S(RTValue pair, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(((RTRecordValue)(java.lang.Object)
				pair.getValue())).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

}
