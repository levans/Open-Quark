package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Append_String extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Append_String $instance = new Append_String();

	private Append_String() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "appendString";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.appendString";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.appendString
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $x1$L = $rootNode.getArgValue();
		RTValue $x0$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				$x0$L.evaluate($ec).getStringValue(), 
				$x1$L.evaluate($ec).getStringValue(), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.appendString
	 */
	public final RTValue f2L(RTValue $x0$L, RTValue $x1$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				$x0$L.evaluate($ec).getStringValue(), 
				$x1$L.evaluate($ec).getStringValue(), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.appendString
	 */
	public final RTValue f2S(java.lang.String $x0, java.lang.String $x1, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_String.make($x0.concat($x1));
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.appendString
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.String fUnboxed2S(java.lang.String $x0, java.lang.String $x1, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return $x0.concat($x1);
	}

	public static final class RTAppS extends RTFullApp {
		private final Append_String function;

		private java.lang.String $x0;

		private java.lang.String $x1;

		public RTAppS(Append_String $function, java.lang.String $$x0, java.lang.String $$x1) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			$x0 = $$x0;
			$x1 = $$x1;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f2S($x0, $x1, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_String.make($x0);
				}

				case 1: {
					return RTData.CAL_String.make($x1);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
