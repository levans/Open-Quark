package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class _dict___Eq___Int extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _dict___Eq___Int $instance = new _dict___Eq___Int();

	private _dict___Eq___Int() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$dictCal.Core.Prelude.Eq#Cal.Core.Prelude.Int";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.$dictCal.Core.Prelude.Eq#Cal.Core.Prelude.Int";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Eq#Cal.Core.Prelude.Int
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $i$L = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S($i$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Eq#Cal.Core.Prelude.Int
	 */
	public final RTValue f1L(RTValue $i$L, RTExecutionContext $ec) throws CALExecutorException {
		return f1S($i$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Eq#Cal.Core.Prelude.Int
	 */
	public final RTValue f1S(int $i, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		switch ($i) {

			case 0: {
				return Equals_Int.$instance;
			}

			case 1: {
				return Not_Equals_Int.$instance;
			}

			default: {
				return unhandledSwitchIndexForIntPattern(null);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final _dict___Eq___Int function;

		private int $i;

		public RTAppS(_dict___Eq___Int $function, int $$i) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			$i = $$i;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f1S($i, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 1;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make($i);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 1)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
