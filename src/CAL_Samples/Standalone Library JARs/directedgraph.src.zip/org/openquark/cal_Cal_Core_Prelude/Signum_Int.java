package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Signum_Int extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	private static final RTData.CAL_Int $L2_Int_1 = RTData.CAL_Int.make(1);

	private static final RTData.CAL_Int $L3_Int__1 = RTData.CAL_Int.make(-1);

	/**
	 * Singleton instance of this class.
	 */
	public static final Signum_Int $instance = new Signum_Int();

	private Signum_Int() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "signumInt";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.signumInt";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.signumInt
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue x$L = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(x$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.signumInt
	 */
	public final RTValue f1L(RTValue x$L, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(x$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.signumInt
	 */
	public final RTValue f1S(int x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (x > 0) {
			return Signum_Int.$L2_Int_1;
		} else {
			if (x < 0) {
				return Signum_Int.$L3_Int__1;
			} else {
				return Signum_Int.$L1_Int_0;
			}
		}
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.signumInt
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed1S(int x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (x > 0) {
			return 1;
		} else {
			if (x < 0) {
				return -1;
			} else {
				return 0;
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Signum_Int function;

		private int signumInt$x$1;

		public RTAppS(Signum_Int $function, int $signumInt$x$1) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			signumInt$x$1 = $signumInt$x$1;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f1S(signumInt$x$1, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 1;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(signumInt$x$1);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 1)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
