package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Compare_Int extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	private static final RTData.CAL_Int $L2_Int_1 = RTData.CAL_Int.make(1);

	private static final RTData.CAL_Int $L3_Int_2 = RTData.CAL_Int.make(2);

	/**
	 * Singleton instance of this class.
	 */
	public static final Compare_Int $instance = new Compare_Int();

	private Compare_Int() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "compareInt";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.compareInt";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.compareInt
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue y$L = $rootNode.getArgValue();
		RTValue x$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				x$L.evaluate($ec).getOrdinalValue(), 
				y$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.compareInt
	 */
	public final RTValue f2L(RTValue x$L, RTValue y$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				x$L.evaluate($ec).getOrdinalValue(), 
				y$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.compareInt
	 */
	public final RTValue f2S(int x, int y, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (x < y) {
			return Compare_Int.$L1_Int_0;
		} else {
			if (x == y) {
				return Compare_Int.$L2_Int_1;
			} else {
				return Compare_Int.$L3_Int_2;
			}
		}
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.compareInt
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed2S(int x, int y, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (x < y) {
			return 0;
		} else {
			if (x == y) {
				return 1;
			} else {
				return 2;
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Compare_Int function;

		private int compareInt$x$1;

		private int compareInt$y$2;

		public RTAppS(Compare_Int $function, int $compareInt$x$1, int $compareInt$y$2) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			compareInt$x$1 = $compareInt$x$1;
			compareInt$y$2 = $compareInt$y$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f2S(compareInt$x$1, compareInt$y$2, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(compareInt$x$1);
				}

				case 1: {
					return RTData.CAL_Int.make(compareInt$y$2);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
