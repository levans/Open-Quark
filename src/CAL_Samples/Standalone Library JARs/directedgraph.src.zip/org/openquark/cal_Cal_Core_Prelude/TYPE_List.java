package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTDataConsFieldSelection;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public abstract class TYPE_List extends RTCons {
	protected TYPE_List() {
	}

	public RTValue get_head() {
		return badFieldAccessor("_head");
	}

	public RTValue get_tail() {
		return badFieldAccessor("_tail");
	}

	protected final java.lang.String getDCNameByOrdinal(int dcOrdinal) {
		switch (dcOrdinal) {

			case 0: {
				return "Nil";
			}

			case 1: {
				return "Cons";
			}

		}
		return 
			((java.lang.String)(java.lang.Object)
				RTValue.badValue_Object(
					null, 
					"Invalid DC ordinal in getDCNameByOrdinal() for org.openquark.cal_Cal_Core_Prelude.TYPE_List"));
	}

	public static final class CAL_Nil extends TYPE_List {
		public static final CAL_Nil $instance = new CAL_Nil();

		private CAL_Nil() {
		}

		public final int getArity() {
			return 0;
		}

		public int getOrdinalValue() {
			return 0;
		}

		public static final CAL_Nil make() {
			return CAL_Nil.$instance;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Core.Prelude";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Nil";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Core.Prelude.Nil";
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Core.Prelude.Nil";
			}

		}
	}
	public static final class CAL_Cons extends TYPE_List {
		private RTValue _head;

		private RTValue _tail;

		public static final CAL_Cons $instance = new CAL_Cons();

		private CAL_Cons() {
		}

		public CAL_Cons(RTValue member0, RTValue member1) {
			assert ((member0 != null) && (member1 != null)) : ("Invalid constructor argument for Cal.Core.Prelude.Cons");
			_head = member0;
			_tail = member1;
		}

		public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
			// Arguments
			final RTValue $arg1 = $rootNode.getArgValue();
			final RTValue $arg0 = $rootNode.prevArg().getArgValue();

			return new CAL_Cons($arg0, $arg1);
		}

		public final RTValue f2L(RTValue member0, RTValue member1, RTExecutionContext $ec) throws CALExecutorException {
			return new CAL_Cons(member0, member1);
		}

		public final int getArity() {
			return 2;
		}

		public int getOrdinalValue() {
			return 1;
		}

		public static final CAL_Cons make() {
			return CAL_Cons.$instance;
		}

		public final RTValue get_head() {
			RTValue _head$;

			if (((java.lang.Object)(_head$ = _head)) instanceof RTResultFunction) {
				return _head = _head$.getValue();
			}
			return _head$;
		}

		public final RTValue get_tail() {
			RTValue _tail$;

			if (((java.lang.Object)(_tail$ = _tail)) instanceof RTResultFunction) {
				return _tail = _tail$.getValue();
			}
			return _tail$;
		}

		public final RTValue buildDeepSeq(RTSupercombinator deepSeq, RTValue rhs) throws CALExecutorException {
			return deepSeq.apply(get_head(), deepSeq.apply(get_tail(), rhs));
		}

		public final RTValue getFieldByIndex(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return get_head();
				}

				case 1: {
					return get_tail();
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return null;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Core.Prelude";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Cons";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Core.Prelude.Cons";
		}

		public final boolean isFunctionSingleton() {
			return this == CAL_Cons.$instance;
		}

		public final CalValue debug_getChild(int childN) {
			if (isFunctionSingleton()) {
				throw new java.lang.IndexOutOfBoundsException();
			}
			switch (childN) {

				case 0: {
					return _head;
				}

				case 1: {
					return _tail;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

					case 0: {
						return "head";
					}

					case 1: {
						return "tail";
					}

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Core.Prelude.Cons";
			}

		}
	}
}
