package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Fold_Right extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Fold_Right $instance = new Fold_Right();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_foldRight_3270_5 = 
		new ErrorInfo("Cal.Core.Prelude", "foldRight", 3270, 5);

	private Fold_Right() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "foldRight";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.foldRight";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.foldRight
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue initialValue = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue foldFunction = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(foldFunction, foldFunction = null), 
				RTValue.lastRef(initialValue, initialValue = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.foldRight
	 */
	public final RTValue f3L(RTValue foldFunction, RTValue initialValue, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(foldFunction, foldFunction = null), 
				RTValue.lastRef(initialValue, initialValue = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.foldRight
	 */
	public final RTValue f3S(RTValue foldFunction, RTValue initialValue, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return initialValue;
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue listHead = $case1.get_head();
				RTValue listTail = $case1.get_tail();

				return 
					foldFunction.apply(
						listHead, 
						new RTFullApp.General._3._L(
							Fold_Right.$instance, 
							foldFunction, 
							initialValue, 
							listTail));
			}

			default: {
				return 
					badSwitchIndex(Fold_Right.Cal_Core_Prelude_foldRight_3270_5);
			}
		}
	}

}
