package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class From_Just extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final From_Just $instance = new From_Just();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_fromJust_3474_5 = 
		new ErrorInfo("Cal.Core.Prelude", "fromJust", 3474, 5);

	private static final ErrorInfo Cal_Core_Prelude_fromJust_3476_16 = 
		new ErrorInfo("Cal.Core.Prelude", "fromJust", 3476, 16);

	private From_Just() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "fromJust";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.fromJust";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.fromJust
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue maybeValue = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				RTValue.lastRef(maybeValue.evaluate($ec), maybeValue = null), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.fromJust
	 */
	public final RTValue f1L(RTValue maybeValue, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				RTValue.lastRef(maybeValue.evaluate($ec), maybeValue = null), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.fromJust
	 */
	public final RTValue f1S(RTValue maybeValue, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)maybeValue.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return 
					RTError.$instance.f2S(
						RTData.CAL_Opaque.make(
							From_Just.Cal_Core_Prelude_fromJust_3476_16), 
						"Nothing.", 
						$ec);
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue value = $case1.get_value();

				return value;
			}

			default: {
				return 
					badSwitchIndex(From_Just.Cal_Core_Prelude_fromJust_3474_5);
			}
		}
	}

}
