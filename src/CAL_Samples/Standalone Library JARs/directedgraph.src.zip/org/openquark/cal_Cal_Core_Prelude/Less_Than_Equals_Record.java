package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTCompareRecord;
import org.openquark.cal.runtime.CALExecutorException;

public final class Less_Than_Equals_Record extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Less_Than_Equals_Record $instance = 
		new Less_Than_Equals_Record();

	private Less_Than_Equals_Record() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "lessThanEqualsRecord";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.lessThanEqualsRecord";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.lessThanEqualsRecord
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue r1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_7 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_7, 
					$dictvarCal_Core_Prelude_Ord_7 = null), 
				RTValue.lastRef(r1.evaluate($ec), r1 = null), 
				RTValue.lastRef(r2.evaluate($ec), r2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.lessThanEqualsRecord
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_7, RTValue r1, RTValue r2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_7, 
					$dictvarCal_Core_Prelude_Ord_7 = null), 
				RTValue.lastRef(r1.evaluate($ec), r1 = null), 
				RTValue.lastRef(r2.evaluate($ec), r2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.lessThanEqualsRecord
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_7, RTValue r1, RTValue r2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(
				RTCompareRecord.$instance.fUnboxed3S(
					$dictvarCal_Core_Prelude_Ord_7.evaluate($ec), 
					r1.getValue(), 
					r2.getValue(), 
					$ec) != 
				2);
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.lessThanEqualsRecord
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Ord_7, RTValue r1, RTValue r2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTCompareRecord.$instance.fUnboxed3S(
				$dictvarCal_Core_Prelude_Ord_7.evaluate($ec), 
				r1.getValue(), 
				r2.getValue(), 
				$ec) != 
			2;
	}

}
