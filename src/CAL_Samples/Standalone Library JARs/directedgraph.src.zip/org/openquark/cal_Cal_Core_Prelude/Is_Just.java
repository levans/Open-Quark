package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Is_Just extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Is_Just $instance = new Is_Just();

	private Is_Just() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "isJust";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.isJust";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.isJust
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue maybeValue = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f1S(
				RTValue.lastRef(maybeValue.evaluate($ec), maybeValue = null), 
				$ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.isJust
	 */
	public final RTValue f1L(RTValue maybeValue, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f1S(
				RTValue.lastRef(maybeValue.evaluate($ec), maybeValue = null), 
				$ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.isJust
	 */
	public final RTValue f1S(RTValue maybeValue, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(
				maybeValue.getValue().getOrdinalValue() == 1);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.isJust
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed1S(RTValue maybeValue, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return maybeValue.getValue().getOrdinalValue() == 1;
	}

}
