package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Const__ extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Const__ $instance = new Const__();

	private Const__() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "const";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.const";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.const
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue valueToIgnore = $rootNode.getArgValue();
		RTValue valueToReturn = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					valueToReturn.evaluate($ec), 
					valueToReturn = null), 
				RTValue.lastRef(valueToIgnore, valueToIgnore = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.const
	 */
	public final RTValue f2L(RTValue valueToReturn, RTValue valueToIgnore, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					valueToReturn.evaluate($ec), 
					valueToReturn = null), 
				RTValue.lastRef(valueToIgnore, valueToIgnore = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.const
	 */
	public final RTValue f2S(RTValue valueToReturn, RTValue valueToIgnore, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return valueToReturn.getValue();
	}

}
