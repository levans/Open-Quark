package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class _equals___List extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	private static final RTData.CAL_Boolean $L2_Boolean_false = 
		RTData.CAL_Boolean.make(false);

	/**
	 * Singleton instance of this class.
	 */
	public static final _equals___List $instance = new _equals___List();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_$equals$List_144_14 = 
		new ErrorInfo("Cal.Core.Prelude", "$equals$List", 144, 14);

	private _equals___List() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$equals$List";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.$equals$List";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$equals$List
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue y = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_54 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_54, 
					$dictvarCal_Core_Prelude_Eq_54 = null), 
				RTValue.lastRef(x.evaluate($ec), x = null), 
				RTValue.lastRef(y.evaluate($ec), y = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$equals$List
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_54, RTValue x, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_54, 
					$dictvarCal_Core_Prelude_Eq_54 = null), 
				RTValue.lastRef(x.evaluate($ec), x = null), 
				RTValue.lastRef(y.evaluate($ec), y = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$equals$List
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_54, RTValue x, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)x.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return 
						RTData.CAL_Boolean.make(
							y.getValue().getOrdinalValue() == 0);
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue head1 = $case1.get_head();
					RTValue tail1 = $case1.get_tail();

					TYPE_List $case3;

					switch (($case3 = (((TYPE_List)(java.lang.Object)y.getValue()))).getOrdinalValue()) {

						case 1: {
							// Cal.Core.Prelude.Cons
							// Decompose data type to access members.
							RTValue head2 = $case3.get_head();
							RTValue tail2 = $case3.get_tail();

							if ((new RTOApp3(
								$dictvarCal_Core_Prelude_Eq_54, 
								_equals___List.$L1_Int_0, 
								head1, 
								head2)).evaluate(
								$ec).getBooleanValue()) {
								x = tail1.evaluate($ec);
								y = tail2.evaluate($ec);
								continue TRLoop;
							} else {
								return _equals___List.$L2_Boolean_false;
							}
						}

						default: {
							return RTData.CAL_Boolean.make(false);
						}
					}
				}

				default: {
					return 
						badSwitchIndex(
							_equals___List.Cal_Core_Prelude_$equals$List_144_14);
				}
			}
		}
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.$equals$List
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Eq_54, RTValue x, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)x.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return y.getValue().getOrdinalValue() == 0;
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue head1 = $case1.get_head();
					RTValue tail1 = $case1.get_tail();

					TYPE_List $case3;

					switch (($case3 = (((TYPE_List)(java.lang.Object)y.getValue()))).getOrdinalValue()) {

						case 1: {
							// Cal.Core.Prelude.Cons
							// Decompose data type to access members.
							RTValue head2 = $case3.get_head();
							RTValue tail2 = $case3.get_tail();

							if ((new RTOApp3(
								$dictvarCal_Core_Prelude_Eq_54, 
								_equals___List.$L1_Int_0, 
								head1, 
								head2)).evaluate(
								$ec).getBooleanValue()) {
								x = tail1.evaluate($ec);
								y = tail2.evaluate($ec);
								continue TRLoop;
							} else {
								return false;
							}
						}

						default: {
							return false;
						}
					}
				}

				default: {
					return 
						badSwitchIndex_boolean(
							_equals___List.Cal_Core_Prelude_$equals$List_144_14);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final _equals___List function;

		private RTValue $dictvarCal_Core_Prelude_Eq_54;

		private RTValue $equals$List$x$1;

		private RTValue $equals$List$y$2;

		public RTAppS(_equals___List $function, RTValue $$dictvarCal_Core_Prelude_Eq_54, RTValue $$equals$List$x$1, RTValue $$equals$List$y$2) {
			assert (
				((($function != null) && 
				($$dictvarCal_Core_Prelude_Eq_54 != null)) && 
				($$equals$List$x$1 != null)) && 
				($$equals$List$y$2 != null)) : (badConsArgMsg());
			function = $function;
			$dictvarCal_Core_Prelude_Eq_54 = $$dictvarCal_Core_Prelude_Eq_54;
			$equals$List$x$1 = $$equals$List$x$1;
			$equals$List$y$2 = $$equals$List$y$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							$dictvarCal_Core_Prelude_Eq_54, 
							$dictvarCal_Core_Prelude_Eq_54 = null), 
						RTValue.lastRef(
							$equals$List$x$1, 
							$equals$List$x$1 = null), 
						RTValue.lastRef(
							$equals$List$y$2, 
							$equals$List$y$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			$dictvarCal_Core_Prelude_Eq_54 = null;
			$equals$List$x$1 = null;
			$equals$List$y$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return $dictvarCal_Core_Prelude_Eq_54;
				}

				case 1: {
					return $equals$List$x$1;
				}

				case 2: {
					return $equals$List$y$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
