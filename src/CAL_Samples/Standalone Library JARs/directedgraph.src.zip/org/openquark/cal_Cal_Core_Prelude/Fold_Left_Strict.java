package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Fold_Left_Strict extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Fold_Left_Strict $instance = new Fold_Left_Strict();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_foldLeftStrict_3248_5 = 
		new ErrorInfo("Cal.Core.Prelude", "foldLeftStrict", 3248, 5);

	private Fold_Left_Strict() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "foldLeftStrict";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.foldLeftStrict";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.foldLeftStrict
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue initialValue = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue foldFunction = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(foldFunction, foldFunction = null), 
				RTValue.lastRef(
					initialValue.evaluate($ec), 
					initialValue = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.foldLeftStrict
	 */
	public final RTValue f3L(RTValue foldFunction, RTValue initialValue, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(foldFunction, foldFunction = null), 
				RTValue.lastRef(
					initialValue.evaluate($ec), 
					initialValue = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.foldLeftStrict
	 */
	public final RTValue f3S(RTValue foldFunction, RTValue initialValue, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return initialValue.getValue();
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue listHead = $case1.get_head();
					RTValue listTail = $case1.get_tail();

						initialValue = 
						foldFunction.f2L(
							initialValue.getValue(), 
							listHead, 
							$ec).evaluate(
							$ec);
					list = listTail.evaluate($ec);
					continue TRLoop;
				}

				default: {
					return 
						badSwitchIndex(
							Fold_Left_Strict.Cal_Core_Prelude_foldLeftStrict_3248_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Fold_Left_Strict function;

		private RTValue foldLeftStrict$foldFunction$1;

		private RTValue foldLeftStrict$initialValue$2;

		private RTValue foldLeftStrict$list$3;

		public RTAppS(Fold_Left_Strict $function, RTValue $foldLeftStrict$foldFunction$1, RTValue $foldLeftStrict$initialValue$2, RTValue $foldLeftStrict$list$3) {
			assert (
				((($function != null) && 
				($foldLeftStrict$foldFunction$1 != null)) && 
				($foldLeftStrict$initialValue$2 != null)) && 
				($foldLeftStrict$list$3 != null)) : (badConsArgMsg());
			function = $function;
			foldLeftStrict$foldFunction$1 = $foldLeftStrict$foldFunction$1;
			foldLeftStrict$initialValue$2 = $foldLeftStrict$initialValue$2;
			foldLeftStrict$list$3 = $foldLeftStrict$list$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							foldLeftStrict$foldFunction$1, 
							foldLeftStrict$foldFunction$1 = null), 
						RTValue.lastRef(
							foldLeftStrict$initialValue$2, 
							foldLeftStrict$initialValue$2 = null), 
						RTValue.lastRef(
							foldLeftStrict$list$3, 
							foldLeftStrict$list$3 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			foldLeftStrict$foldFunction$1 = null;
			foldLeftStrict$initialValue$2 = null;
			foldLeftStrict$list$3 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return foldLeftStrict$foldFunction$1;
				}

				case 1: {
					return foldLeftStrict$initialValue$2;
				}

				case 2: {
					return foldLeftStrict$list$3;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
