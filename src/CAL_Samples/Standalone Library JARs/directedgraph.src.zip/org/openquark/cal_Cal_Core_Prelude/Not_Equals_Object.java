package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Not_Equals_Object extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Not_Equals_Object $instance = new Not_Equals_Object();

	private Not_Equals_Object() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "notEqualsObject";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.notEqualsObject";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.notEqualsObject
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue y$L = $rootNode.getArgValue();
		RTValue x$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				x$L.evaluate($ec).getOpaqueValue(), 
				y$L.evaluate($ec).getOpaqueValue(), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.notEqualsObject
	 */
	public final RTValue f2L(RTValue x$L, RTValue y$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				x$L.evaluate($ec).getOpaqueValue(), 
				y$L.evaluate($ec).getOpaqueValue(), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.notEqualsObject
	 */
	public final RTValue f2S(java.lang.Object x, java.lang.Object y, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Boolean.make(!x.equals(y));
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.notEqualsObject
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed2S(java.lang.Object x, java.lang.Object y, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return !x.equals(y);
	}

	public static final class RTAppS extends RTFullApp {
		private final Not_Equals_Object function;

		private java.lang.Object notEqualsObject$x$1;

		private java.lang.Object notEqualsObject$y$2;

		public RTAppS(Not_Equals_Object $function, java.lang.Object $notEqualsObject$x$1, java.lang.Object $notEqualsObject$y$2) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			notEqualsObject$x$1 = $notEqualsObject$x$1;
			notEqualsObject$y$2 = $notEqualsObject$y$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(notEqualsObject$x$1, notEqualsObject$y$2, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Opaque.make(notEqualsObject$x$1);
				}

				case 1: {
					return RTData.CAL_Opaque.make(notEqualsObject$y$2);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
