package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Output_J_Object extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Output_J_Object $instance = new Output_J_Object();

	private Output_J_Object() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "outputJObject";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.outputJObject";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputJObject
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue x$L = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(x$L.evaluate($ec).getOpaqueValue(), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputJObject
	 */
	public final RTValue f1L(RTValue x$L, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(x$L.evaluate($ec).getOpaqueValue(), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputJObject
	 */
	public final RTValue f1S(java.lang.Object x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Opaque.make(x);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.outputJObject
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.Object fUnboxed1S(java.lang.Object x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return x;
	}

	public static final class RTAppS extends RTFullApp {
		private final Output_J_Object function;

		private java.lang.Object outputJObject$x$1;

		public RTAppS(Output_J_Object $function, java.lang.Object $outputJObject$x$1) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			outputJObject$x$1 = $outputJObject$x$1;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f1S(outputJObject$x$1, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 1;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Opaque.make(outputJObject$x$1);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 1)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
