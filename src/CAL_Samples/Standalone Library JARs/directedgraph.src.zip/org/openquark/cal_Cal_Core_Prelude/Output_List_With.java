package org.openquark.cal_Cal_Core_Prelude;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal.util.FixedSizeList;

public final class Output_List_With extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Output_List_With $instance = new Output_List_With();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4169_5 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4169, 5);

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4173_5 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4173, 5);

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4177_5 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4177, 5);

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4181_5 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4181, 5);

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4185_5 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4185, 5);

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4189_5 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4189, 5);

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4193_5 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4193, 5);

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4197_5 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4197, 5);

	private Output_List_With() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "outputListWith";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.outputListWith";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputListWith
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue f = $rootNode.getArgValue();
		RTValue list = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(list.evaluate($ec), list = null), 
				RTValue.lastRef(f, f = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputListWith
	 */
	public final RTValue f2L(RTValue list, RTValue f, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(list.evaluate($ec), list = null), 
				RTValue.lastRef(f, f = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputListWith
	 */
	public final RTValue f2S(RTValue list, RTValue f, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return RTData.CAL_Opaque.make(Collections.EMPTY_LIST);
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue x0 = $case1.get_head();
				RTValue list0 = $case1.get_tail();

				TYPE_List $case2;

				switch (($case2 = (((TYPE_List)(java.lang.Object)list0.evaluate($ec)))).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.Nil
						return 
							RTData.CAL_Opaque.make(
								FixedSizeList.make(
									f.f1L(x0, $ec).evaluate(
										$ec).getOpaqueValue()));
					}

					case 1: {
						// Cal.Core.Prelude.Cons
						// Decompose data type to access members.
						RTValue x1 = $case2.get_head();
						RTValue list1 = $case2.get_tail();

						TYPE_List $case3;

						switch (($case3 = (((TYPE_List)(java.lang.Object)list1.evaluate($ec)))).getOrdinalValue()) {

							case 0: {
								// Cal.Core.Prelude.Nil
								return 
									RTData.CAL_Opaque.make(
										FixedSizeList.make(
											f.f1L(x0, $ec).evaluate(
												$ec).getOpaqueValue(), 
											f.f1L(x1, $ec).evaluate(
												$ec).getOpaqueValue()));
							}

							case 1: {
								// Cal.Core.Prelude.Cons
								// Decompose data type to access members.
								RTValue x2 = $case3.get_head();
								RTValue list2 = $case3.get_tail();

								TYPE_List $case4;

								switch (($case4 = (((TYPE_List)(java.lang.Object)list2.evaluate($ec)))).getOrdinalValue()) {

									case 0: {
										// Cal.Core.Prelude.Nil
										return 
											RTData.CAL_Opaque.make(
												FixedSizeList.make(
													f.f1L(x0, $ec).evaluate(
														$ec).getOpaqueValue(), 
													f.f1L(x1, $ec).evaluate(
														$ec).getOpaqueValue(), 
													f.f1L(x2, $ec).evaluate(
														$ec).getOpaqueValue()));
									}

									case 1: {
										// Cal.Core.Prelude.Cons
										// Decompose data type to access members.
										RTValue x3 = $case4.get_head();
										RTValue list3 = 
											$case4.get_tail();

										TYPE_List $case5;

										switch (($case5 = (((TYPE_List)(java.lang.Object)list3.evaluate($ec)))).getOrdinalValue()) {

											case 0: {
												// Cal.Core.Prelude.Nil
												return 
													RTData.CAL_Opaque.make(
														FixedSizeList.make(
															f.f1L(
																x0, 
																$ec).evaluate(
																$ec).getOpaqueValue(), 
															f.f1L(
																x1, 
																$ec).evaluate(
																$ec).getOpaqueValue(), 
															f.f1L(
																x2, 
																$ec).evaluate(
																$ec).getOpaqueValue(), 
															f.f1L(
																x3, 
																$ec).evaluate(
																$ec).getOpaqueValue()));
											}

											case 1: {
												// Cal.Core.Prelude.Cons
												// Decompose data type to access members.
												RTValue x4 = 
													$case5.get_head();
												RTValue list4 = 
													$case5.get_tail();

												TYPE_List $case6;

												switch (($case6 = (((TYPE_List)(java.lang.Object)list4.evaluate($ec)))).getOrdinalValue()) {

													case 0: {
														// Cal.Core.Prelude.Nil
														return 
															RTData.CAL_Opaque.make(
																FixedSizeList.make(
																	f.f1L(
																		x0, 
																		$ec).evaluate(
																		$ec).getOpaqueValue(), 
																	f.f1L(
																		x1, 
																		$ec).evaluate(
																		$ec).getOpaqueValue(), 
																	f.f1L(
																		x2, 
																		$ec).evaluate(
																		$ec).getOpaqueValue(), 
																	f.f1L(
																		x3, 
																		$ec).evaluate(
																		$ec).getOpaqueValue(), 
																	f.f1L(
																		x4, 
																		$ec).evaluate(
																		$ec).getOpaqueValue()));
													}

													case 1: {
														// Cal.Core.Prelude.Cons
														// Decompose data type to access members.
														RTValue x5 = 
															$case6.get_head();
														RTValue list5 = 
															$case6.get_tail();

														TYPE_List $case7;

														switch (($case7 = (((TYPE_List)(java.lang.Object)list5.evaluate($ec)))).getOrdinalValue()) {

															case 0: {
																// Cal.Core.Prelude.Nil
																return 
																	RTData.CAL_Opaque.make(
																		FixedSizeList.make(
																			f.f1L(
																				x0, 
																				$ec).evaluate(
																				$ec).getOpaqueValue(), 
																			f.f1L(
																				x1, 
																				$ec).evaluate(
																				$ec).getOpaqueValue(), 
																			f.f1L(
																				x2, 
																				$ec).evaluate(
																				$ec).getOpaqueValue(), 
																			f.f1L(
																				x3, 
																				$ec).evaluate(
																				$ec).getOpaqueValue(), 
																			f.f1L(
																				x4, 
																				$ec).evaluate(
																				$ec).getOpaqueValue(), 
																			f.f1L(
																				x5, 
																				$ec).evaluate(
																				$ec).getOpaqueValue()));
															}

															case 1: {
																// Cal.Core.Prelude.Cons
																// Decompose data type to access members.
																RTValue x6 = 
																	$case7.get_head();
																RTValue list6 = 
																	$case7.get_tail();

																TYPE_List $case8;

																switch (($case8 = (((TYPE_List)(java.lang.Object)list6.evaluate($ec)))).getOrdinalValue()) {

																	case 0: {
																		// Cal.Core.Prelude.Nil
																		return 
																			RTData.CAL_Opaque.make(
																				FixedSizeList.make(
																					f.f1L(
																						x0, 
																						$ec).evaluate(
																						$ec).getOpaqueValue(), 
																					f.f1L(
																						x1, 
																						$ec).evaluate(
																						$ec).getOpaqueValue(), 
																					f.f1L(
																						x2, 
																						$ec).evaluate(
																						$ec).getOpaqueValue(), 
																					f.f1L(
																						x3, 
																						$ec).evaluate(
																						$ec).getOpaqueValue(), 
																					f.f1L(
																						x4, 
																						$ec).evaluate(
																						$ec).getOpaqueValue(), 
																					f.f1L(
																						x5, 
																						$ec).evaluate(
																						$ec).getOpaqueValue(), 
																					f.f1L(
																						x6, 
																						$ec).evaluate(
																						$ec).getOpaqueValue()));
																	}

																	case 1: {
																		// Cal.Core.Prelude.Cons
																		// Decompose data type to access members.
																		RTValue x7 = 
																			$case8.get_head();
																		RTValue list7 = 
																			$case8.get_tail();
																		List letVar_javaList$U = 
																			new ArrayList()
;

																		letVar_javaList$U.add(
																			f.f1L(
																				x0, 
																				$ec).evaluate(
																				$ec).getOpaqueValue());
																		letVar_javaList$U.add(
																			f.f1L(
																				x1, 
																				$ec).evaluate(
																				$ec).getOpaqueValue());
																		letVar_javaList$U.add(
																			f.f1L(
																				x2, 
																				$ec).evaluate(
																				$ec).getOpaqueValue());
																		letVar_javaList$U.add(
																			f.f1L(
																				x3, 
																				$ec).evaluate(
																				$ec).getOpaqueValue());
																		letVar_javaList$U.add(
																			f.f1L(
																				x4, 
																				$ec).evaluate(
																				$ec).getOpaqueValue());
																		letVar_javaList$U.add(
																			f.f1L(
																				x5, 
																				$ec).evaluate(
																				$ec).getOpaqueValue());
																		letVar_javaList$U.add(
																			f.f1L(
																				x6, 
																				$ec).evaluate(
																				$ec).getOpaqueValue());
																		letVar_javaList$U.add(
																			f.f1L(
																				x7, 
																				$ec).evaluate(
																				$ec).getOpaqueValue());
																		return 
																			new Output_List_With__output_List_With_Helper__20.RTAppS(
																				Output_List_With__output_List_With_Helper__20.$instance, 
																				list7.evaluate(
																					$ec), 
																				f, 
																				letVar_javaList$U);
																	}

																	default: {
																		return 
																			badSwitchIndex(
																				Output_List_With.Cal_Core_Prelude_outputListWith_4197_5);
																	}
																}
															}

															default: {
																return 
																	badSwitchIndex(
																		Output_List_With.Cal_Core_Prelude_outputListWith_4193_5);
															}
														}
													}

													default: {
														return 
															badSwitchIndex(
																Output_List_With.Cal_Core_Prelude_outputListWith_4189_5);
													}
												}
											}

											default: {
												return 
													badSwitchIndex(
														Output_List_With.Cal_Core_Prelude_outputListWith_4185_5);
											}
										}
									}

									default: {
										return 
											badSwitchIndex(
												Output_List_With.Cal_Core_Prelude_outputListWith_4181_5);
									}
								}
							}

							default: {
								return 
									badSwitchIndex(
										Output_List_With.Cal_Core_Prelude_outputListWith_4177_5);
							}
						}
					}

					default: {
						return 
							badSwitchIndex(
								Output_List_With.Cal_Core_Prelude_outputListWith_4173_5);
					}
				}
			}

			default: {
				return 
					badSwitchIndex(
						Output_List_With.Cal_Core_Prelude_outputListWith_4169_5);
			}
		}
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.outputListWith
	 * This version of the logic returns an unboxed value.
	 */
	public final List fUnboxed2S(RTValue list, RTValue f, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = f2S(list, f, $ec);

		list = null;
		f = null;
		return ((List)(java.lang.Object)$result.evaluate($ec).getOpaqueValue());
	}

}
