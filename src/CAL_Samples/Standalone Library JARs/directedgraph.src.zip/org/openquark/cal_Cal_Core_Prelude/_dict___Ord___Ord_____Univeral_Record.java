package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTCompareRecord;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class _dict___Ord___Ord_____Univeral_Record extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	/**
	 * Instance of this class representing CAL function $dictCal.Core.Prelude.Ord#$UniveralRecord.
	 */
	public static final _dict___Ord___Ord_____Univeral_Record $instance__dict_Cal___Core___Prelude___Ord_____Univeral_Record = 
		new _dict___Ord___Ord_____Univeral_Record(0, 2);

	/**
	 * Instance of this class representing CAL function maxRecord.
	 */
	public static final _dict___Ord___Ord_____Univeral_Record $instance_max_Record = 
		new _dict___Ord___Ord_____Univeral_Record(1, 3);

	/**
	 * Instance of this class representing CAL function minRecord.
	 */
	public static final _dict___Ord___Ord_____Univeral_Record $instance_min_Record = 
		new _dict___Ord___Ord_____Univeral_Record(2, 3);

	/**
	 * Tag field indicating which CAL function this class instance represents.
	 *     0 -> $dictCal.Core.Prelude.Ord#$UniveralRecord
	 *     1 -> maxRecord
	 *     2 -> minRecord
	 */
	private final int scTag;

	/**
	 * Field holding arity of represented function.
	 */
	private final int arity;

	private _dict___Ord___Ord_____Univeral_Record(int scIndex, int arityValue) {
		scTag = scIndex;
		arity = arityValue;
	}

	public final int getArity() {
		return arity;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		switch (scTag) {

			case 0: {
				return "$dictCal.Core.Prelude.Ord#$UniveralRecord";
			}

			case 1: {
				return "maxRecord";
			}

			case 2: {
				return "minRecord";
			}

		}
		return 
			((java.lang.String)(java.lang.Object)
				RTValue.badValue_Object(
					null, 
					"Bad index in getUnQualifiedName()"));
	}

	public final java.lang.String getQualifiedName() {
		switch (scTag) {

			case 0: {
				return 
					"Cal.Core.Prelude.$dictCal.Core.Prelude.Ord#$UniveralRecord";
			}

			case 1: {
				return "Cal.Core.Prelude.maxRecord";
			}

			case 2: {
				return "Cal.Core.Prelude.minRecord";
			}

		}
		return 
			((java.lang.String)(java.lang.Object)
				RTValue.badValue_Object(
					null, 
					"Bad index in getQualifiedName()"));
	}

	/**
	 * _dict_Cal___Core___Prelude___Ord_____Univeral_Record_f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Ord#$UniveralRecord
	 */
	public final RTValue _dict_Cal___Core___Prelude___Ord_____Univeral_Record_f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $i$L = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_0 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			_dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_0, 
					$dictvarCal_Core_Prelude_Ord_0 = null), 
				$i$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * _dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Ord#$UniveralRecord
	 */
	public final RTValue _dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2L(RTValue $dictvarCal_Core_Prelude_Ord_0, RTValue $i$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			_dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_0, 
					$dictvarCal_Core_Prelude_Ord_0 = null), 
				$i$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * _dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Ord#$UniveralRecord
	 */
	public final RTValue _dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2S(RTValue $dictvarCal_Core_Prelude_Ord_0, int $i, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		switch ($i) {

			case 0: {
				return 
					new RTPartialApp._2._1(
						_dict___Eq___Eq_____Univeral_Record.$instance, 
						$dictvarCal_Core_Prelude_Ord_0.apply(
							_dict___Ord___Ord_____Univeral_Record.$L1_Int_0));
			}

			case 1: {
				return 
					new RTPartialApp._3._1(
						Less_Than_Record.$instance, 
						$dictvarCal_Core_Prelude_Ord_0);
			}

			case 2: {
				return 
					new RTPartialApp._3._1(
						Less_Than_Equals_Record.$instance, 
						$dictvarCal_Core_Prelude_Ord_0);
			}

			case 3: {
				return 
					new RTPartialApp._3._1(
						Greater_Than_Equals_Record.$instance, 
						$dictvarCal_Core_Prelude_Ord_0);
			}

			case 4: {
				return 
					new RTPartialApp._3._1(
						Greater_Than_Record.$instance, 
						$dictvarCal_Core_Prelude_Ord_0);
			}

			case 5: {
				return 
					new RTPartialApp._3._1(
						RTCompareRecord.$instance, 
						$dictvarCal_Core_Prelude_Ord_0);
			}

			case 6: {
				return 
					new RTPartialApp._3._1(
						_dict___Ord___Ord_____Univeral_Record.$instance_max_Record, 
						$dictvarCal_Core_Prelude_Ord_0);
			}

			case 7: {
				return 
					new RTPartialApp._3._1(
						_dict___Ord___Ord_____Univeral_Record.$instance_min_Record, 
						$dictvarCal_Core_Prelude_Ord_0);
			}

			default: {
				return unhandledSwitchIndexForIntPattern(null);
			}
		}
	}

	/**
	 * max_Record_f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.maxRecord
	 */
	public final RTValue max_Record_f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue r1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_22 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			max_Record_f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_22, 
					$dictvarCal_Core_Prelude_Ord_22 = null), 
				RTValue.lastRef(r1.evaluate($ec), r1 = null), 
				RTValue.lastRef(r2.evaluate($ec), r2 = null), 
				$ec);
	}

	/**
	 * max_Record_f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.maxRecord
	 */
	public final RTValue max_Record_f3L(RTValue $dictvarCal_Core_Prelude_Ord_22, RTValue r1, RTValue r2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			max_Record_f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_22, 
					$dictvarCal_Core_Prelude_Ord_22 = null), 
				RTValue.lastRef(r1.evaluate($ec), r1 = null), 
				RTValue.lastRef(r2.evaluate($ec), r2 = null), 
				$ec);
	}

	/**
	 * max_Record_f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.maxRecord
	 */
	public final RTValue max_Record_f3S(RTValue $dictvarCal_Core_Prelude_Ord_22, RTValue r1, RTValue r2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (_dict___Ord___Ord_____Univeral_Record.$instance__dict_Cal___Core___Prelude___Ord_____Univeral_Record._dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2S(
			$dictvarCal_Core_Prelude_Ord_22, 
			2, 
			$ec).evaluate(
			$ec).f2L(
			r1.getValue(), 
			r2.getValue(), 
			$ec).evaluate(
			$ec).getBooleanValue()) {
			return r2.getValue();
		} else {
			return r1.getValue();
		}
	}

	/**
	 * min_Record_f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.minRecord
	 */
	public final RTValue min_Record_f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue r1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_68 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			min_Record_f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_68, 
					$dictvarCal_Core_Prelude_Ord_68 = null), 
				RTValue.lastRef(r1.evaluate($ec), r1 = null), 
				RTValue.lastRef(r2.evaluate($ec), r2 = null), 
				$ec);
	}

	/**
	 * min_Record_f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.minRecord
	 */
	public final RTValue min_Record_f3L(RTValue $dictvarCal_Core_Prelude_Ord_68, RTValue r1, RTValue r2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			min_Record_f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_68, 
					$dictvarCal_Core_Prelude_Ord_68 = null), 
				RTValue.lastRef(r1.evaluate($ec), r1 = null), 
				RTValue.lastRef(r2.evaluate($ec), r2 = null), 
				$ec);
	}

	/**
	 * min_Record_f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.minRecord
	 */
	public final RTValue min_Record_f3S(RTValue $dictvarCal_Core_Prelude_Ord_68, RTValue r1, RTValue r2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (_dict___Ord___Ord_____Univeral_Record.$instance__dict_Cal___Core___Prelude___Ord_____Univeral_Record._dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2S(
			$dictvarCal_Core_Prelude_Ord_68, 
			2, 
			$ec).evaluate(
			$ec).f2L(
			r1.getValue(), 
			r2.getValue(), 
			$ec).evaluate(
			$ec).getBooleanValue()) {
			return r1.getValue();
		} else {
			return r2.getValue();
		}
	}

	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		switch (scTag) {

			case 0: {
				return 
					_dict_Cal___Core___Prelude___Ord_____Univeral_Record_f(
						$rootNode, 
						$ec);
			}

			case 1: {
				return max_Record_f($rootNode, $ec);
			}

			case 2: {
				return min_Record_f($rootNode, $ec);
			}

		}
		return RTValue.badValue("Bad scTag in \'f\'.");
	}

	public final RTValue f2S(RTValue $arg0, RTValue $arg1, RTExecutionContext $ec) throws CALExecutorException {
		switch (scTag) {

		}
		return RTValue.badValue("Bad scTag in \'f\'.");
	}

	public final RTValue f2L(RTValue $arg0, RTValue $arg1, RTExecutionContext $ec) throws CALExecutorException {
		switch (scTag) {

			case 0: {
				return 
					_dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2L(
						$arg0, 
						$arg1, 
						$ec);
			}

		}
		// This is an oversaturated lazy application.
		// Usually this occurs when dealing with a lazy application of a function type argument.
		// Defer to the base implementation in the super class.
		return super.f2L($arg0, $arg1, $ec);
	}

	public final RTValue f3S(RTValue $arg0, RTValue $arg1, RTValue $arg2, RTExecutionContext $ec) throws CALExecutorException {
		switch (scTag) {

			case 1: {
				return max_Record_f3S($arg0, $arg1, $arg2, $ec);
			}

			case 2: {
				return min_Record_f3S($arg0, $arg1, $arg2, $ec);
			}

		}
		return RTValue.badValue("Bad scTag in \'f\'.");
	}

	public final RTValue f3L(RTValue $arg0, RTValue $arg1, RTValue $arg2, RTExecutionContext $ec) throws CALExecutorException {
		switch (scTag) {

			case 1: {
				return max_Record_f3L($arg0, $arg1, $arg2, $ec);
			}

			case 2: {
				return min_Record_f3L($arg0, $arg1, $arg2, $ec);
			}

		}
		// This is an oversaturated lazy application.
		// Usually this occurs when dealing with a lazy application of a function type argument.
		// Defer to the base implementation in the super class.
		return super.f3L($arg0, $arg1, $arg2, $ec);
	}

	public static final class RTAppS__dict___Ord___Ord_____Univeral_Record extends RTFullApp {
		private final _dict___Ord___Ord_____Univeral_Record function;

		private RTValue $dictvarCal_Core_Prelude_Ord_0;

		private int $i;

		public RTAppS__dict___Ord___Ord_____Univeral_Record(_dict___Ord___Ord_____Univeral_Record $function, RTValue $$dictvarCal_Core_Prelude_Ord_0, int $$i) {
			assert (
				($function != null) && ($$dictvarCal_Core_Prelude_Ord_0 != null)) : (badConsArgMsg());
			function = $function;
			$dictvarCal_Core_Prelude_Ord_0 = $$dictvarCal_Core_Prelude_Ord_0;
			$i = $$i;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function._dict_Cal___Core___Prelude___Ord_____Univeral_Record_f2S(
						RTValue.lastRef(
							$dictvarCal_Core_Prelude_Ord_0, 
							$dictvarCal_Core_Prelude_Ord_0 = null), 
						$i, 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			$dictvarCal_Core_Prelude_Ord_0 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return $dictvarCal_Core_Prelude_Ord_0;
				}

				case 1: {
					return RTData.CAL_Int.make($i);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
