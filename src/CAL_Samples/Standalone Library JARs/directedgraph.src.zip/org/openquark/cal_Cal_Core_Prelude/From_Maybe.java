package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class From_Maybe extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final From_Maybe $instance = new From_Maybe();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_fromMaybe_3489_5 = 
		new ErrorInfo("Cal.Core.Prelude", "fromMaybe", 3489, 5);

	private From_Maybe() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "fromMaybe";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.fromMaybe";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.fromMaybe
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue maybeValue = $rootNode.getArgValue();
		RTValue defaultValue = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(defaultValue, defaultValue = null), 
				RTValue.lastRef(maybeValue.evaluate($ec), maybeValue = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.fromMaybe
	 */
	public final RTValue f2L(RTValue defaultValue, RTValue maybeValue, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(defaultValue, defaultValue = null), 
				RTValue.lastRef(maybeValue.evaluate($ec), maybeValue = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.fromMaybe
	 */
	public final RTValue f2S(RTValue defaultValue, RTValue maybeValue, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Maybe $case1;

		switch (($case1 = (((TYPE_Maybe)(java.lang.Object)maybeValue.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nothing
				return defaultValue;
			}

			case 1: {
				// Cal.Core.Prelude.Just
				// Decompose data type to access members.
				RTValue value = $case1.get_value();

				return value;
			}

			default: {
				return 
					badSwitchIndex(From_Maybe.Cal_Core_Prelude_fromMaybe_3489_5);
			}
		}
	}

}
