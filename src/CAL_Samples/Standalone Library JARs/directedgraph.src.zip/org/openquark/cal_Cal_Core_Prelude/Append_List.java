package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Append_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Append_List $instance = new Append_List();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_appendList_3135_5 = 
		new ErrorInfo("Cal.Core.Prelude", "appendList", 3135, 5);

	private Append_List() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "appendList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.appendList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.appendList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list2 = $rootNode.getArgValue();
		RTValue list1 = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(list1.evaluate($ec), list1 = null), 
				RTValue.lastRef(list2, list2 = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.appendList
	 */
	public final RTValue f2L(RTValue list1, RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(list1.evaluate($ec), list1 = null), 
				RTValue.lastRef(list2, list2 = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.appendList
	 */
	public final RTValue f2S(RTValue list1, RTValue list2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list1.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return list2;
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue list1Head = $case1.get_head();
				RTValue list1Tail = $case1.get_tail();

				return 
					new TYPE_List.CAL_Cons(
						list1Head, 
						new RTFullApp.General._2._L(
							Append_List.$instance, 
							list1Tail, 
							list2));
			}

			default: {
				return 
					badSwitchIndex(
						Append_List.Cal_Core_Prelude_appendList_3135_5);
			}
		}
	}

}
