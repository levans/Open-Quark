package org.openquark.cal_Cal_Core_Prelude;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Output_List_With__output_List_With_Helper__20 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Output_List_With__output_List_With_Helper__20 $instance = 
		new Output_List_With__output_List_With_Helper__20();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_outputListWith_4207_17 = 
		new ErrorInfo("Cal.Core.Prelude", "outputListWith", 4207, 17);

	private Output_List_With__output_List_With_Helper__20() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "outputListWith$outputListWithHelper$20";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.outputListWith$outputListWithHelper$20";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputListWith$outputListWithHelper$20
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue javaList$L = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue elementMappingFunction = 
			($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue list = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(list.evaluate($ec), list = null), 
				RTValue.lastRef(
					elementMappingFunction, 
					elementMappingFunction = null), 
				((List)(java.lang.Object)
					javaList$L.evaluate($ec).getOpaqueValue()), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputListWith$outputListWithHelper$20
	 */
	public final RTValue f3L(RTValue list, RTValue elementMappingFunction, RTValue javaList$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(list.evaluate($ec), list = null), 
				RTValue.lastRef(
					elementMappingFunction, 
					elementMappingFunction = null), 
				((List)(java.lang.Object)
					javaList$L.evaluate($ec).getOpaqueValue()), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputListWith$outputListWithHelper$20
	 */
	public final RTValue f3S(RTValue list, RTValue elementMappingFunction, List javaList, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return RTData.CAL_Opaque.make(javaList);
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue x = $case1.get_head();
					RTValue xs = $case1.get_tail();

					javaList.add(
						elementMappingFunction.f1L(x, $ec).evaluate(
							$ec).getOpaqueValue());
					list = xs.evaluate($ec);
					continue TRLoop;
				}

				default: {
					return 
						badSwitchIndex(
							Output_List_With__output_List_With_Helper__20.Cal_Core_Prelude_outputListWith_4207_17);
				}
			}
		}
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.outputListWith$outputListWithHelper$20
	 * This version of the logic returns an unboxed value.
	 */
	public final List fUnboxed3S(RTValue list, RTValue elementMappingFunction, List javaList, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_List $case1;

			switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Core.Prelude.Nil
					return ((List)(java.lang.Object)javaList);
				}

				case 1: {
					// Cal.Core.Prelude.Cons
					// Decompose data type to access members.
					RTValue x = $case1.get_head();
					RTValue xs = $case1.get_tail();

					javaList.add(
						elementMappingFunction.f1L(x, $ec).evaluate(
							$ec).getOpaqueValue());
					list = xs.evaluate($ec);
					continue TRLoop;
				}

				default: {
					return 
						((List)(java.lang.Object)
							badSwitchIndex_Object(
								Output_List_With__output_List_With_Helper__20.Cal_Core_Prelude_outputListWith_4207_17));
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Output_List_With__output_List_With_Helper__20 function;

		private RTValue outputListWith$list$21;

		private RTValue outputListWith$elementMappingFunction$22;

		private List outputListWith$javaList$23;

		public RTAppS(Output_List_With__output_List_With_Helper__20 $function, RTValue $outputListWith$list$21, RTValue $outputListWith$elementMappingFunction$22, List $outputListWith$javaList$23) {
			assert (
				(($function != null) && ($outputListWith$list$21 != null)) && 
				($outputListWith$elementMappingFunction$22 != null)) : (badConsArgMsg());
			function = $function;
			outputListWith$list$21 = $outputListWith$list$21;
				outputListWith$elementMappingFunction$22 = 
				$outputListWith$elementMappingFunction$22;
			outputListWith$javaList$23 = $outputListWith$javaList$23;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							outputListWith$list$21, 
							outputListWith$list$21 = null), 
						RTValue.lastRef(
							outputListWith$elementMappingFunction$22, 
							outputListWith$elementMappingFunction$22 = null), 
						outputListWith$javaList$23, 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			outputListWith$list$21 = null;
			outputListWith$elementMappingFunction$22 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return outputListWith$list$21;
				}

				case 1: {
					return outputListWith$elementMappingFunction$22;
				}

				case 2: {
					return RTData.CAL_Opaque.make(outputListWith$javaList$23);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
