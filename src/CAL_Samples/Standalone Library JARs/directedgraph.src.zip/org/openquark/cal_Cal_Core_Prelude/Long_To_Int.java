package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Long_To_Int extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Long_To_Int $instance = new Long_To_Int();

	private Long_To_Int() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "longToInt";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.longToInt";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.longToInt
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $x0$L = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S($x0$L.evaluate($ec).getLongValue(), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.longToInt
	 */
	public final RTValue f1L(RTValue $x0$L, RTExecutionContext $ec) throws CALExecutorException {
		return f1S($x0$L.evaluate($ec).getLongValue(), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.longToInt
	 */
	public final RTValue f1S(long $x0, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Int.make(((int)$x0));
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.longToInt
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed1S(long $x0, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return ((int)$x0);
	}

	public static final class RTAppS extends RTFullApp {
		private final Long_To_Int function;

		private long $x0;

		public RTAppS(Long_To_Int $function, long $$x0) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			$x0 = $$x0;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f1S($x0, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 1;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Long.make($x0);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 1)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
