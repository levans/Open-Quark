package org.openquark.cal_Cal_Core_Prelude;

import java.math.BigInteger;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Int_To_Integer extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Int_To_Integer $instance = new Int_To_Integer();

	private Int_To_Integer() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "intToInteger";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.intToInteger";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.intToInteger
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue intValue$L = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(intValue$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.intToInteger
	 */
	public final RTValue f1L(RTValue intValue$L, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(intValue$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.intToInteger
	 */
	public final RTValue f1S(int intValue, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Integer.make(BigInteger.valueOf(((long)intValue)));
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.intToInteger
	 * This version of the logic returns an unboxed value.
	 */
	public final BigInteger fUnboxed1S(int intValue, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return BigInteger.valueOf(((long)intValue));
	}

	public static final class RTAppS extends RTFullApp {
		private final Int_To_Integer function;

		private int intToInteger$intValue$1;

		public RTAppS(Int_To_Integer $function, int $intToInteger$intValue$1) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			intToInteger$intValue$1 = $intToInteger$intValue$1;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f1S(intToInteger$intValue$1, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 1;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(intToInteger$intValue$1);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 1)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
