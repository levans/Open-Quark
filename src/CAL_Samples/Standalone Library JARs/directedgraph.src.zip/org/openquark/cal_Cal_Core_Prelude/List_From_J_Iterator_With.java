package org.openquark.cal_Cal_Core_Prelude;

import java.util.Iterator;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class List_From_J_Iterator_With extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final List_From_J_Iterator_With $instance = 
		new List_From_J_Iterator_With();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private List_From_J_Iterator_With() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "listFromJIteratorWith";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.listFromJIteratorWith";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJIteratorWith
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue elementMappingFunction = $rootNode.getArgValue();
		RTValue iterator$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				((Iterator)(java.lang.Object)
					iterator$L.evaluate($ec).getOpaqueValue()), 
				RTValue.lastRef(
					elementMappingFunction, 
					elementMappingFunction = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJIteratorWith
	 */
	public final RTValue f2L(RTValue iterator$L, RTValue elementMappingFunction, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				((Iterator)(java.lang.Object)
					iterator$L.evaluate($ec).getOpaqueValue()), 
				RTValue.lastRef(
					elementMappingFunction, 
					elementMappingFunction = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJIteratorWith
	 */
	public final RTValue f2S(Iterator iterator, RTValue elementMappingFunction, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (iterator.hasNext()) {
			return 
				new TYPE_List.CAL_Cons(
					elementMappingFunction.apply(
						RTData.CAL_Opaque.make(iterator.next())), 
					new RTAppS(
						List_From_J_Iterator_With.$instance, 
						iterator, 
						elementMappingFunction));
		} else {
			return List_From_J_Iterator_With.i_Nil;
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final List_From_J_Iterator_With function;

		private Iterator listFromJIteratorWith$iterator$1;

		private RTValue listFromJIteratorWith$elementMappingFunction$2;

		public RTAppS(List_From_J_Iterator_With $function, Iterator $listFromJIteratorWith$iterator$1, RTValue $listFromJIteratorWith$elementMappingFunction$2) {
			assert (
				($function != null) && 
				($listFromJIteratorWith$elementMappingFunction$2 != null)) : (badConsArgMsg());
			function = $function;
			listFromJIteratorWith$iterator$1 = $listFromJIteratorWith$iterator$1;
				listFromJIteratorWith$elementMappingFunction$2 = 
				$listFromJIteratorWith$elementMappingFunction$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						listFromJIteratorWith$iterator$1, 
						RTValue.lastRef(
							listFromJIteratorWith$elementMappingFunction$2, 
								listFromJIteratorWith$elementMappingFunction$2 = 
								null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			listFromJIteratorWith$elementMappingFunction$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return 
						RTData.CAL_Opaque.make(listFromJIteratorWith$iterator$1);
				}

				case 1: {
					return listFromJIteratorWith$elementMappingFunction$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
