package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTIndirection;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Repeat extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Repeat $instance = new Repeat();

	private Repeat() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "repeat";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.repeat";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.repeat
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue valueToRepeat = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(valueToRepeat, valueToRepeat = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.repeat
	 */
	public final RTValue f1L(RTValue valueToRepeat, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(valueToRepeat, valueToRepeat = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.repeat
	 */
	public final RTValue f1S(RTValue valueToRepeat, RTExecutionContext $ec) throws CALExecutorException {
		RTIndirection letVar_repeatedValueList = new RTIndirection();

		letVar_repeatedValueList.setResult(
			new TYPE_List.CAL_Cons(valueToRepeat, letVar_repeatedValueList));
		// Top level supercombinator logic
		return letVar_repeatedValueList;
	}

}
