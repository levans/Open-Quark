package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class If extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final If $instance = new If();

	private If() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "if";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.if";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.if
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $else = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue $then = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $cond$L = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				$cond$L.evaluate($ec).getBooleanValue(), 
				RTValue.lastRef($then, $then = null), 
				RTValue.lastRef($else, $else = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.if
	 */
	public final RTValue f3L(RTValue $cond$L, RTValue $then, RTValue $else, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				$cond$L.evaluate($ec).getBooleanValue(), 
				RTValue.lastRef($then, $then = null), 
				RTValue.lastRef($else, $else = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.if
	 */
	public final RTValue f3S(boolean $cond, RTValue $then, RTValue $else, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if ($cond) {
			return $then;
		} else {
			return $else;
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final If function;

		private boolean $cond;

		private RTValue $then;

		private RTValue $else;

		public RTAppS(If $function, boolean $$cond, RTValue $$then, RTValue $$else) {
			assert (
				(($function != null) && ($$then != null)) && ($$else != null)) : (badConsArgMsg());
			function = $function;
			$cond = $$cond;
			$then = $$then;
			$else = $$else;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						$cond, 
						RTValue.lastRef($then, $then = null), 
						RTValue.lastRef($else, $else = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			$then = null;
			$else = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Boolean.make($cond);
				}

				case 1: {
					return $then;
				}

				case 2: {
					return $else;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
