package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class Up_From_Int extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Up_From_Int $instance = new Up_From_Int();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Up_From_Int() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "upFromInt";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.upFromInt";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.upFromInt
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue start$L = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(start$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.upFromInt
	 */
	public final RTValue f1L(RTValue start$L, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(start$L.evaluate($ec).getOrdinalValue(), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.upFromInt
	 */
	public final RTValue f1S(int start, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (start < 2147483647) {
			return 
				new TYPE_List.CAL_Cons(
					RTData.CAL_Int.make(start), 
					new RTAppS(Up_From_Int.$instance, start + 1));
		} else {
			return 
				new TYPE_List.CAL_Cons(
					RTData.CAL_Int.make(start), 
					Up_From_Int.i_Nil);
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Up_From_Int function;

		private int upFromInt$start$1;

		public RTAppS(Up_From_Int $function, int $upFromInt$start$1) {
			assert ($function != null) : (badConsArgMsg());
			function = $function;
			upFromInt$start$1 = $upFromInt$start$1;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(function.f1S(upFromInt$start$1, $ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 1;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(upFromInt$start$1);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 1)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
