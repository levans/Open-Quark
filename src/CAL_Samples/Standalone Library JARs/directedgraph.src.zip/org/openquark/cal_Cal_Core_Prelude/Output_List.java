package org.openquark.cal_Cal_Core_Prelude;

import java.util.List;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Output_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Output_List $instance = new Output_List();

	private Output_List() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "outputList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.outputList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Outputable_34 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Outputable_34, 
					$dictvarCal_Core_Prelude_Outputable_34 = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputList
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Outputable_34, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Outputable_34, 
					$dictvarCal_Core_Prelude_Outputable_34 = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.outputList
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Outputable_34, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Output_List_With.$instance.f2S(
				list.getValue(), 
				$dictvarCal_Core_Prelude_Outputable_34, 
				$ec);
	}

	/**
	 * fUnboxed2S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.outputList
	 * This version of the logic returns an unboxed value.
	 */
	public final List fUnboxed2S(RTValue $dictvarCal_Core_Prelude_Outputable_34, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = 
			f2S($dictvarCal_Core_Prelude_Outputable_34, list, $ec);

		$dictvarCal_Core_Prelude_Outputable_34 = null;
		list = null;
		return ((List)(java.lang.Object)$result.evaluate($ec).getOpaqueValue());
	}

}
