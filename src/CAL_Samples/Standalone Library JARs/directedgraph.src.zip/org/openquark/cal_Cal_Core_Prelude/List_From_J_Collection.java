package org.openquark.cal_Cal_Core_Prelude;

import java.util.Collection;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class List_From_J_Collection extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final List_From_J_Collection $instance = 
		new List_From_J_Collection();

	private List_From_J_Collection() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "listFromJCollection";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.listFromJCollection";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJCollection
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue collection$L = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Inputable_37 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Inputable_37, 
					$dictvarCal_Core_Prelude_Inputable_37 = null), 
				((Collection)(java.lang.Object)
					collection$L.evaluate($ec).getOpaqueValue()), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJCollection
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Inputable_37, RTValue collection$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Inputable_37, 
					$dictvarCal_Core_Prelude_Inputable_37 = null), 
				((Collection)(java.lang.Object)
					collection$L.evaluate($ec).getOpaqueValue()), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJCollection
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Inputable_37, Collection collection, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			List_From_J_Collection_With.$instance.f2S(
				collection, 
				$dictvarCal_Core_Prelude_Inputable_37, 
				$ec);
	}

	public static final class RTAppS extends RTFullApp {
		private final List_From_J_Collection function;

		private RTValue $dictvarCal_Core_Prelude_Inputable_37;

		private Collection listFromJCollection$collection$1;

		public RTAppS(List_From_J_Collection $function, RTValue $$dictvarCal_Core_Prelude_Inputable_37, Collection $listFromJCollection$collection$1) {
			assert (
				($function != null) && 
				($$dictvarCal_Core_Prelude_Inputable_37 != null)) : (badConsArgMsg());
			function = $function;
				$dictvarCal_Core_Prelude_Inputable_37 = 
				$$dictvarCal_Core_Prelude_Inputable_37;
			listFromJCollection$collection$1 = $listFromJCollection$collection$1;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(
							$dictvarCal_Core_Prelude_Inputable_37, 
							$dictvarCal_Core_Prelude_Inputable_37 = null), 
						listFromJCollection$collection$1, 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			$dictvarCal_Core_Prelude_Inputable_37 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return $dictvarCal_Core_Prelude_Inputable_37;
				}

				case 1: {
					return 
						RTData.CAL_Opaque.make(listFromJCollection$collection$1);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
