package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Is_Empty_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Is_Empty_List $instance = new Is_Empty_List();

	private Is_Empty_List() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "isEmptyList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.isEmptyList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.isEmptyList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.isEmptyList
	 */
	public final RTValue f1L(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(list.evaluate($ec), list = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.isEmptyList
	 */
	public final RTValue f1S(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Boolean.make(list.getValue().getOrdinalValue() == 0);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.isEmptyList
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed1S(RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return list.getValue().getOrdinalValue() == 0;
	}

}
