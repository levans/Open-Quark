package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Flip extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Flip $instance = new Flip();

	private Flip() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "flip";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.flip";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.flip
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue y = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue f = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(f.evaluate($ec), f = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(y, y = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.flip
	 */
	public final RTValue f3L(RTValue f, RTValue x, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(f.evaluate($ec), f = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(y, y = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.flip
	 */
	public final RTValue f3S(RTValue f, RTValue x, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return f.getValue().apply(y, x);
	}

}
