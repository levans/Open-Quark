package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTDataConsFieldSelection;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public abstract class TYPE_Maybe extends RTCons {
	protected TYPE_Maybe() {
	}

	public RTValue get_value() {
		return badFieldAccessor("_value");
	}

	protected final java.lang.String getDCNameByOrdinal(int dcOrdinal) {
		switch (dcOrdinal) {

			case 0: {
				return "Nothing";
			}

			case 1: {
				return "Just";
			}

		}
		return 
			((java.lang.String)(java.lang.Object)
				RTValue.badValue_Object(
					null, 
					"Invalid DC ordinal in getDCNameByOrdinal() for org.openquark.cal_Cal_Core_Prelude.TYPE_Maybe"));
	}

	public static final class CAL_Nothing extends TYPE_Maybe {
		public static final CAL_Nothing $instance = new CAL_Nothing();

		private CAL_Nothing() {
		}

		public final int getArity() {
			return 0;
		}

		public int getOrdinalValue() {
			return 0;
		}

		public static final CAL_Nothing make() {
			return CAL_Nothing.$instance;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Core.Prelude";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Nothing";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Core.Prelude.Nothing";
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Core.Prelude.Nothing";
			}

		}
	}
	public static final class CAL_Just extends TYPE_Maybe {
		private RTValue _value;

		public static final CAL_Just $instance = new CAL_Just();

		private CAL_Just() {
		}

		public CAL_Just(RTValue member0) {
			assert (member0 != null) : ("Invalid constructor argument for Cal.Core.Prelude.Just");
			_value = member0;
		}

		public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
			// Arguments
			final RTValue $arg0 = $rootNode.getArgValue();

			return new CAL_Just($arg0);
		}

		public final RTValue f1L(RTValue member0, RTExecutionContext $ec) throws CALExecutorException {
			return new CAL_Just(member0);
		}

		public final int getArity() {
			return 1;
		}

		public int getOrdinalValue() {
			return 1;
		}

		public static final CAL_Just make() {
			return CAL_Just.$instance;
		}

		public final RTValue get_value() {
			RTValue _value$;

			if (((java.lang.Object)
				(_value$ = _value))
				 instanceof RTResultFunction) {
				return _value = _value$.getValue();
			}
			return _value$;
		}

		public final RTValue buildDeepSeq(RTSupercombinator deepSeq, RTValue rhs) throws CALExecutorException {
			return deepSeq.apply(get_value(), rhs);
		}

		public final RTValue getFieldByIndex(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return get_value();
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return null;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Core.Prelude";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Just";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Core.Prelude.Just";
		}

		public final boolean isFunctionSingleton() {
			return this == CAL_Just.$instance;
		}

		public final CalValue debug_getChild(int childN) {
			if (isFunctionSingleton()) {
				throw new java.lang.IndexOutOfBoundsException();
			}
			switch (childN) {

				case 0: {
					return _value;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

					case 0: {
						return "value";
					}

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Core.Prelude.Just";
			}

		}
	}
}
