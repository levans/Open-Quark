package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Induce_Equality_Function extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	/**
	 * Singleton instance of this class.
	 */
	public static final Induce_Equality_Function $instance = 
		new Induce_Equality_Function();

	private Induce_Equality_Function() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "induceEqualityFunction";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.induceEqualityFunction";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.induceEqualityFunction
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue y = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue projectionFunction = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_41 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_41, 
					$dictvarCal_Core_Prelude_Eq_41 = null), 
				RTValue.lastRef(
					projectionFunction.evaluate($ec), 
					projectionFunction = null), 
				RTValue.lastRef(x.evaluate($ec), x = null), 
				RTValue.lastRef(y.evaluate($ec), y = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.induceEqualityFunction
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Prelude_Eq_41, RTValue projectionFunction, RTValue x, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_41, 
					$dictvarCal_Core_Prelude_Eq_41 = null), 
				RTValue.lastRef(
					projectionFunction.evaluate($ec), 
					projectionFunction = null), 
				RTValue.lastRef(x.evaluate($ec), x = null), 
				RTValue.lastRef(y.evaluate($ec), y = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.induceEqualityFunction
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Prelude_Eq_41, RTValue projectionFunction, RTValue x, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new RTOApp3(
				$dictvarCal_Core_Prelude_Eq_41, 
				Induce_Equality_Function.$L1_Int_0, 
				projectionFunction.getValue().apply(x.getValue()), 
				projectionFunction.getValue().apply(y.getValue()));
	}

	/**
	 * fUnboxed4S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.induceEqualityFunction
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed4S(RTValue $dictvarCal_Core_Prelude_Eq_41, RTValue projectionFunction, RTValue x, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = 
			f4S($dictvarCal_Core_Prelude_Eq_41, projectionFunction, x, y, $ec);

		$dictvarCal_Core_Prelude_Eq_41 = null;
		projectionFunction = null;
		x = null;
		y = null;
		return $result.evaluate($ec).getBooleanValue();
	}

}
