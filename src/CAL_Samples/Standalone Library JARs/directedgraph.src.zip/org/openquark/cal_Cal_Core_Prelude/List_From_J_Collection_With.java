package org.openquark.cal_Cal_Core_Prelude;

import java.util.Collection;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class List_From_J_Collection_With extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final List_From_J_Collection_With $instance = 
		new List_From_J_Collection_With();

	private List_From_J_Collection_With() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "listFromJCollectionWith";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.listFromJCollectionWith";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJCollectionWith
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue elementMappingFunction = $rootNode.getArgValue();
		RTValue javaCollection$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				((Collection)(java.lang.Object)
					javaCollection$L.evaluate($ec).getOpaqueValue()), 
				RTValue.lastRef(
					elementMappingFunction, 
					elementMappingFunction = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJCollectionWith
	 */
	public final RTValue f2L(RTValue javaCollection$L, RTValue elementMappingFunction, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				((Collection)(java.lang.Object)
					javaCollection$L.evaluate($ec).getOpaqueValue()), 
				RTValue.lastRef(
					elementMappingFunction, 
					elementMappingFunction = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.listFromJCollectionWith
	 */
	public final RTValue f2S(Collection javaCollection, RTValue elementMappingFunction, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			List_From_J_Iterator_With.$instance.f2S(
				javaCollection.iterator(), 
				elementMappingFunction, 
				$ec);
	}

	public static final class RTAppS extends RTFullApp {
		private final List_From_J_Collection_With function;

		private Collection listFromJCollectionWith$javaCollection$1;

		private RTValue listFromJCollectionWith$elementMappingFunction$2;

		public RTAppS(List_From_J_Collection_With $function, Collection $listFromJCollectionWith$javaCollection$1, RTValue $listFromJCollectionWith$elementMappingFunction$2) {
			assert (
				($function != null) && 
				($listFromJCollectionWith$elementMappingFunction$2 != null)) : (badConsArgMsg());
			function = $function;
				listFromJCollectionWith$javaCollection$1 = 
				$listFromJCollectionWith$javaCollection$1;
				listFromJCollectionWith$elementMappingFunction$2 = 
				$listFromJCollectionWith$elementMappingFunction$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						listFromJCollectionWith$javaCollection$1, 
						RTValue.lastRef(
							listFromJCollectionWith$elementMappingFunction$2, 
								listFromJCollectionWith$elementMappingFunction$2 = 
								null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			listFromJCollectionWith$elementMappingFunction$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return 
						RTData.CAL_Opaque.make(
							listFromJCollectionWith$javaCollection$1);
				}

				case 1: {
					return listFromJCollectionWith$elementMappingFunction$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
