package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTEqualsRecord;
import org.openquark.cal.internal.runtime.lecc.functions.RTNotEqualsRecord;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;

public final class _dict___Eq___Eq_____Univeral_Record extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final _dict___Eq___Eq_____Univeral_Record $instance = 
		new _dict___Eq___Eq_____Univeral_Record();

	private _dict___Eq___Eq_____Univeral_Record() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "$dictCal.Core.Prelude.Eq#$UniveralRecord";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.$dictCal.Core.Prelude.Eq#$UniveralRecord";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Eq#$UniveralRecord
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $i$L = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_0 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_0, 
					$dictvarCal_Core_Prelude_Eq_0 = null), 
				$i$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Eq#$UniveralRecord
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Eq_0, RTValue $i$L, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_0, 
					$dictvarCal_Core_Prelude_Eq_0 = null), 
				$i$L.evaluate($ec).getOrdinalValue(), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.$dictCal.Core.Prelude.Eq#$UniveralRecord
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Eq_0, int $i, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		switch ($i) {

			case 0: {
				return 
					new RTPartialApp._3._1(
						RTEqualsRecord.$instance, 
						$dictvarCal_Core_Prelude_Eq_0);
			}

			case 1: {
				return 
					new RTPartialApp._3._1(
						RTNotEqualsRecord.$instance, 
						$dictvarCal_Core_Prelude_Eq_0);
			}

			default: {
				return unhandledSwitchIndexForIntPattern(null);
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final _dict___Eq___Eq_____Univeral_Record function;

		private RTValue $dictvarCal_Core_Prelude_Eq_0;

		private int $i;

		public RTAppS(_dict___Eq___Eq_____Univeral_Record $function, RTValue $$dictvarCal_Core_Prelude_Eq_0, int $$i) {
			assert (
				($function != null) && ($$dictvarCal_Core_Prelude_Eq_0 != null)) : (badConsArgMsg());
			function = $function;
			$dictvarCal_Core_Prelude_Eq_0 = $$dictvarCal_Core_Prelude_Eq_0;
			$i = $$i;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(
							$dictvarCal_Core_Prelude_Eq_0, 
							$dictvarCal_Core_Prelude_Eq_0 = null), 
						$i, 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			$dictvarCal_Core_Prelude_Eq_0 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return $dictvarCal_Core_Prelude_Eq_0;
				}

				case 1: {
					return RTData.CAL_Int.make($i);
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
