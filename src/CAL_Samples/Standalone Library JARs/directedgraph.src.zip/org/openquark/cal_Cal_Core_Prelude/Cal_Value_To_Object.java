package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Cal_Value_To_Object extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Cal_Value_To_Object $instance = 
		new Cal_Value_To_Object();

	private Cal_Value_To_Object() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "calValueToObject";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.calValueToObject";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.calValueToObject
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue $x0 = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef($x0, $x0 = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.calValueToObject
	 */
	public final RTValue f1L(RTValue $x0, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef($x0, $x0 = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.calValueToObject
	 */
	public final RTValue f1S(RTValue $x0, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return RTData.CAL_Opaque.make($x0);
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Core.Prelude.calValueToObject
	 * This version of the logic returns an unboxed value.
	 */
	public final java.lang.Object fUnboxed1S(RTValue $x0, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return $x0;
	}

}
