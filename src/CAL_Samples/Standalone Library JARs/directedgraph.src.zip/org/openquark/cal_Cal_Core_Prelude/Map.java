package org.openquark.cal_Cal_Core_Prelude;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Map extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Map $instance = new Map();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Core_Prelude_map_3203_5 = 
		new ErrorInfo("Cal.Core.Prelude", "map", 3203, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_List.CAL_Nil i_Nil = TYPE_List.CAL_Nil.make();

	private Map() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Core.Prelude";
	}

	public final java.lang.String getUnqualifiedName() {
		return "map";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Core.Prelude.map";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.map
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue mapFunction = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(mapFunction, mapFunction = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.map
	 */
	public final RTValue f2L(RTValue mapFunction, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(mapFunction, mapFunction = null), 
				RTValue.lastRef(list.evaluate($ec), list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Core.Prelude.map
	 */
	public final RTValue f2S(RTValue mapFunction, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_List $case1;

		switch (($case1 = (((TYPE_List)(java.lang.Object)list.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Core.Prelude.Nil
				return Map.i_Nil;
			}

			case 1: {
				// Cal.Core.Prelude.Cons
				// Decompose data type to access members.
				RTValue listHead = $case1.get_head();
				RTValue listTail = $case1.get_tail();

				return 
					new TYPE_List.CAL_Cons(
						mapFunction.apply(listHead), 
						new RTFullApp.General._2._L(
							Map.$instance, 
							mapFunction, 
							listTail));
			}

			default: {
				return badSwitchIndex(Map.Cal_Core_Prelude_map_3203_5);
			}
		}
	}

}
