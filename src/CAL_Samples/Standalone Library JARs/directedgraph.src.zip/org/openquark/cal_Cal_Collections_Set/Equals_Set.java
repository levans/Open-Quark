package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude._equals___List;

public final class Equals_Set extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Equals_Set $instance = new Equals_Set();

	private Equals_Set() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "equalsSet";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.equalsSet";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.equalsSet
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue s2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue s1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Eq_9 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_9, 
					$dictvarCal_Core_Prelude_Eq_9 = null), 
				RTValue.lastRef(s1.evaluate($ec), s1 = null), 
				RTValue.lastRef(s2.evaluate($ec), s2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.equalsSet
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Eq_9, RTValue s1, RTValue s2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Eq_9, 
					$dictvarCal_Core_Prelude_Eq_9 = null), 
				RTValue.lastRef(s1.evaluate($ec), s1 = null), 
				RTValue.lastRef(s2.evaluate($ec), s2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.equalsSet
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Eq_9, RTValue s1, RTValue s2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(
				(Size.$instance.fUnboxed1S(s1.getValue(), $ec) == 
				Size.$instance.fUnboxed1S(s2.getValue(), $ec)) && 
				_equals___List.$instance.fUnboxed3S(
					$dictvarCal_Core_Prelude_Eq_9, 
					To_Asc_List.$instance.f1S(s1.getValue(), $ec).evaluate(
						$ec), 
					To_Asc_List.$instance.f1S(s2.getValue(), $ec).evaluate(
						$ec), 
					$ec));
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Collections.Set.equalsSet
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Eq_9, RTValue s1, RTValue s2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(Size.$instance.fUnboxed1S(s1.getValue(), $ec) == 
			Size.$instance.fUnboxed1S(s2.getValue(), $ec)) && 
			_equals___List.$instance.fUnboxed3S(
				$dictvarCal_Core_Prelude_Eq_9, 
				To_Asc_List.$instance.f1S(s1.getValue(), $ec).evaluate($ec), 
				To_Asc_List.$instance.f1S(s2.getValue(), $ec).evaluate($ec), 
				$ec);
	}

}
