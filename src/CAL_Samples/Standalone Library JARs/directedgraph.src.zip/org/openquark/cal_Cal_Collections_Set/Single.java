package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Single extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Single $instance = new Single();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Single() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "single";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.single";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.single
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue x = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(x, x = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.single
	 */
	public final RTValue f1L(RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(x, x = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.single
	 */
	public final RTValue f1S(RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return new TYPE_Set.CAL_Bin(1, x, Single.i_Tip, Single.i_Tip);
	}

}
