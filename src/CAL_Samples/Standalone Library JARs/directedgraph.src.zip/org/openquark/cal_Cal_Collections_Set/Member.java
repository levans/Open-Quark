package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Member extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_5 = RTData.CAL_Int.make(5);

	/**
	 * Singleton instance of this class.
	 */
	public static final Member $instance = new Member();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_member_369_5 = 
		new ErrorInfo("Cal.Collections.Set", "member", 369, 5);

	private static final ErrorInfo Cal_Collections_Set_member_372_9 = 
		new ErrorInfo("Cal.Collections.Set", "member", 372, 9);

	private Member() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "member";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.member";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.member
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_29 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_29, 
					$dictvarCal_Core_Prelude_Ord_29 = null), 
				RTValue.lastRef(x.evaluate($ec), x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.member
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_29, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_29, 
					$dictvarCal_Core_Prelude_Ord_29 = null), 
				RTValue.lastRef(x.evaluate($ec), x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.member
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_29, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_Set $case1;

			switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Collections.Set.Tip
					return RTData.CAL_Boolean.make(false);
				}

				case 1: {
					// Cal.Collections.Set.Bin
					// Decompose data type to access members.
					RTValue value = $case1.get_value();
					RTValue leftSet = $case1.get_leftSet();
					RTValue rightSet = $case1.get_rightSet();

					switch ((new RTOApp3($dictvarCal_Core_Prelude_Ord_29, Member.$L1_Int_5, x.getValue(), value)).evaluate($ec).getOrdinalValue()) {

						case 0: {
							// Cal.Core.Prelude.LT
							t = leftSet;
							continue TRLoop;
						}

						case 1: {
							// Cal.Core.Prelude.EQ
							return RTData.CAL_Boolean.make(true);
						}

						case 2: {
							// Cal.Core.Prelude.GT
							t = rightSet;
							continue TRLoop;
						}

						default: {
							return 
								badSwitchIndex(
									Member.Cal_Collections_Set_member_372_9);
						}
					}
				}

				default: {
					return 
						badSwitchIndex(Member.Cal_Collections_Set_member_369_5);
				}
			}
		}
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Collections.Set.member
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Ord_29, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_Set $case1;

			switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Collections.Set.Tip
					return false;
				}

				case 1: {
					// Cal.Collections.Set.Bin
					// Decompose data type to access members.
					RTValue value = $case1.get_value();
					RTValue leftSet = $case1.get_leftSet();
					RTValue rightSet = $case1.get_rightSet();

					switch ((new RTOApp3($dictvarCal_Core_Prelude_Ord_29, Member.$L1_Int_5, x.getValue(), value)).evaluate($ec).getOrdinalValue()) {

						case 0: {
							// Cal.Core.Prelude.LT
							t = leftSet;
							continue TRLoop;
						}

						case 1: {
							// Cal.Core.Prelude.EQ
							return true;
						}

						case 2: {
							// Cal.Core.Prelude.GT
							t = rightSet;
							continue TRLoop;
						}

						default: {
							return 
								badSwitchIndex_boolean(
									Member.Cal_Collections_Set_member_372_9);
						}
					}
				}

				default: {
					return 
						badSwitchIndex_boolean(
							Member.Cal_Collections_Set_member_369_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Member function;

		private RTValue $dictvarCal_Core_Prelude_Ord_29;

		private RTValue member$x$1;

		private RTValue member$t$2;

		public RTAppS(Member $function, RTValue $$dictvarCal_Core_Prelude_Ord_29, RTValue $member$x$1, RTValue $member$t$2) {
			assert (
				((($function != null) && 
				($$dictvarCal_Core_Prelude_Ord_29 != null)) && 
				($member$x$1 != null)) && 
				($member$t$2 != null)) : (badConsArgMsg());
			function = $function;
			$dictvarCal_Core_Prelude_Ord_29 = $$dictvarCal_Core_Prelude_Ord_29;
			member$x$1 = $member$x$1;
			member$t$2 = $member$t$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							$dictvarCal_Core_Prelude_Ord_29, 
							$dictvarCal_Core_Prelude_Ord_29 = null), 
						RTValue.lastRef(member$x$1, member$x$1 = null), 
						RTValue.lastRef(member$t$2, member$t$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			$dictvarCal_Core_Prelude_Ord_29 = null;
			member$x$1 = null;
			member$t$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return $dictvarCal_Core_Prelude_Ord_29;
				}

				case 1: {
					return member$x$1;
				}

				case 2: {
					return member$t$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
