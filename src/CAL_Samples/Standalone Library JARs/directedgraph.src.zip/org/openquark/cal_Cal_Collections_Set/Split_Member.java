package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Split_Member extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_5 = RTData.CAL_Int.make(5);

	/**
	 * Singleton instance of this class.
	 */
	public static final Split_Member $instance = new Split_Member();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_splitMember_1635_5 = 
		new ErrorInfo("Cal.Collections.Set", "splitMember", 1635, 5);

	private static final ErrorInfo Cal_Collections_Set_splitMember_1638_9 = 
		new ErrorInfo("Cal.Collections.Set", "splitMember", 1638, 9);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Split_Member() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "splitMember";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.splitMember";
	}

	private static final RTValue gt$8$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 3);
	}

	private static final RTValue gt$8$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				3).evaluate(
				$ec);
	}

	private static final RTValue lt$7$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 2);
	}

	private static final RTValue lt$7$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue found$6$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 1);
	}

	private static final RTValue found$6$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final boolean found$6$def_Unboxed(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec).getBooleanValue();
	}

	private static final RTValue $pattern_found_lt_gt$9$def_Lazy(RTValue $dictvarCal_Core_Prelude_Ord_1, RTValue x, RTValue leftSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Split_Member.$instance, 
				$dictvarCal_Core_Prelude_Ord_1, 
				x, 
				leftSet.getValue());
	}

	private static final RTValue $pattern_found_lt_gt$9$def_Strict(RTValue $dictvarCal_Core_Prelude_Ord_1, RTValue x, RTValue leftSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Split_Member.$instance.f3S(
				$dictvarCal_Core_Prelude_Ord_1, 
				x, 
				leftSet.getValue(), 
				$ec).evaluate(
				$ec);
	}

	private static final RTValue gt$12$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 3);
	}

	private static final RTValue gt$12$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				3).evaluate(
				$ec);
	}

	private static final RTValue lt$11$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 2);
	}

	private static final RTValue lt$11$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue found$10$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 1);
	}

	private static final RTValue found$10$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final boolean found$10$def_Unboxed(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec).getBooleanValue();
	}

	private static final RTValue $pattern_found_lt_gt$13$def_Lazy(RTValue $dictvarCal_Core_Prelude_Ord_1, RTValue x, RTValue rightSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Split_Member.$instance, 
				$dictvarCal_Core_Prelude_Ord_1, 
				x, 
				rightSet.getValue());
	}

	private static final RTValue $pattern_found_lt_gt$13$def_Strict(RTValue $dictvarCal_Core_Prelude_Ord_1, RTValue x, RTValue rightSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Split_Member.$instance.f3S(
				$dictvarCal_Core_Prelude_Ord_1, 
				x, 
				rightSet.getValue(), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.splitMember
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_1 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_1, 
					$dictvarCal_Core_Prelude_Ord_1 = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.splitMember
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_1, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_1, 
					$dictvarCal_Core_Prelude_Ord_1 = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.splitMember
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_1, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {RTData.CAL_Boolean.make(false), Split_Member.i_Tip, Split_Member.i_Tip});
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue value = $case1.get_value();
				RTValue leftSet = $case1.get_leftSet();
				RTValue rightSet = $case1.get_rightSet();

				switch ((new RTOApp3($dictvarCal_Core_Prelude_Ord_1, Split_Member.$L1_Int_5, x, value)).evaluate($ec).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.LT
						RTValue letVar_pattern_found_lt_gt = 
							Split_Member.$pattern_found_lt_gt$9$def_Lazy(
								$dictvarCal_Core_Prelude_Ord_1, 
								x, 
								leftSet, 
								$ec);

						return 
							RTRecordValue.makeTupleRecord(
								new RTValue[] {Split_Member.found$6$def_Lazy(letVar_pattern_found_lt_gt, $ec), Split_Member.lt$7$def_Lazy(letVar_pattern_found_lt_gt, $ec), new RTFullApp.General._3._L(Join.$instance, value, Split_Member.gt$8$def_Lazy(letVar_pattern_found_lt_gt, $ec), rightSet)});
					}

					case 1: {
						// Cal.Core.Prelude.EQ
						return 
							RTRecordValue.makeTupleRecord(
								new RTValue[] {RTData.CAL_Boolean.make(true), leftSet, rightSet});
					}

					case 2: {
						// Cal.Core.Prelude.GT
						RTValue letVar_pattern_found_lt_gt_1 = 
							Split_Member.$pattern_found_lt_gt$13$def_Lazy(
								$dictvarCal_Core_Prelude_Ord_1, 
								x, 
								rightSet, 
								$ec);

						return 
							RTRecordValue.makeTupleRecord(
								new RTValue[] {Split_Member.found$10$def_Lazy(letVar_pattern_found_lt_gt_1, $ec), new RTFullApp.General._3._L(Join.$instance, value, leftSet, Split_Member.lt$11$def_Lazy(letVar_pattern_found_lt_gt_1, $ec)), Split_Member.gt$12$def_Lazy(letVar_pattern_found_lt_gt_1, $ec)});
					}

					default: {
						return 
							badSwitchIndex(
								Split_Member.Cal_Collections_Set_splitMember_1638_9);
					}
				}
			}

			default: {
				return 
					badSwitchIndex(
						Split_Member.Cal_Collections_Set_splitMember_1635_5);
			}
		}
	}

}
