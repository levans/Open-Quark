package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Double_L extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Double_L $instance = new Double_L();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_doubleL_2003_5 = 
		new ErrorInfo("Cal.Collections.Set", "doubleL", 2003, 5);

	private static final ErrorInfo Cal_Collections_Set_doubleL_2005_9 = 
		new ErrorInfo("Cal.Collections.Set", "doubleL", 2005, 9);

	private Double_L() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "doubleL";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.doubleL";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.doubleL
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t5 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue x1 = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(x1, x1 = null), 
				RTValue.lastRef(t1, t1 = null), 
				RTValue.lastRef(t5.evaluate($ec), t5 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.doubleL
	 */
	public final RTValue f3L(RTValue x1, RTValue t1, RTValue t5, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(x1, x1 = null), 
				RTValue.lastRef(t1, t1 = null), 
				RTValue.lastRef(t5.evaluate($ec), t5 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.doubleL
	 */
	public final RTValue f3S(RTValue x1, RTValue t1, RTValue t5, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t5.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 
					unhandledSwitchIndex(
						Double_L.Cal_Collections_Set_doubleL_2003_5, 
						"Cal.Collections.Set.Tip");
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue x2 = $case1.get_value();
				RTValue t6 = $case1.get_leftSet();
				RTValue t4 = $case1.get_rightSet();

				TYPE_Set $case2;

				switch (($case2 = (((TYPE_Set)(java.lang.Object)t6))).getOrdinalValue()) {

					case 0: {
						// Cal.Collections.Set.Tip
						return 
							unhandledSwitchIndex(
								Double_L.Cal_Collections_Set_doubleL_2005_9, 
								"Cal.Collections.Set.Tip");
					}

					case 1: {
						// Cal.Collections.Set.Bin
						// Decompose data type to access members.
						RTValue x3 = $case2.get_value();
						RTValue t2 = $case2.get_leftSet();
						RTValue t3 = $case2.get_rightSet();

						return 
							Bin.$instance.f3S(
								x3, 
								Bin.$instance.f3S(
									x1, 
									t1.evaluate($ec), 
									t2, 
									$ec).evaluate(
									$ec), 
								Bin.$instance.f3S(x2, t3, t4, $ec).evaluate(
									$ec), 
								$ec);
					}

					default: {
						return 
							badSwitchIndex(
								Double_L.Cal_Collections_Set_doubleL_2005_9);
					}
				}
			}

			default: {
				return 
					badSwitchIndex(Double_L.Cal_Collections_Set_doubleL_2003_5);
			}
		}
	}

}
