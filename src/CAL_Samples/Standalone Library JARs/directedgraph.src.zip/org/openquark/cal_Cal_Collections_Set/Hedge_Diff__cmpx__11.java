package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Hedge_Diff__cmpx__11 extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_5 = RTData.CAL_Int.make(5);

	/**
	 * Singleton instance of this class.
	 */
	public static final Hedge_Diff__cmpx__11 $instance = 
		new Hedge_Diff__cmpx__11();

	private Hedge_Diff__cmpx__11() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "hedgeDiff$cmpx$11";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.hedgeDiff$cmpx$11";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.hedgeDiff$cmpx$11
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue y = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue value = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_18 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_18, 
					$dictvarCal_Core_Prelude_Ord_18 = null), 
				RTValue.lastRef(value, value = null), 
				RTValue.lastRef(y, y = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.hedgeDiff$cmpx$11
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_18, RTValue value, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_18, 
					$dictvarCal_Core_Prelude_Ord_18 = null), 
				RTValue.lastRef(value, value = null), 
				RTValue.lastRef(y, y = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.hedgeDiff$cmpx$11
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_18, RTValue value, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new RTOApp3(
				$dictvarCal_Core_Prelude_Ord_18, 
				Hedge_Diff__cmpx__11.$L1_Int_5, 
				value, 
				y);
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Collections.Set.hedgeDiff$cmpx$11
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Ord_18, RTValue value, RTValue y, RTExecutionContext $ec) throws CALExecutorException {
		RTValue $result = f3S($dictvarCal_Core_Prelude_Ord_18, value, y, $ec);

		$dictvarCal_Core_Prelude_Ord_18 = null;
		value = null;
		y = null;
		return $result.evaluate($ec).getOrdinalValue();
	}

}
