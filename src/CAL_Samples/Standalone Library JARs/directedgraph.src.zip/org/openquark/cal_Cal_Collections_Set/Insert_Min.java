package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Insert_Min extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Insert_Min $instance = new Insert_Min();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_insertMin_1741_5 = 
		new ErrorInfo("Cal.Collections.Set", "insertMin", 1741, 5);

	private Insert_Min() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "insertMin";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.insertMin";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.insertMin
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue x = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.insertMin
	 */
	public final RTValue f2L(RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.insertMin
	 */
	public final RTValue f2S(RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return Single.$instance.f1S(x, $ec);
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue value = $case1.get_value();
				RTValue leftSet = $case1.get_leftSet();
				RTValue rightSet = $case1.get_rightSet();

				return 
					new RTFullApp.General._3._L(
						Balance.$instance, 
						value, 
						new RTFullApp.General._2._S(
							Insert_Min.$instance, 
							x, 
							leftSet), 
						rightSet);
			}

			default: {
				return 
					badSwitchIndex(
						Insert_Min.Cal_Collections_Set_insertMin_1741_5);
			}
		}
	}

}
