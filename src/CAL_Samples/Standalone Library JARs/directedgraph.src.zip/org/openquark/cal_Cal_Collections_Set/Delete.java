package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Delete extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_5 = RTData.CAL_Int.make(5);

	/**
	 * Singleton instance of this class.
	 */
	public static final Delete $instance = new Delete();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_delete_474_5 = 
		new ErrorInfo("Cal.Collections.Set", "delete", 474, 5);

	private static final ErrorInfo Cal_Collections_Set_delete_477_9 = 
		new ErrorInfo("Cal.Collections.Set", "delete", 477, 9);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Delete() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "delete";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.delete";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.delete
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_0 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_0, 
					$dictvarCal_Core_Prelude_Ord_0 = null), 
				RTValue.lastRef(x.evaluate($ec), x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.delete
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_0, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_0, 
					$dictvarCal_Core_Prelude_Ord_0 = null), 
				RTValue.lastRef(x.evaluate($ec), x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.delete
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_0, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return Delete.i_Tip;
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue value = $case1.get_value();
				RTValue leftSet = $case1.get_leftSet();
				RTValue rightSet = $case1.get_rightSet();

				switch ((new RTOApp3($dictvarCal_Core_Prelude_Ord_0, Delete.$L1_Int_5, x.getValue(), value)).evaluate($ec).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.LT
						return 
							new RTFullApp.General._3._L(
								Balance.$instance, 
								value, 
								new RTFullApp.General._3._S(
									Delete.$instance, 
									$dictvarCal_Core_Prelude_Ord_0, 
									x.getValue(), 
									leftSet), 
								rightSet);
					}

					case 1: {
						// Cal.Core.Prelude.EQ
						return Glue.$instance.f2S(leftSet, rightSet, $ec);
					}

					case 2: {
						// Cal.Core.Prelude.GT
						return 
							new RTFullApp.General._3._L(
								Balance.$instance, 
								value, 
								leftSet, 
								new RTFullApp.General._3._S(
									Delete.$instance, 
									$dictvarCal_Core_Prelude_Ord_0, 
									x.getValue(), 
									rightSet));
					}

					default: {
						return 
							badSwitchIndex(
								Delete.Cal_Collections_Set_delete_477_9);
					}
				}
			}

			default: {
				return badSwitchIndex(Delete.Cal_Collections_Set_delete_474_5);
			}
		}
	}

}
