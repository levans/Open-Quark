package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;
import org.openquark.cal_Cal_Collections_List.Drop;
import org.openquark.cal_Cal_Core_Prelude.Subtract_Int;
import org.openquark.cal_Cal_Core_Prelude.TYPE_List;

public final class Direct_Build extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_1 = RTData.CAL_Int.make(1);

	/**
	 * Singleton instance of this class.
	 */
	public static final Direct_Build $instance = new Direct_Build();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_directBuild_1346_9 = 
		new ErrorInfo("Cal.Collections.Set", "directBuild", 1346, 9);

	private static final ErrorInfo Cal_Collections_Set_directBuild_1348_9 = 
		new ErrorInfo("Cal.Collections.Set", "directBuild", 1348, 9);

	private static final ErrorInfo Cal_Collections_Set_directBuild_1350_9 = 
		new ErrorInfo("Cal.Collections.Set", "directBuild", 1350, 9);

	private static final ErrorInfo Cal_Collections_Set_directBuild_1352_9 = 
		new ErrorInfo("Cal.Collections.Set", "directBuild", 1352, 9);

	private static final ErrorInfo Cal_Collections_Set_directBuild_1354_9 = 
		new ErrorInfo("Cal.Collections.Set", "directBuild", 1354, 9);

	private static final ErrorInfo Cal_Collections_Set_directBuild_1365_13 = 
		new ErrorInfo("Cal.Collections.Set", "directBuild", 1365, 13);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Direct_Build() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "directBuild";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.directBuild";
	}

	private static final RTValue nRight$13$def_Lazy(int n, RTValue nLeft, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Subtract_Int.$instance, 
				new RTFullApp.General._2._L(
					Subtract_Int.$instance, 
					RTData.CAL_Int.make(n), 
					nLeft), 
				Direct_Build.$L1_Int_1);
	}

	private static final RTValue nRight$13$def_Strict(int n, RTValue nLeft, RTExecutionContext $ec) throws CALExecutorException {
		return 
			RTData.CAL_Int.make((n - nLeft.evaluate($ec).getOrdinalValue()) - 1);
	}

	private static final int nRight$13$def_Unboxed(int n, RTValue nLeft, RTExecutionContext $ec) throws CALExecutorException {
		return (n - nLeft.evaluate($ec).getOrdinalValue()) - 1;
	}

	private static final RTValue nLeft$12$def_Lazy(int n, RTExecutionContext $ec) throws CALExecutorException {
		return RTData.CAL_Int.make(n / 2);
	}

	private static final RTValue nLeft$12$def_Strict(int n, RTExecutionContext $ec) throws CALExecutorException {
		return RTData.CAL_Int.make(n / 2);
	}

	private static final int nLeft$12$def_Unboxed(int n, RTExecutionContext $ec) throws CALExecutorException {
		return n / 2;
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.directBuild
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue list = $rootNode.getArgValue();
		RTValue n$L = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				n$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list, list = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.directBuild
	 */
	public final RTValue f2L(RTValue n$L, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				n$L.evaluate($ec).getOrdinalValue(), 
				RTValue.lastRef(list, list = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.directBuild
	 */
	public final RTValue f2S(int n, RTValue list, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		switch (n) {

			case 0: {
				return Direct_Build.i_Tip;
			}

			case 5: {
				TYPE_List $case2;

				switch (($case2 = (((TYPE_List)(java.lang.Object)list.evaluate($ec)))).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.Nil
						return 
							unhandledSwitchIndex(
								Direct_Build.Cal_Collections_Set_directBuild_1346_9, 
								"Cal.Core.Prelude.Nil");
					}

					case 1: {
						// Cal.Core.Prelude.Cons
						// Decompose data type to access members.
						RTValue y1 = $case2.get_head();
						RTValue list2 = $case2.get_tail();

						TYPE_List $case3;

						switch (($case3 = (((TYPE_List)(java.lang.Object)list2.evaluate($ec)))).getOrdinalValue()) {

							case 0: {
								// Cal.Core.Prelude.Nil
								return 
									unhandledSwitchIndex(
										Direct_Build.Cal_Collections_Set_directBuild_1348_9, 
										"Cal.Core.Prelude.Nil");
							}

							case 1: {
								// Cal.Core.Prelude.Cons
								// Decompose data type to access members.
								RTValue y2 = $case3.get_head();
								RTValue list3 = $case3.get_tail();

								TYPE_List $case4;

								switch (($case4 = (((TYPE_List)(java.lang.Object)list3.evaluate($ec)))).getOrdinalValue()) {

									case 0: {
										// Cal.Core.Prelude.Nil
										return 
											unhandledSwitchIndex(
												Direct_Build.Cal_Collections_Set_directBuild_1350_9, 
												"Cal.Core.Prelude.Nil");
									}

									case 1: {
										// Cal.Core.Prelude.Cons
										// Decompose data type to access members.
										RTValue y3 = $case4.get_head();
										RTValue list4 = 
											$case4.get_tail();

										TYPE_List $case5;

										switch (($case5 = (((TYPE_List)(java.lang.Object)list4.evaluate($ec)))).getOrdinalValue()) {

											case 0: {
												// Cal.Core.Prelude.Nil
												return 
													unhandledSwitchIndex(
														Direct_Build.Cal_Collections_Set_directBuild_1352_9, 
														"Cal.Core.Prelude.Nil");
											}

											case 1: {
												// Cal.Core.Prelude.Cons
												// Decompose data type to access members.
												RTValue y4 = 
													$case5.get_head();
												RTValue list5 = 
													$case5.get_tail();

												TYPE_List $case6;

												switch (($case6 = (((TYPE_List)(java.lang.Object)list5.evaluate($ec)))).getOrdinalValue()) {

													case 0: {
														// Cal.Core.Prelude.Nil
														return 
															unhandledSwitchIndex(
																Direct_Build.Cal_Collections_Set_directBuild_1354_9, 
																"Cal.Core.Prelude.Nil");
													}

													case 1: {
														// Cal.Core.Prelude.Cons
														// Decompose data type to access members.
														RTValue y5 = 
															$case6.get_head();

														return 
															new TYPE_Set.CAL_Bin(
																5, 
																y4, 
																new TYPE_Set.CAL_Bin(
																	3, 
																	y2, 
																	Single.$instance.f1S(
																		y1, 
																		$ec).evaluate(
																		$ec), 
																	Single.$instance.f1S(
																		y3, 
																		$ec).evaluate(
																		$ec)), 
																Single.$instance.f1S(
																	y5, 
																	$ec).evaluate(
																	$ec));
													}

													default: {
														return 
															badSwitchIndex(
																Direct_Build.Cal_Collections_Set_directBuild_1354_9);
													}
												}
											}

											default: {
												return 
													badSwitchIndex(
														Direct_Build.Cal_Collections_Set_directBuild_1352_9);
											}
										}
									}

									default: {
										return 
											badSwitchIndex(
												Direct_Build.Cal_Collections_Set_directBuild_1350_9);
									}
								}
							}

							default: {
								return 
									badSwitchIndex(
										Direct_Build.Cal_Collections_Set_directBuild_1348_9);
							}
						}
					}

					default: {
						return 
							badSwitchIndex(
								Direct_Build.Cal_Collections_Set_directBuild_1346_9);
					}
				}
			}

			default: {
				int letVar_nLeft$U = 
					Direct_Build.nLeft$12$def_Unboxed(n, $ec);

				TYPE_List $case7;

				switch (($case7 = (((TYPE_List)(java.lang.Object)Drop.$instance.f2S(letVar_nLeft$U, list.evaluate($ec), $ec).evaluate($ec)))).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.Nil
						return 
							unhandledSwitchIndex(
								Direct_Build.Cal_Collections_Set_directBuild_1365_13, 
								"Cal.Core.Prelude.Nil");
					}

					case 1: {
						// Cal.Core.Prelude.Cons
						// Decompose data type to access members.
						RTValue root = $case7.get_head();
						RTValue rightList = $case7.get_tail();
						RTValue letVar_nRight = 
							Direct_Build.nRight$13$def_Lazy(
								n, 
								RTData.CAL_Int.make(letVar_nLeft$U), 
								$ec);

						letVar_nRight.evaluate($ec).getOrdinalValue();
						return 
							new TYPE_Set.CAL_Bin(
								n, 
								root, 
								Direct_Build.$instance.f2S(
									letVar_nLeft$U, 
									list, 
									$ec).evaluate(
									$ec), 
								Direct_Build.$instance.f2S(
									letVar_nRight.evaluate(
										$ec).getOrdinalValue(), 
									rightList, 
									$ec).evaluate(
									$ec));
					}

					default: {
						return 
							badSwitchIndex(
								Direct_Build.Cal_Collections_Set_directBuild_1365_13);
					}
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Direct_Build function;

		private int directBuild$n$1;

		private RTValue directBuild$list$2;

		public RTAppS(Direct_Build $function, int $directBuild$n$1, RTValue $directBuild$list$2) {
			assert (($function != null) && ($directBuild$list$2 != null)) : (badConsArgMsg());
			function = $function;
			directBuild$n$1 = $directBuild$n$1;
			directBuild$list$2 = $directBuild$list$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						directBuild$n$1, 
						RTValue.lastRef(
							directBuild$list$2, 
							directBuild$list$2 = null), 
						$ec));
				clearMembers();
			}
			return result;
		}

		public final void clearMembers() {
			directBuild$list$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(directBuild$n$1);
				}

				case 1: {
					return directBuild$list$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
