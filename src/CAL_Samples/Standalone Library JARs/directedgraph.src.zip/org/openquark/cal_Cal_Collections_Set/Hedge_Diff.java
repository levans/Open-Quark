package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Hedge_Diff extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Hedge_Diff $instance = new Hedge_Diff();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_hedgeDiff_779_9 = 
		new ErrorInfo("Cal.Collections.Set", "hedgeDiff", 779, 9);

	private static final ErrorInfo Cal_Collections_Set_hedgeDiff_782_9 = 
		new ErrorInfo("Cal.Collections.Set", "hedgeDiff", 782, 9);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Hedge_Diff() {
	}

	public final int getArity() {
		return 5;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "hedgeDiff";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.hedgeDiff";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.hedgeDiff
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue cmphi = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue cmplo = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_18 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f5S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_18, 
					$dictvarCal_Core_Prelude_Ord_18 = null), 
				RTValue.lastRef(cmplo, cmplo = null), 
				RTValue.lastRef(cmphi, cmphi = null), 
				RTValue.lastRef(t1.evaluate($ec), t1 = null), 
				RTValue.lastRef(t2.evaluate($ec), t2 = null), 
				$ec);
	}

	/**
	 * f5L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.hedgeDiff
	 */
	public final RTValue f5L(RTValue $dictvarCal_Core_Prelude_Ord_18, RTValue cmplo, RTValue cmphi, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f5S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_18, 
					$dictvarCal_Core_Prelude_Ord_18 = null), 
				RTValue.lastRef(cmplo, cmplo = null), 
				RTValue.lastRef(cmphi, cmphi = null), 
				RTValue.lastRef(t1.evaluate($ec), t1 = null), 
				RTValue.lastRef(t2.evaluate($ec), t2 = null), 
				$ec);
	}

	/**
	 * f5S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.hedgeDiff
	 */
	public final RTValue f5S(RTValue $dictvarCal_Core_Prelude_Ord_18, RTValue cmplo, RTValue cmphi, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (Is_Empty.$instance.fUnboxed1S(t1.getValue(), $ec)) {
			return Hedge_Diff.i_Tip;
		} else {
			if (Is_Empty.$instance.fUnboxed1S(t2.getValue(), $ec)) {
				TYPE_Set $case3;

				switch (($case3 = (((TYPE_Set)(java.lang.Object)t1.getValue()))).getOrdinalValue()) {

					case 0: {
						// Cal.Collections.Set.Tip
						return 
							unhandledSwitchIndex(
								Hedge_Diff.Cal_Collections_Set_hedgeDiff_779_9, 
								"Cal.Collections.Set.Tip");
					}

					case 1: {
						// Cal.Collections.Set.Bin
						// Decompose data type to access members.
						RTValue value = $case3.get_value();
						RTValue leftSet = $case3.get_leftSet();
						RTValue rightSet = $case3.get_rightSet();

						return 
							Join.$instance.f3S(
								value, 
								Filter_Gt.$instance.f2S(
									cmplo, 
									leftSet, 
									$ec).evaluate(
									$ec), 
								Filter_Lt.$instance.f2S(
									cmphi, 
									rightSet, 
									$ec).evaluate(
									$ec), 
								$ec);
					}

					default: {
						return 
							badSwitchIndex(
								Hedge_Diff.Cal_Collections_Set_hedgeDiff_779_9);
					}
				}
			} else {
				TYPE_Set $case4;

				switch (($case4 = (((TYPE_Set)(java.lang.Object)t2.getValue()))).getOrdinalValue()) {

					case 0: {
						// Cal.Collections.Set.Tip
						return 
							unhandledSwitchIndex(
								Hedge_Diff.Cal_Collections_Set_hedgeDiff_782_9, 
								"Cal.Collections.Set.Tip");
					}

					case 1: {
						// Cal.Collections.Set.Bin
						// Decompose data type to access members.
						RTValue value_1 = $case4.get_value();
						RTValue leftSet_1 = $case4.get_leftSet();
						RTValue rightSet_1 = $case4.get_rightSet();

						return 
							new RTFullApp.General._2._L(
								Merge.$instance, 
								new RTFullApp.General._5._L(
									Hedge_Diff.$instance, 
									$dictvarCal_Core_Prelude_Ord_18, 
									cmplo, 
									new RTPartialApp._3._2(
										Hedge_Diff__cmpx__11.$instance, 
										$dictvarCal_Core_Prelude_Ord_18, 
										value_1), 
									new Trim.RTAppS(
										Trim.$instance, 
										cmplo, 
										new RTPartialApp._3._2(
											Hedge_Diff__cmpx__11.$instance, 
											$dictvarCal_Core_Prelude_Ord_18, 
											value_1), 
										t1.getValue()), 
									leftSet_1), 
								new RTFullApp.General._5._L(
									Hedge_Diff.$instance, 
									$dictvarCal_Core_Prelude_Ord_18, 
									new RTPartialApp._3._2(
										Hedge_Diff__cmpx__11.$instance, 
										$dictvarCal_Core_Prelude_Ord_18, 
										value_1), 
									cmphi, 
									new Trim.RTAppS(
										Trim.$instance, 
										new RTPartialApp._3._2(
											Hedge_Diff__cmpx__11.$instance, 
											$dictvarCal_Core_Prelude_Ord_18, 
											value_1), 
										cmphi, 
										t1.getValue()), 
									rightSet_1));
					}

					default: {
						return 
							badSwitchIndex(
								Hedge_Diff.Cal_Collections_Set_hedgeDiff_782_9);
					}
				}
			}
		}
	}

}
