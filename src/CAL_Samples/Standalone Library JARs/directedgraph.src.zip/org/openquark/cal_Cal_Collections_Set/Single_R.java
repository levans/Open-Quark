package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Single_R extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Single_R $instance = new Single_R();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_singleR_1994_5 = 
		new ErrorInfo("Cal.Collections.Set", "singleR", 1994, 5);

	private Single_R() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "singleR";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.singleR";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.singleR
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t3 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t4 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue x1 = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(x1, x1 = null), 
				RTValue.lastRef(t4.evaluate($ec), t4 = null), 
				RTValue.lastRef(t3, t3 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.singleR
	 */
	public final RTValue f3L(RTValue x1, RTValue t4, RTValue t3, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(x1, x1 = null), 
				RTValue.lastRef(t4.evaluate($ec), t4 = null), 
				RTValue.lastRef(t3, t3 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.singleR
	 */
	public final RTValue f3S(RTValue x1, RTValue t4, RTValue t3, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t4.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 
					unhandledSwitchIndex(
						Single_R.Cal_Collections_Set_singleR_1994_5, 
						"Cal.Collections.Set.Tip");
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue x2 = $case1.get_value();
				RTValue t1 = $case1.get_leftSet();
				RTValue t2 = $case1.get_rightSet();

				return 
					Bin.$instance.f3S(
						x2, 
						t1, 
						Bin.$instance.f3S(
							x1, 
							t2, 
							t3.evaluate($ec), 
							$ec).evaluate(
							$ec), 
						$ec);
			}

			default: {
				return 
					badSwitchIndex(Single_R.Cal_Collections_Set_singleR_1994_5);
			}
		}
	}

}
