package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Rotate_L extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Rotate_L $instance = new Rotate_L();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_rotateL_1958_5 = 
		new ErrorInfo("Cal.Collections.Set", "rotateL", 1958, 5);

	private Rotate_L() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "rotateL";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.rotateL";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.rotateL
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue l = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue x = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.rotateL
	 */
	public final RTValue f3L(RTValue x, RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.rotateL
	 */
	public final RTValue f3S(RTValue x, RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)r.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 
					unhandledSwitchIndex(
						Rotate_L.Cal_Collections_Set_rotateL_1958_5, 
						"Cal.Collections.Set.Tip");
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue leftSet = $case1.get_leftSet();
				RTValue rightSet = $case1.get_rightSet();

				if (Size.$instance.fUnboxed1S(leftSet, $ec) < 
				(2 * Size.$instance.fUnboxed1S(rightSet, $ec))) {
					return 
						Single_L.$instance.f3S(
							x, 
							l.getValue(), 
							r.getValue(), 
							$ec);
				} else {
					return 
						Double_L.$instance.f3S(
							x, 
							l.getValue(), 
							r.getValue(), 
							$ec);
				}
			}

			default: {
				return 
					badSwitchIndex(Rotate_L.Cal_Collections_Set_rotateL_1958_5);
			}
		}
	}

}
