package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Glue extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Glue $instance = new Glue();

	private Glue() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "glue";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.glue";
	}

	private static final RTValue lNew$4$def_Lazy(RTValue pattern_m_lNew, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_m_lNew, 2);
	}

	private static final RTValue lNew$4$def_Strict(RTValue pattern_m_lNew, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_m_lNew.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue m$3$def_Lazy(RTValue pattern_m_lNew, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_m_lNew, 1);
	}

	private static final RTValue m$3$def_Strict(RTValue pattern_m_lNew, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_m_lNew.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_m_lNew$5$def_Lazy(RTValue l, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._S(Delete_Find_Max.$instance, l.getValue());
	}

	private static final RTValue $pattern_m_lNew$5$def_Strict(RTValue l, RTExecutionContext $ec) throws CALExecutorException {
		return Delete_Find_Max.$instance.f1S(l.getValue(), $ec).evaluate($ec);
	}

	private static final RTValue rNew$7$def_Lazy(RTValue pattern_m_rNew, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_m_rNew, 2);
	}

	private static final RTValue rNew$7$def_Strict(RTValue pattern_m_rNew, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_m_rNew.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue m$6$def_Lazy(RTValue pattern_m_rNew, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_m_rNew, 1);
	}

	private static final RTValue m$6$def_Strict(RTValue pattern_m_rNew, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_m_rNew.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_m_rNew$8$def_Lazy(RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._S(Delete_Find_Min.$instance, r.getValue());
	}

	private static final RTValue $pattern_m_rNew$8$def_Strict(RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return Delete_Find_Min.$instance.f1S(r.getValue(), $ec).evaluate($ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.glue
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r = $rootNode.getArgValue();
		RTValue l = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.glue
	 */
	public final RTValue f2L(RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.glue
	 */
	public final RTValue f2S(RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (Is_Empty.$instance.fUnboxed1S(l.getValue(), $ec)) {
			return r.getValue();
		} else {
			if (Is_Empty.$instance.fUnboxed1S(r.getValue(), $ec)) {
				return l.getValue();
			} else {
				if (Size.$instance.fUnboxed1S(l.getValue(), $ec) > 
				Size.$instance.fUnboxed1S(r.getValue(), $ec)) {
					RTValue letVar_pattern_m_lNew = 
						Glue.$pattern_m_lNew$5$def_Lazy(l.getValue(), $ec);

					return 
						Balance.$instance.f3S(
							Glue.m$3$def_Lazy(letVar_pattern_m_lNew, $ec), 
							Glue.lNew$4$def_Strict(letVar_pattern_m_lNew, $ec), 
							r.getValue(), 
							$ec);
				} else {
					RTValue letVar_pattern_m_rNew = 
						Glue.$pattern_m_rNew$8$def_Lazy(r.getValue(), $ec);

					return 
						Balance.$instance.f3S(
							Glue.m$6$def_Lazy(letVar_pattern_m_rNew, $ec), 
							l.getValue(), 
							Glue.rNew$7$def_Strict(letVar_pattern_m_rNew, $ec), 
							$ec);
				}
			}
		}
	}

}
