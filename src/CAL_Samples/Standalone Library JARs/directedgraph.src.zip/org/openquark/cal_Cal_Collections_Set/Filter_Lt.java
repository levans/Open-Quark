package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Filter_Lt extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Filter_Lt $instance = new Filter_Lt();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_filterLt_1551_5 = 
		new ErrorInfo("Cal.Collections.Set", "filterLt", 1551, 5);

	private static final ErrorInfo Cal_Collections_Set_filterLt_1554_9 = 
		new ErrorInfo("Cal.Collections.Set", "filterLt", 1554, 9);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Filter_Lt() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "filterLt";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.filterLt";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.filterLt
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue cmp = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(cmp, cmp = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.filterLt
	 */
	public final RTValue f2L(RTValue cmp, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(cmp, cmp = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.filterLt
	 */
	public final RTValue f2S(RTValue cmp, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_Set $case1;

			switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Collections.Set.Tip
					return Filter_Lt.i_Tip;
				}

				case 1: {
					// Cal.Collections.Set.Bin
					// Decompose data type to access members.
					RTValue value = $case1.get_value();
					RTValue leftSet = $case1.get_leftSet();
					RTValue rightSet = $case1.get_rightSet();

					switch (cmp.f1L(value, $ec).evaluate($ec).getOrdinalValue()) {

						case 0: {
							// Cal.Core.Prelude.LT
							t = leftSet;
							continue TRLoop;
						}

						case 1: {
							// Cal.Core.Prelude.EQ
							return leftSet.getValue();
						}

						case 2: {
							// Cal.Core.Prelude.GT
							return 
								new RTFullApp.General._3._L(
									Join.$instance, 
									value, 
									leftSet, 
									new RTAppS(
										Filter_Lt.$instance, 
										cmp, 
										rightSet));
						}

						default: {
							return 
								badSwitchIndex(
									Filter_Lt.Cal_Collections_Set_filterLt_1554_9);
						}
					}
				}

				default: {
					return 
						badSwitchIndex(
							Filter_Lt.Cal_Collections_Set_filterLt_1551_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Filter_Lt function;

		private RTValue filterLt$cmp$1;

		private RTValue filterLt$t$2;

		public RTAppS(Filter_Lt $function, RTValue $filterLt$cmp$1, RTValue $filterLt$t$2) {
			assert (
				(($function != null) && ($filterLt$cmp$1 != null)) && 
				($filterLt$t$2 != null)) : (badConsArgMsg());
			function = $function;
			filterLt$cmp$1 = $filterLt$cmp$1;
			filterLt$t$2 = $filterLt$t$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f2S(
						RTValue.lastRef(filterLt$cmp$1, filterLt$cmp$1 = null), 
						RTValue.lastRef(filterLt$t$2, filterLt$t$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			filterLt$cmp$1 = null;
			filterLt$t$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 2;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return filterLt$cmp$1;
				}

				case 1: {
					return filterLt$t$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 2)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
