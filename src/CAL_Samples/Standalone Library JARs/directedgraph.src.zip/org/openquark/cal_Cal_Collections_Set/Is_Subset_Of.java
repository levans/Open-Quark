package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Is_Subset_Of extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Is_Subset_Of $instance = new Is_Subset_Of();

	private Is_Subset_Of() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "isSubsetOf";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.isSubsetOf";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.isSubsetOf
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_16 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_16, 
					$dictvarCal_Core_Prelude_Ord_16 = null), 
				RTValue.lastRef(t1.evaluate($ec), t1 = null), 
				RTValue.lastRef(t2.evaluate($ec), t2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.isSubsetOf
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_16, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_16, 
					$dictvarCal_Core_Prelude_Ord_16 = null), 
				RTValue.lastRef(t1.evaluate($ec), t1 = null), 
				RTValue.lastRef(t2.evaluate($ec), t2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.isSubsetOf
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_16, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			RTData.CAL_Boolean.make(
				(Size.$instance.fUnboxed1S(t1.getValue(), $ec) <= 
				Size.$instance.fUnboxed1S(t2.getValue(), $ec)) && 
				Is_Subset_Of_Helper.$instance.fUnboxed3S(
					$dictvarCal_Core_Prelude_Ord_16, 
					t1.getValue(), 
					t2.getValue(), 
					$ec));
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Collections.Set.isSubsetOf
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Ord_16, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			(Size.$instance.fUnboxed1S(t1.getValue(), $ec) <= 
			Size.$instance.fUnboxed1S(t2.getValue(), $ec)) && 
			Is_Subset_Of_Helper.$instance.fUnboxed3S(
				$dictvarCal_Core_Prelude_Ord_16, 
				t1.getValue(), 
				t2.getValue(), 
				$ec);
	}

}
