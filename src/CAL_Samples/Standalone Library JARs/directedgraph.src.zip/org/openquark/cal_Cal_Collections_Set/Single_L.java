package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Single_L extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Single_L $instance = new Single_L();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_singleL_1986_5 = 
		new ErrorInfo("Cal.Collections.Set", "singleL", 1986, 5);

	private Single_L() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "singleL";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.singleL";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.singleL
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t4 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue x1 = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(x1, x1 = null), 
				RTValue.lastRef(t1, t1 = null), 
				RTValue.lastRef(t4.evaluate($ec), t4 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.singleL
	 */
	public final RTValue f3L(RTValue x1, RTValue t1, RTValue t4, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(x1, x1 = null), 
				RTValue.lastRef(t1, t1 = null), 
				RTValue.lastRef(t4.evaluate($ec), t4 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.singleL
	 */
	public final RTValue f3S(RTValue x1, RTValue t1, RTValue t4, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t4.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 
					unhandledSwitchIndex(
						Single_L.Cal_Collections_Set_singleL_1986_5, 
						"Cal.Collections.Set.Tip");
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue x2 = $case1.get_value();
				RTValue t2 = $case1.get_leftSet();
				RTValue t3 = $case1.get_rightSet();

				return 
					Bin.$instance.f3S(
						x2, 
						Bin.$instance.f3S(
							x1, 
							t1.evaluate($ec), 
							t2, 
							$ec).evaluate(
							$ec), 
						t3, 
						$ec);
			}

			default: {
				return 
					badSwitchIndex(Single_L.Cal_Collections_Set_singleL_1986_5);
			}
		}
	}

}
