package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Delete_Find_Min extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Delete_Find_Min $instance = new Delete_Find_Min();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_deleteFindMin_1825_5 = 
		new ErrorInfo("Cal.Collections.Set", "deleteFindMin", 1825, 5);

	private static final ErrorInfo Cal_Collections_Set_deleteFindMin_1834_13 = 
		new ErrorInfo("Cal.Collections.Set", "deleteFindMin", 1834, 13);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Delete_Find_Min() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "deleteFindMin";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.deleteFindMin";
	}

	private static final RTValue lNew$6$def_Lazy(RTValue pattern_xm_lNew, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_xm_lNew, 2);
	}

	private static final RTValue lNew$6$def_Strict(RTValue pattern_xm_lNew, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_xm_lNew.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue xm$5$def_Lazy(RTValue pattern_xm_lNew, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_xm_lNew, 1);
	}

	private static final RTValue xm$5$def_Strict(RTValue pattern_xm_lNew, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_xm_lNew.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_xm_lNew$7$def_Lazy(RTValue leftSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._S(
				Delete_Find_Min.$instance, 
				leftSet.getValue());
	}

	private static final RTValue $pattern_xm_lNew$7$def_Strict(RTValue leftSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Delete_Find_Min.$instance.f1S(leftSet.getValue(), $ec).evaluate($ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.deleteFindMin
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.deleteFindMin
	 */
	public final RTValue f1L(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.deleteFindMin
	 */
	public final RTValue f1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {new RTError.RTAppS(RTError.$instance, RTData.CAL_Opaque.make(Delete_Find_Min.Cal_Collections_Set_deleteFindMin_1834_13), "Can not return the minimal element of an empty set."), Delete_Find_Min.i_Tip});
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue value = $case1.get_value();
				RTValue leftSet = $case1.get_leftSet();
				RTValue rightSet = $case1.get_rightSet();

				if (Is_Empty.$instance.fUnboxed1S(leftSet, $ec)) {
					return 
						RTRecordValue.makeTupleRecord(
							new RTValue[] {value, rightSet});
				} else {
					RTValue letVar_pattern_xm_lNew = 
						Delete_Find_Min.$pattern_xm_lNew$7$def_Lazy(
							leftSet, 
							$ec);

					return 
						RTRecordValue.makeTupleRecord(
							new RTValue[] {Delete_Find_Min.xm$5$def_Lazy(letVar_pattern_xm_lNew, $ec), new RTFullApp.General._3._L(Balance.$instance, value, Delete_Find_Min.lNew$6$def_Lazy(letVar_pattern_xm_lNew, $ec), rightSet)});
				}
			}

			default: {
				return 
					badSwitchIndex(
						Delete_Find_Min.Cal_Collections_Set_deleteFindMin_1825_5);
			}
		}
	}

}
