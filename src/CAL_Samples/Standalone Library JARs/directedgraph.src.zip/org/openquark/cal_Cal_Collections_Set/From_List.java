package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Fold_Left_Strict;

public final class From_List extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final From_List $instance = new From_List();

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private From_List() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "fromList";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.fromList";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.fromList
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue xs = $rootNode.getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_4 = 
			$rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_4, 
					$dictvarCal_Core_Prelude_Ord_4 = null), 
				RTValue.lastRef(xs.evaluate($ec), xs = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.fromList
	 */
	public final RTValue f2L(RTValue $dictvarCal_Core_Prelude_Ord_4, RTValue xs, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_4, 
					$dictvarCal_Core_Prelude_Ord_4 = null), 
				RTValue.lastRef(xs.evaluate($ec), xs = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.fromList
	 */
	public final RTValue f2S(RTValue $dictvarCal_Core_Prelude_Ord_4, RTValue xs, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			new Fold_Left_Strict.RTAppS(
				Fold_Left_Strict.$instance, 
				new RTPartialApp._3._1(
					From_List__ins__2.$instance, 
					$dictvarCal_Core_Prelude_Ord_4), 
				From_List.i_Tip, 
				xs.getValue());
	}

}
