package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.internal.runtime.lecc.functions.RTError;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Delete_Find_Max extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Delete_Find_Max $instance = new Delete_Find_Max();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_deleteFindMax_1848_5 = 
		new ErrorInfo("Cal.Collections.Set", "deleteFindMax", 1848, 5);

	private static final ErrorInfo Cal_Collections_Set_deleteFindMax_1857_13 = 
		new ErrorInfo("Cal.Collections.Set", "deleteFindMax", 1857, 13);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Delete_Find_Max() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "deleteFindMax";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.deleteFindMax";
	}

	private static final RTValue rNew$6$def_Lazy(RTValue pattern_xm_rNew, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_xm_rNew, 2);
	}

	private static final RTValue rNew$6$def_Strict(RTValue pattern_xm_rNew, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_xm_rNew.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue xm$5$def_Lazy(RTValue pattern_xm_rNew, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_xm_rNew, 1);
	}

	private static final RTValue xm$5$def_Strict(RTValue pattern_xm_rNew, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_xm_rNew.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final RTValue $pattern_xm_rNew$7$def_Lazy(RTValue rightSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._1._S(
				Delete_Find_Max.$instance, 
				rightSet.getValue());
	}

	private static final RTValue $pattern_xm_rNew$7$def_Strict(RTValue rightSet, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Delete_Find_Max.$instance.f1S(rightSet.getValue(), $ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.deleteFindMax
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.deleteFindMax
	 */
	public final RTValue f1L(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.deleteFindMax
	 */
	public final RTValue f1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 
					RTRecordValue.makeTupleRecord(
						new RTValue[] {new RTError.RTAppS(RTError.$instance, RTData.CAL_Opaque.make(Delete_Find_Max.Cal_Collections_Set_deleteFindMax_1857_13), "Can not return the maximal element of an empty set."), Delete_Find_Max.i_Tip});
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue value = $case1.get_value();
				RTValue leftSet = $case1.get_leftSet();
				RTValue rightSet = $case1.get_rightSet();

				if (Is_Empty.$instance.fUnboxed1S(rightSet, $ec)) {
					return 
						RTRecordValue.makeTupleRecord(
							new RTValue[] {value, leftSet});
				} else {
					RTValue letVar_pattern_xm_rNew = 
						Delete_Find_Max.$pattern_xm_rNew$7$def_Lazy(
							rightSet, 
							$ec);

					return 
						RTRecordValue.makeTupleRecord(
							new RTValue[] {Delete_Find_Max.xm$5$def_Lazy(letVar_pattern_xm_rNew, $ec), new RTFullApp.General._3._L(Balance.$instance, value, leftSet, Delete_Find_Max.rNew$6$def_Lazy(letVar_pattern_xm_rNew, $ec))});
				}
			}

			default: {
				return 
					badSwitchIndex(
						Delete_Find_Max.Cal_Collections_Set_deleteFindMax_1848_5);
			}
		}
	}

}
