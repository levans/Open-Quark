package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Trim extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Trim $instance = new Trim();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_trim_1473_5 = 
		new ErrorInfo("Cal.Collections.Set", "trim", 1473, 5);

	/*
	 * Data constructor class instances for all referenced data constructors.
	 */

	private static final TYPE_Set.CAL_Tip i_Tip = TYPE_Set.CAL_Tip.make();

	private Trim() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "trim";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.trim";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.trim
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue cmphi = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue cmplo = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(cmplo, cmplo = null), 
				RTValue.lastRef(cmphi, cmphi = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.trim
	 */
	public final RTValue f3L(RTValue cmplo, RTValue cmphi, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(cmplo, cmplo = null), 
				RTValue.lastRef(cmphi, cmphi = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.trim
	 */
	public final RTValue f3S(RTValue cmplo, RTValue cmphi, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			TYPE_Set $case1;

			switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

				case 0: {
					// Cal.Collections.Set.Tip
					return Trim.i_Tip;
				}

				case 1: {
					// Cal.Collections.Set.Bin
					// Decompose data type to access members.
					RTValue value = $case1.get_value();
					RTValue leftSet = $case1.get_leftSet();
					RTValue rightSet = $case1.get_rightSet();

					switch (cmplo.f1L(value, $ec).evaluate($ec).getOrdinalValue()) {

						case 0: {
							// Cal.Core.Prelude.LT
							switch (cmphi.f1L(value, $ec).evaluate($ec).getOrdinalValue()) {

								case 2: {
									// Cal.Core.Prelude.GT
									return t.getValue();
								}

								default: {
									t = leftSet;
									continue TRLoop;
								}
							}
						}

						default: {
							t = rightSet;
							continue TRLoop;
						}
					}
				}

				default: {
					return badSwitchIndex(Trim.Cal_Collections_Set_trim_1473_5);
				}
			}
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Trim function;

		private RTValue trim$cmplo$1;

		private RTValue trim$cmphi$2;

		private RTValue trim$t$3;

		public RTAppS(Trim $function, RTValue $trim$cmplo$1, RTValue $trim$cmphi$2, RTValue $trim$t$3) {
			assert (
				((($function != null) && ($trim$cmplo$1 != null)) && 
				($trim$cmphi$2 != null)) && 
				($trim$t$3 != null)) : (badConsArgMsg());
			function = $function;
			trim$cmplo$1 = $trim$cmplo$1;
			trim$cmphi$2 = $trim$cmphi$2;
			trim$t$3 = $trim$t$3;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(trim$cmplo$1, trim$cmplo$1 = null), 
						RTValue.lastRef(trim$cmphi$2, trim$cmphi$2 = null), 
						RTValue.lastRef(trim$t$3, trim$t$3 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			trim$cmplo$1 = null;
			trim$cmphi$2 = null;
			trim$t$3 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return trim$cmplo$1;
				}

				case 1: {
					return trim$cmphi$2;
				}

				case 2: {
					return trim$t$3;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
