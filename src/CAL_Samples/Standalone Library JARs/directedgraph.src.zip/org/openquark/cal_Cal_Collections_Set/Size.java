package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Size extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	/**
	 * Singleton instance of this class.
	 */
	public static final Size $instance = new Size();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_size_340_5 = 
		new ErrorInfo("Cal.Collections.Set", "size", 340, 5);

	private Size() {
	}

	public final int getArity() {
		return 1;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "size";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.size";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.size
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.size
	 */
	public final RTValue f1L(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return f1S(RTValue.lastRef(t.evaluate($ec), t = null), $ec);
	}

	/**
	 * f1S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.size
	 */
	public final RTValue f1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return Size.$L1_Int_0;
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				int size$U = $case1.get_size_As_Int();

				return RTData.CAL_Int.make(size$U).getValue();
			}

			default: {
				return badSwitchIndex(Size.Cal_Collections_Set_size_340_5);
			}
		}
	}

	/**
	 * fUnboxed1S
	 * This method implements the logic of the CAL function Cal.Collections.Set.size
	 * This version of the logic returns an unboxed value.
	 */
	public final int fUnboxed1S(RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 0;
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				int size$U = $case1.get_size_As_Int();

				return size$U;
			}

			default: {
				return badSwitchIndex_int(Size.Cal_Collections_Set_size_340_5);
			}
		}
	}

}
