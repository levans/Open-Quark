package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Join extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Join $instance = new Join();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_join_1699_5 = 
		new ErrorInfo("Cal.Collections.Set", "join", 1699, 5);

	private static final ErrorInfo Cal_Collections_Set_join_1702_9 = 
		new ErrorInfo("Cal.Collections.Set", "join", 1702, 9);

	private Join() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "join";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.join";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.join
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue l = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue x = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.join
	 */
	public final RTValue f3L(RTValue x, RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.join
	 */
	public final RTValue f3S(RTValue x, RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)l.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return Insert_Min.$instance.f2S(x, r.getValue(), $ec);
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				int sizeL$U = $case1.get_size_As_Int();
				RTValue valueL = $case1.get_value();
				RTValue leftSetL = $case1.get_leftSet();
				RTValue rightSetL = $case1.get_rightSet();

				TYPE_Set $case2;

				switch (($case2 = (((TYPE_Set)(java.lang.Object)r.getValue()))).getOrdinalValue()) {

					case 0: {
						// Cal.Collections.Set.Tip
						return Insert_Max.$instance.f2S(x, l.getValue(), $ec);
					}

					case 1: {
						// Cal.Collections.Set.Bin
						// Decompose data type to access members.
						int sizeR$U = $case2.get_size_As_Int();
						RTValue valueR = $case2.get_value();
						RTValue leftSetR = $case2.get_leftSet();
						RTValue rightSetR = $case2.get_rightSet();

						if ((4 * sizeL$U) <= sizeR$U) {
							return 
								new RTFullApp.General._3._L(
									Balance.$instance, 
									valueR, 
									new RTFullApp.General._3._S(
										Join.$instance, 
										x, 
										l.getValue(), 
										leftSetR), 
									rightSetR);
						} else {
							if ((4 * sizeR$U) <= sizeL$U) {
								return 
									new RTFullApp.General._3._L(
										Balance.$instance, 
										valueL, 
										leftSetL, 
										new RTFullApp.General._3._S(
											Join.$instance, 
											x, 
											rightSetL, 
											r.getValue()));
							} else {
								return 
									Bin.$instance.f3S(
										x, 
										l.getValue(), 
										r.getValue(), 
										$ec);
							}
						}
					}

					default: {
						return 
							badSwitchIndex(Join.Cal_Collections_Set_join_1702_9);
					}
				}
			}

			default: {
				return badSwitchIndex(Join.Cal_Collections_Set_join_1699_5);
			}
		}
	}

}
