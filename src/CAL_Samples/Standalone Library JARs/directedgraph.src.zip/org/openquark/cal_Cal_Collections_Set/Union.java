package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTPartialApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Const__;

public final class Union extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_0 = RTData.CAL_Int.make(0);

	private static final RTData.CAL_Int $L2_Int_2 = RTData.CAL_Int.make(2);

	/**
	 * Singleton instance of this class.
	 */
	public static final Union $instance = new Union();

	private Union() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "union";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.union";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.union
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_26 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_26, 
					$dictvarCal_Core_Prelude_Ord_26 = null), 
				RTValue.lastRef(t1.evaluate($ec), t1 = null), 
				RTValue.lastRef(t2.evaluate($ec), t2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.union
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_26, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_26, 
					$dictvarCal_Core_Prelude_Ord_26 = null), 
				RTValue.lastRef(t1.evaluate($ec), t1 = null), 
				RTValue.lastRef(t2.evaluate($ec), t2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.union
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_26, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		if (Is_Empty.$instance.fUnboxed1S(t1.getValue(), $ec)) {
			return t2.getValue();
		} else {
			if (Is_Empty.$instance.fUnboxed1S(t2.getValue(), $ec)) {
				return t1.getValue();
			} else {
				if (Size.$instance.fUnboxed1S(t1.getValue(), $ec) >= 
				Size.$instance.fUnboxed1S(t2.getValue(), $ec)) {
					return 
						Hedge_Union.$instance.f5S(
							$dictvarCal_Core_Prelude_Ord_26, 
							new RTPartialApp._2._1(
								Const__.$instance, 
								Union.$L1_Int_0), 
							new RTPartialApp._2._1(
								Const__.$instance, 
								Union.$L2_Int_2), 
							t1.getValue(), 
							t2.getValue(), 
							$ec);
				} else {
					return 
						Hedge_Union.$instance.f5S(
							$dictvarCal_Core_Prelude_Ord_26, 
							new RTPartialApp._2._1(
								Const__.$instance, 
								Union.$L1_Int_0), 
							new RTPartialApp._2._1(
								Const__.$instance, 
								Union.$L2_Int_2), 
							t2.getValue(), 
							t1.getValue(), 
							$ec);
				}
			}
		}
	}

}
