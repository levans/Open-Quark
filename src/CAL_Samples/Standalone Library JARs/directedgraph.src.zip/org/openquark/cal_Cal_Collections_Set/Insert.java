package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTOApp3;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Insert extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_5 = RTData.CAL_Int.make(5);

	/**
	 * Singleton instance of this class.
	 */
	public static final Insert $instance = new Insert();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_insert_441_5 = 
		new ErrorInfo("Cal.Collections.Set", "insert", 441, 5);

	private static final ErrorInfo Cal_Collections_Set_insert_444_9 = 
		new ErrorInfo("Cal.Collections.Set", "insert", 444, 9);

	private Insert() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "insert";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.insert";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.insert
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue x = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_3 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_3, 
					$dictvarCal_Core_Prelude_Ord_3 = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.insert
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_3, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_3, 
					$dictvarCal_Core_Prelude_Ord_3 = null), 
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(t.evaluate($ec), t = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.insert
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_3, RTValue x, RTValue t, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return Single.$instance.f1S(x, $ec);
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				int size$U = $case1.get_size_As_Int();
				RTValue value = $case1.get_value();
				RTValue leftSet = $case1.get_leftSet();
				RTValue rightSet = $case1.get_rightSet();

				switch ((new RTOApp3($dictvarCal_Core_Prelude_Ord_3, Insert.$L1_Int_5, x, value)).evaluate($ec).getOrdinalValue()) {

					case 0: {
						// Cal.Core.Prelude.LT
						return 
							new RTFullApp.General._3._L(
								Balance.$instance, 
								value, 
								new RTFullApp.General._3._S(
									Insert.$instance, 
									$dictvarCal_Core_Prelude_Ord_3, 
									x, 
									leftSet), 
								rightSet);
					}

					case 1: {
						// Cal.Core.Prelude.EQ
						return 
							new TYPE_Set.CAL_Bin(size$U, x, leftSet, rightSet);
					}

					case 2: {
						// Cal.Core.Prelude.GT
						return 
							new RTFullApp.General._3._L(
								Balance.$instance, 
								value, 
								leftSet, 
								new RTFullApp.General._3._S(
									Insert.$instance, 
									$dictvarCal_Core_Prelude_Ord_3, 
									x, 
									rightSet));
					}

					default: {
						return 
							badSwitchIndex(
								Insert.Cal_Collections_Set_insert_444_9);
					}
				}
			}

			default: {
				return badSwitchIndex(Insert.Cal_Collections_Set_insert_441_5);
			}
		}
	}

}
