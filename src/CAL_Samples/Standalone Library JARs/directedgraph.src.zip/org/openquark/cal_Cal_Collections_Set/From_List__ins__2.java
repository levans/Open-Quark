package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class From_List__ins__2 extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final From_List__ins__2 $instance = new From_List__ins__2();

	private From_List__ins__2() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "fromList$ins$2";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.fromList$ins$2";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.fromList$ins$2
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue x = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_5 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_5, 
					$dictvarCal_Core_Prelude_Ord_5 = null), 
				RTValue.lastRef(t, t = null), 
				RTValue.lastRef(x, x = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.fromList$ins$2
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_5, RTValue t, RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_5, 
					$dictvarCal_Core_Prelude_Ord_5 = null), 
				RTValue.lastRef(t, t = null), 
				RTValue.lastRef(x, x = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.fromList$ins$2
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_5, RTValue t, RTValue x, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			Insert.$instance.f3S(
				$dictvarCal_Core_Prelude_Ord_5, 
				x, 
				t.evaluate($ec), 
				$ec);
	}

}
