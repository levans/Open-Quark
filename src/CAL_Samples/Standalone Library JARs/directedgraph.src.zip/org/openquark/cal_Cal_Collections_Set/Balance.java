package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal_Cal_Core_Prelude.Add_Int;

public final class Balance extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Int $L1_Int_1 = RTData.CAL_Int.make(1);

	/**
	 * Singleton instance of this class.
	 */
	public static final Balance $instance = new Balance();

	private Balance() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "balance";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.balance";
	}

	private static final RTValue sizeX$6$def_Lazy(RTValue sizeL, RTValue sizeR, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._2._L(
				Add_Int.$instance, 
				new RTFullApp.General._2._L(Add_Int.$instance, sizeL, sizeR), 
				Balance.$L1_Int_1);
	}

	private static final RTValue sizeX$6$def_Strict(RTValue sizeL, RTValue sizeR, RTExecutionContext $ec) throws CALExecutorException {
		return 
			RTData.CAL_Int.make(
				(sizeL.evaluate($ec).getOrdinalValue() + 
				sizeR.evaluate($ec).getOrdinalValue()) + 
				1);
	}

	private static final int sizeX$6$def_Unboxed(RTValue sizeL, RTValue sizeR, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(sizeL.evaluate($ec).getOrdinalValue() + 
			sizeR.evaluate($ec).getOrdinalValue()) + 
			1;
	}

	private static final RTValue sizeR$5$def_Lazy(RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._1._S(Size.$instance, r.getValue());
	}

	private static final RTValue sizeR$5$def_Strict(RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return Size.$instance.f1S(r.getValue(), $ec).evaluate($ec);
	}

	private static final int sizeR$5$def_Unboxed(RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return Size.$instance.fUnboxed1S(r.getValue(), $ec);
	}

	private static final RTValue sizeL$4$def_Lazy(RTValue l, RTExecutionContext $ec) throws CALExecutorException {
		return new RTFullApp.General._1._S(Size.$instance, l.getValue());
	}

	private static final RTValue sizeL$4$def_Strict(RTValue l, RTExecutionContext $ec) throws CALExecutorException {
		return Size.$instance.f1S(l.getValue(), $ec).evaluate($ec);
	}

	private static final int sizeL$4$def_Unboxed(RTValue l, RTExecutionContext $ec) throws CALExecutorException {
		return Size.$instance.fUnboxed1S(l.getValue(), $ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.balance
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue l = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue x = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.balance
	 */
	public final RTValue f3L(RTValue x, RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(x, x = null), 
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.balance
	 */
	public final RTValue f3S(RTValue x, RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		RTValue letVar_sizeL = Balance.sizeL$4$def_Lazy(l.getValue(), $ec);
		RTValue letVar_sizeR = Balance.sizeR$5$def_Lazy(r.getValue(), $ec);

		// Top level supercombinator logic
		if ((letVar_sizeL.evaluate($ec).getOrdinalValue() + 
		letVar_sizeR.evaluate($ec).getOrdinalValue()) <= 
		1) {
			return 
				new TYPE_Set.CAL_Bin(
					Balance.sizeX$6$def_Unboxed(
						letVar_sizeL, 
						letVar_sizeR, 
						$ec), 
					x, 
					l.getValue(), 
					r.getValue());
		} else {
			if (letVar_sizeR.evaluate($ec).getOrdinalValue() >= 
			(4 * letVar_sizeL.evaluate($ec).getOrdinalValue())) {
				return 
					Rotate_L.$instance.f3S(x, l.getValue(), r.getValue(), $ec);
			} else {
				if (letVar_sizeL.evaluate($ec).getOrdinalValue() >= 
				(4 * letVar_sizeR.evaluate($ec).getOrdinalValue())) {
					return 
						Rotate_R.$instance.f3S(
							x, 
							l.getValue(), 
							r.getValue(), 
							$ec);
				} else {
					return 
						new TYPE_Set.CAL_Bin(
							Balance.sizeX$6$def_Unboxed(
								letVar_sizeL, 
								letVar_sizeR, 
								$ec), 
							x, 
							l.getValue(), 
							r.getValue());
				}
			}
		}
	}

}
