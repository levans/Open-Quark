package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTRecordSelection;
import org.openquark.cal.internal.runtime.lecc.RTRecordValue;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public final class Is_Subset_Of_Helper extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	private static final RTData.CAL_Boolean $L1_Boolean_false = 
		RTData.CAL_Boolean.make(false);

	/**
	 * Singleton instance of this class.
	 */
	public static final Is_Subset_Of_Helper $instance = 
		new Is_Subset_Of_Helper();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_isSubsetOfHelper_539_9 = 
		new ErrorInfo("Cal.Collections.Set", "isSubsetOfHelper", 539, 9);

	private Is_Subset_Of_Helper() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "isSubsetOfHelper";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.isSubsetOfHelper";
	}

	private static final RTValue gt$8$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 3);
	}

	private static final RTValue gt$8$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				3).evaluate(
				$ec);
	}

	private static final RTValue lt$7$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 2);
	}

	private static final RTValue lt$7$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				2).evaluate(
				$ec);
	}

	private static final RTValue found$6$def_Lazy(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return new RTRecordSelection.Ordinal(pattern_found_lt_gt, 1);
	}

	private static final RTValue found$6$def_Strict(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec);
	}

	private static final boolean found$6$def_Unboxed(RTValue pattern_found_lt_gt, RTExecutionContext $ec) throws CALExecutorException {
		return 
			(((RTRecordValue)(java.lang.Object)
				pattern_found_lt_gt.evaluate($ec))).getOrdinalFieldValue(
				1).evaluate(
				$ec).getBooleanValue();
	}

	private static final RTValue $pattern_found_lt_gt$9$def_Lazy(RTValue $dictvarCal_Core_Prelude_Ord_2, RTValue value, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			new RTFullApp.General._3._S(
				Split_Member.$instance, 
				$dictvarCal_Core_Prelude_Ord_2, 
				value, 
				t2.getValue());
	}

	private static final RTValue $pattern_found_lt_gt$9$def_Strict(RTValue $dictvarCal_Core_Prelude_Ord_2, RTValue value, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			Split_Member.$instance.f3S(
				$dictvarCal_Core_Prelude_Ord_2, 
				value, 
				t2.getValue(), 
				$ec).evaluate(
				$ec);
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.isSubsetOfHelper
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t2 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t1 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_2 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_2, 
					$dictvarCal_Core_Prelude_Ord_2 = null), 
				RTValue.lastRef(t1.evaluate($ec), t1 = null), 
				RTValue.lastRef(t2.evaluate($ec), t2 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.isSubsetOfHelper
	 */
	public final RTValue f3L(RTValue $dictvarCal_Core_Prelude_Ord_2, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_2, 
					$dictvarCal_Core_Prelude_Ord_2 = null), 
				RTValue.lastRef(t1.evaluate($ec), t1 = null), 
				RTValue.lastRef(t2.evaluate($ec), t2 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.isSubsetOfHelper
	 */
	public final RTValue f3S(RTValue $dictvarCal_Core_Prelude_Ord_2, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			// Top level supercombinator logic
			if (Is_Empty.$instance.fUnboxed1S(t1.getValue(), $ec)) {
				return RTData.CAL_Boolean.make(true);
			} else {
				if (Is_Empty.$instance.fUnboxed1S(t2.getValue(), $ec)) {
					return RTData.CAL_Boolean.make(false);
				} else {
					TYPE_Set $case3;

					switch (($case3 = (((TYPE_Set)(java.lang.Object)t1.getValue()))).getOrdinalValue()) {

						case 0: {
							// Cal.Collections.Set.Tip
							return 
								unhandledSwitchIndex(
									Is_Subset_Of_Helper.Cal_Collections_Set_isSubsetOfHelper_539_9, 
									"Cal.Collections.Set.Tip");
						}

						case 1: {
							// Cal.Collections.Set.Bin
							// Decompose data type to access members.
							RTValue value = $case3.get_value();
							RTValue leftSet = $case3.get_leftSet();
							RTValue rightSet = $case3.get_rightSet();
							RTValue letVar_pattern_found_lt_gt = 
								Is_Subset_Of_Helper.$pattern_found_lt_gt$9$def_Lazy(
									$dictvarCal_Core_Prelude_Ord_2, 
									value, 
									t2.getValue(), 
									$ec);

							if (Is_Subset_Of_Helper.found$6$def_Unboxed(
								letVar_pattern_found_lt_gt, 
								$ec)) {
								if (Is_Subset_Of_Helper.$instance.fUnboxed3S(
									$dictvarCal_Core_Prelude_Ord_2, 
									leftSet, 
									Is_Subset_Of_Helper.lt$7$def_Strict(
										letVar_pattern_found_lt_gt, 
										$ec), 
									$ec)) {
									t1 = rightSet;
										t2 = 
										Is_Subset_Of_Helper.gt$8$def_Strict(
											letVar_pattern_found_lt_gt, 
											$ec);
									continue TRLoop;
								} else {
									return Is_Subset_Of_Helper.$L1_Boolean_false;
								}
							} else {
								return Is_Subset_Of_Helper.$L1_Boolean_false;
							}
						}

						default: {
							return 
								badSwitchIndex(
									Is_Subset_Of_Helper.Cal_Collections_Set_isSubsetOfHelper_539_9);
						}
					}
				}
			}
		}
	}

	/**
	 * fUnboxed3S
	 * This method implements the logic of the CAL function Cal.Collections.Set.isSubsetOfHelper
	 * This version of the logic returns an unboxed value.
	 */
	public final boolean fUnboxed3S(RTValue $dictvarCal_Core_Prelude_Ord_2, RTValue t1, RTValue t2, RTExecutionContext $ec) throws CALExecutorException {
		TRLoop: while (true) {
			if ($ec.isQuitRequested()) {
				throw RTValue.INTERRUPT_EXCEPTION;
			}
			RTValue $result = 
				f3S($dictvarCal_Core_Prelude_Ord_2, t1, t2, $ec);

			$dictvarCal_Core_Prelude_Ord_2 = null;
			t1 = null;
			t2 = null;
			return $result.evaluate($ec).getBooleanValue();
		}
	}

	public static final class RTAppS extends RTFullApp {
		private final Is_Subset_Of_Helper function;

		private RTValue $dictvarCal_Core_Prelude_Ord_2;

		private RTValue isSubsetOfHelper$t1$1;

		private RTValue isSubsetOfHelper$t2$2;

		public RTAppS(Is_Subset_Of_Helper $function, RTValue $$dictvarCal_Core_Prelude_Ord_2, RTValue $isSubsetOfHelper$t1$1, RTValue $isSubsetOfHelper$t2$2) {
			assert (
				((($function != null) && 
				($$dictvarCal_Core_Prelude_Ord_2 != null)) && 
				($isSubsetOfHelper$t1$1 != null)) && 
				($isSubsetOfHelper$t2$2 != null)) : (badConsArgMsg());
			function = $function;
			$dictvarCal_Core_Prelude_Ord_2 = $$dictvarCal_Core_Prelude_Ord_2;
			isSubsetOfHelper$t1$1 = $isSubsetOfHelper$t1$1;
			isSubsetOfHelper$t2$2 = $isSubsetOfHelper$t2$2;
		}

		protected final RTValue reduce(RTExecutionContext $ec) throws CALExecutorException {
			if (result == null) {
				setResult(
					function.f3S(
						RTValue.lastRef(
							$dictvarCal_Core_Prelude_Ord_2, 
							$dictvarCal_Core_Prelude_Ord_2 = null), 
						RTValue.lastRef(
							isSubsetOfHelper$t1$1, 
							isSubsetOfHelper$t1$1 = null), 
						RTValue.lastRef(
							isSubsetOfHelper$t2$2, 
							isSubsetOfHelper$t2$2 = null), 
						$ec));
			}
			return result;
		}

		public final void clearMembers() {
			$dictvarCal_Core_Prelude_Ord_2 = null;
			isSubsetOfHelper$t1$1 = null;
			isSubsetOfHelper$t2$2 = null;
		}

		public final int debug_getNChildren() {
			if (result != null) {
				return super.debug_getNChildren();
			} else {
				return 3;
			}
		}

		public final CalValue debug_getChild(int childN) {
			if (result != null) {
				return super.debug_getChild(childN);
			}
			switch (childN) {

				case 0: {
					return $dictvarCal_Core_Prelude_Ord_2;
				}

				case 1: {
					return isSubsetOfHelper$t1$1;
				}

				case 2: {
					return isSubsetOfHelper$t2$2;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public final java.lang.String debug_getNodeStartText() {
			if (result != null) {
				return super.debug_getNodeStartText();
			} else {
				return "(" + function.getQualifiedName();
			}
		}

		public final java.lang.String debug_getNodeEndText() {
			if (result != null) {
				return super.debug_getNodeEndText();
			} else {
				return ")";
			}
		}

		public final java.lang.String debug_getChildPrefixText(int childN) {
			if (result != null) {
				return super.debug_getChildPrefixText(childN);
			}
			if ((childN >= 0) && (childN < 3)) {
				return " ";
			}
			throw new java.lang.IndexOutOfBoundsException();
		}

	}
}
