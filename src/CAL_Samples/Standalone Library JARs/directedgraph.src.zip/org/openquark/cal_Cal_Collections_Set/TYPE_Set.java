package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTCons;
import org.openquark.cal.internal.runtime.lecc.RTData;
import org.openquark.cal.internal.runtime.lecc.RTDataConsFieldSelection;
import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.CalValue;
import org.openquark.cal.runtime.ErrorInfo;

public abstract class TYPE_Set extends RTCons {
	protected TYPE_Set() {
	}

	public RTValue get_size() {
		return badFieldAccessor("_size");
	}

	public RTValue get_value() {
		return badFieldAccessor("_value");
	}

	public RTValue get_leftSet() {
		return badFieldAccessor("_leftSet");
	}

	public RTValue get_rightSet() {
		return badFieldAccessor("_rightSet");
	}

	public int get_size_As_Int() throws CALExecutorException {
		return badFieldAccessor_Int("_size");
	}

	protected final java.lang.String getDCNameByOrdinal(int dcOrdinal) {
		switch (dcOrdinal) {

			case 0: {
				return "Tip";
			}

			case 1: {
				return "Bin";
			}

		}
		return 
			((java.lang.String)(java.lang.Object)
				RTValue.badValue_Object(
					null, 
					"Invalid DC ordinal in getDCNameByOrdinal() for org.openquark.cal_Cal_Collections_Set.TYPE_Set"));
	}

	public static final class CAL_Tip extends TYPE_Set {
		public static final CAL_Tip $instance = new CAL_Tip();

		private CAL_Tip() {
		}

		public final int getArity() {
			return 0;
		}

		public int getOrdinalValue() {
			return 0;
		}

		public static final CAL_Tip make() {
			return CAL_Tip.$instance;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Collections.Set";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Tip";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Collections.Set.Tip";
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Collections.Set.Tip";
			}

		}
	}
	public static final class CAL_Bin extends TYPE_Set {
		private final int _size;

		private RTValue _value;

		private final RTValue _leftSet;

		private final RTValue _rightSet;

		public static final CAL_Bin $instance = new CAL_Bin();

		private CAL_Bin() {
			_size = (-1);
			_leftSet = null;
			_rightSet = null;
		}

		public CAL_Bin(int member0, RTValue member1, RTValue member2, RTValue member3) {
			assert (
				((member1 != null) && (member2 != null)) && (member3 != null)) : ("Invalid constructor argument for Cal.Collections.Set.Bin");
			_size = member0;
			_value = member1;
			_leftSet = member2;
			_rightSet = member3;
		}

		public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
			// Arguments
			RTValue $arg3 = $rootNode.getArgValue();
			RTValue $currentRootNode;
			RTValue $arg2 = 
				($currentRootNode = $rootNode.prevArg()).getArgValue();
			final RTValue $arg1 = 
				($currentRootNode = $currentRootNode.prevArg()).getArgValue();
			RTValue $arg0 = $currentRootNode.prevArg().getArgValue();

			return 
				new CAL_Bin(
					$arg0.evaluate($ec).getOrdinalValue(), 
					$arg1, 
					$arg2.evaluate($ec), 
					$arg3.evaluate($ec));
		}

		public final RTValue f4L(RTValue member0, RTValue member1, RTValue member2, RTValue member3, RTExecutionContext $ec) throws CALExecutorException {
			return 
				new CAL_Bin(
					member0.evaluate($ec).getOrdinalValue(), 
					member1, 
					member2.evaluate($ec), 
					member3.evaluate($ec));
		}

		public final int getArity() {
			return 4;
		}

		public int getOrdinalValue() {
			return 1;
		}

		public static final CAL_Bin make() {
			return CAL_Bin.$instance;
		}

		public final RTValue get_size() {
			return RTData.CAL_Int.make(_size);
		}

		public final int get_size_As_Int() throws CALExecutorException {
			return _size;
		}

		public final RTValue get_value() {
			RTValue _value$;

			if (((java.lang.Object)
				(_value$ = _value))
				 instanceof RTResultFunction) {
				return _value = _value$.getValue();
			}
			return _value$;
		}

		public final RTValue get_leftSet() {
			return _leftSet;
		}

		public final RTValue get_rightSet() {
			return _rightSet;
		}

		public final RTValue buildDeepSeq(RTSupercombinator deepSeq, RTValue rhs) throws CALExecutorException {
			return 
				deepSeq.apply(
					get_value(), 
					deepSeq.apply(_leftSet, deepSeq.apply(_rightSet, rhs)));
		}

		public final RTValue getFieldByIndex(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return RTData.CAL_Int.make(_size);
				}

				case 1: {
					return get_value();
				}

				case 2: {
					return get_leftSet();
				}

				case 3: {
					return get_rightSet();
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return null;
		}

		public final int getFieldByIndex_As_Int(int dcOrdinal, int fieldIndex, ErrorInfo errorInfo) throws CALExecutorException {
			checkDCOrdinalForFieldSelection(dcOrdinal, errorInfo);
			switch (fieldIndex) {

				case 0: {
					return _size;
				}

			}
			badFieldIndexInGetFieldByIndex(fieldIndex);
			return -1;
		}

		public final java.lang.String getModuleName() {
			return "Cal.Collections.Set";
		}

		public final java.lang.String getUnqualifiedName() {
			return "Bin";
		}

		public final java.lang.String getQualifiedName() {
			return "Cal.Collections.Set.Bin";
		}

		public final boolean isFunctionSingleton() {
			return this == CAL_Bin.$instance;
		}

		public final CalValue debug_getChild(int childN) {
			if (isFunctionSingleton()) {
				throw new java.lang.IndexOutOfBoundsException();
			}
			switch (childN) {

				case 0: {
					return RTData.CAL_Int.make(_size);
				}

				case 1: {
					return _value;
				}

				case 2: {
					return _leftSet;
				}

				case 3: {
					return _rightSet;
				}

				default: {
					throw new java.lang.IndexOutOfBoundsException();
				}
			}
		}

		public static final class FieldSelection extends RTDataConsFieldSelection {
			public FieldSelection(RTValue $dataConsExpr, int $dcOrdinal, int $fieldOrdinal, ErrorInfo $errorInfo) {
				super ($dataConsExpr, $dcOrdinal, $fieldOrdinal, $errorInfo);
			}

			protected final java.lang.String getFieldNameByOrdinal(int ordinal) {
				switch (ordinal) {

					case 0: {
						return "size";
					}

					case 1: {
						return "value";
					}

					case 2: {
						return "leftSet";
					}

					case 3: {
						return "rightSet";
					}

				}
				throw new java.lang.IndexOutOfBoundsException();
			}

			protected final java.lang.String getDCName() {
				return "Cal.Collections.Set.Bin";
			}

		}
	}
}
