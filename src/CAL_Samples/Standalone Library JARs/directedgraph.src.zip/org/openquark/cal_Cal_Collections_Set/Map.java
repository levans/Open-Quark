package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;

public final class Map extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Map $instance = new Map();

	private Map() {
	}

	public final int getArity() {
		return 4;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "map";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.map";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.map
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue set = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue f = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_23 = 
			($currentRootNode = $currentRootNode.prevArg()).getArgValue();
		RTValue $dictvarCal_Core_Prelude_Ord_22 = 
			$currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_22, 
					$dictvarCal_Core_Prelude_Ord_22 = null), 
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_23, 
					$dictvarCal_Core_Prelude_Ord_23 = null), 
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(set.evaluate($ec), set = null), 
				$ec);
	}

	/**
	 * f4L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.map
	 */
	public final RTValue f4L(RTValue $dictvarCal_Core_Prelude_Ord_22, RTValue $dictvarCal_Core_Prelude_Ord_23, RTValue f, RTValue set, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f4S(
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_22, 
					$dictvarCal_Core_Prelude_Ord_22 = null), 
				RTValue.lastRef(
					$dictvarCal_Core_Prelude_Ord_23, 
					$dictvarCal_Core_Prelude_Ord_23 = null), 
				RTValue.lastRef(f, f = null), 
				RTValue.lastRef(set.evaluate($ec), set = null), 
				$ec);
	}

	/**
	 * f4S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.map
	 */
	public final RTValue f4S(RTValue $dictvarCal_Core_Prelude_Ord_22, RTValue $dictvarCal_Core_Prelude_Ord_23, RTValue f, RTValue set, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		return 
			From_List.$instance.f2S(
				$dictvarCal_Core_Prelude_Ord_23, 
				org.openquark.cal_Cal_Core_Prelude.Map.$instance.f2S(
					f, 
					To_Asc_List.$instance.f1S(set.getValue(), $ec).evaluate(
						$ec), 
					$ec).evaluate(
					$ec), 
				$ec);
	}

}
