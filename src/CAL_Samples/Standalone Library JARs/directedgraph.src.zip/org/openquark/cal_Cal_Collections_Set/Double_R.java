package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Double_R extends RTSupercombinator {
	/**
	 * Singleton instance of this class.
	 */
	public static final Double_R $instance = new Double_R();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_doubleR_2015_5 = 
		new ErrorInfo("Cal.Collections.Set", "doubleR", 2015, 5);

	private static final ErrorInfo Cal_Collections_Set_doubleR_2017_9 = 
		new ErrorInfo("Cal.Collections.Set", "doubleR", 2017, 9);

	private Double_R() {
	}

	public final int getArity() {
		return 3;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "doubleR";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.doubleR";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.doubleR
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue t4 = $rootNode.getArgValue();
		RTValue $currentRootNode;
		RTValue t5 = ($currentRootNode = $rootNode.prevArg()).getArgValue();
		RTValue x1 = $currentRootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f3S(
				RTValue.lastRef(x1, x1 = null), 
				RTValue.lastRef(t5.evaluate($ec), t5 = null), 
				RTValue.lastRef(t4, t4 = null), 
				$ec);
	}

	/**
	 * f3L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.doubleR
	 */
	public final RTValue f3L(RTValue x1, RTValue t5, RTValue t4, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f3S(
				RTValue.lastRef(x1, x1 = null), 
				RTValue.lastRef(t5.evaluate($ec), t5 = null), 
				RTValue.lastRef(t4, t4 = null), 
				$ec);
	}

	/**
	 * f3S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.doubleR
	 */
	public final RTValue f3S(RTValue x1, RTValue t5, RTValue t4, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)t5.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return 
					unhandledSwitchIndex(
						Double_R.Cal_Collections_Set_doubleR_2015_5, 
						"Cal.Collections.Set.Tip");
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				RTValue x2 = $case1.get_value();
				RTValue t1 = $case1.get_leftSet();
				RTValue t6 = $case1.get_rightSet();

				TYPE_Set $case2;

				switch (($case2 = (((TYPE_Set)(java.lang.Object)t6))).getOrdinalValue()) {

					case 0: {
						// Cal.Collections.Set.Tip
						return 
							unhandledSwitchIndex(
								Double_R.Cal_Collections_Set_doubleR_2017_9, 
								"Cal.Collections.Set.Tip");
					}

					case 1: {
						// Cal.Collections.Set.Bin
						// Decompose data type to access members.
						RTValue x3 = $case2.get_value();
						RTValue t2 = $case2.get_leftSet();
						RTValue t3 = $case2.get_rightSet();

						return 
							Bin.$instance.f3S(
								x3, 
								Bin.$instance.f3S(x2, t1, t2, $ec).evaluate(
									$ec), 
								Bin.$instance.f3S(
									x1, 
									t3, 
									t4.evaluate($ec), 
									$ec).evaluate(
									$ec), 
								$ec);
					}

					default: {
						return 
							badSwitchIndex(
								Double_R.Cal_Collections_Set_doubleR_2017_9);
					}
				}
			}

			default: {
				return 
					badSwitchIndex(Double_R.Cal_Collections_Set_doubleR_2015_5);
			}
		}
	}

}
