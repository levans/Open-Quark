package org.openquark.cal_Cal_Collections_Set;

import org.openquark.cal.internal.runtime.lecc.RTExecutionContext;
import org.openquark.cal.internal.runtime.lecc.RTFullApp;
import org.openquark.cal.internal.runtime.lecc.RTResultFunction;
import org.openquark.cal.internal.runtime.lecc.RTSupercombinator;
import org.openquark.cal.internal.runtime.lecc.RTValue;
import org.openquark.cal.runtime.CALExecutorException;
import org.openquark.cal.runtime.ErrorInfo;

public final class Merge extends RTSupercombinator {
	/*
	 * CAL data instances for literal values.
	 */

	/**
	 * Singleton instance of this class.
	 */
	public static final Merge $instance = new Merge();

	/*
	 * ErrorInfo instances.
	 */

	private static final ErrorInfo Cal_Collections_Set_merge_1761_5 = 
		new ErrorInfo("Cal.Collections.Set", "merge", 1761, 5);

	private static final ErrorInfo Cal_Collections_Set_merge_1764_9 = 
		new ErrorInfo("Cal.Collections.Set", "merge", 1764, 9);

	private Merge() {
	}

	public final int getArity() {
		return 2;
	}

	public final java.lang.String getModuleName() {
		return "Cal.Collections.Set";
	}

	public final java.lang.String getUnqualifiedName() {
		return "merge";
	}

	public final java.lang.String getQualifiedName() {
		return "Cal.Collections.Set.merge";
	}

	/**
	 * f
	 * This method implements the function logic of the CAL function Cal.Collections.Set.merge
	 */
	public final RTValue f(final RTResultFunction $rootNode, final RTExecutionContext $ec) throws CALExecutorException {
		// Arguments
		RTValue r = $rootNode.getArgValue();
		RTValue l = $rootNode.prevArg().getArgValue();

		// Release the fields in the root node to open them to garbage collection
		$rootNode.clearMembers();
		return 
			f2S(
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f2L
	 * This method implements the function logic of the CAL function Cal.Collections.Set.merge
	 */
	public final RTValue f2L(RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		return 
			f2S(
				RTValue.lastRef(l.evaluate($ec), l = null), 
				RTValue.lastRef(r.evaluate($ec), r = null), 
				$ec);
	}

	/**
	 * f2S
	 * This method implements the function logic of the CAL function Cal.Collections.Set.merge
	 */
	public final RTValue f2S(RTValue l, RTValue r, RTExecutionContext $ec) throws CALExecutorException {
		// Top level supercombinator logic
		TYPE_Set $case1;

		switch (($case1 = (((TYPE_Set)(java.lang.Object)l.getValue()))).getOrdinalValue()) {

			case 0: {
				// Cal.Collections.Set.Tip
				return r.getValue();
			}

			case 1: {
				// Cal.Collections.Set.Bin
				// Decompose data type to access members.
				int sizeL$U = $case1.get_size_As_Int();
				RTValue valueL = $case1.get_value();
				RTValue leftSetL = $case1.get_leftSet();
				RTValue rightSetL = $case1.get_rightSet();

				TYPE_Set $case2;

				switch (($case2 = (((TYPE_Set)(java.lang.Object)r.getValue()))).getOrdinalValue()) {

					case 0: {
						// Cal.Collections.Set.Tip
						return l.getValue();
					}

					case 1: {
						// Cal.Collections.Set.Bin
						// Decompose data type to access members.
						int sizeR$U = $case2.get_size_As_Int();
						RTValue valueR = $case2.get_value();
						RTValue leftSetR = $case2.get_leftSet();
						RTValue rightSetR = $case2.get_rightSet();

						if ((4 * sizeL$U) <= sizeR$U) {
							return 
								new RTFullApp.General._3._L(
									Balance.$instance, 
									valueR, 
									new RTFullApp.General._2._S(
										Merge.$instance, 
										l.getValue(), 
										leftSetR), 
									rightSetR);
						} else {
							if ((4 * sizeR$U) <= sizeL$U) {
								return 
									new RTFullApp.General._3._L(
										Balance.$instance, 
										valueL, 
										leftSetL, 
										new RTFullApp.General._2._S(
											Merge.$instance, 
											rightSetL, 
											r.getValue()));
							} else {
								return 
									Glue.$instance.f2S(
										l.getValue(), 
										r.getValue(), 
										$ec);
							}
						}
					}

					default: {
						return 
							badSwitchIndex(
								Merge.Cal_Collections_Set_merge_1764_9);
					}
				}
			}

			default: {
				return badSwitchIndex(Merge.Cal_Collections_Set_merge_1761_5);
			}
		}
	}

}
